import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/pages/Index'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index
    },
    {
      path: '/detail',
      name: 'Detail',
      component:resolve=>require(['@/components/Detail'],resolve)
    },
    {
      path: '/protocol',
      name: 'Protocol',
      component:resolve=>require(['@/components/Protocol'],resolve)
    },
    {
      path: '/order',
      name: 'Order',
      component:resolve=>require(['@/components/Order'],resolve)
    },
    {
      path: '/ordershow',
      name: 'Ordershow',
      component:resolve=>require(['@/components/Ordershow'],resolve)
    },
    {
      path: '/viplist',
      name: 'Viplist',
      component:resolve=>require(['@/components/Viplist'],resolve)
    },
    {
      path: '/watchdetail',
      name: 'Watchdetail',
      component:resolve=>require(['@/components/Watchdetail'],resolve)
    },
    {
      path: '/logout',
      name: 'Logout',
      component:resolve=>require(['@/components/Logout'],resolve)
    },
    {
      path: '/login',
      name: 'Login',
      component:resolve=>require(['@/components/Login'],resolve)
    }
  ]
})
