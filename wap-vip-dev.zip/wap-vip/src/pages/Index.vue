<template>
  <div class="vip">
    <div class="topNav">
      <div class="topNavActive">{{$t('vip')}}</div>
      <div @click="topNavClick">{{$t('tb2')}}</div>
    </div>
    <div class="banner">
      <!--<div class="bannerHead">-->
        <!--<p>{{$t('addLevel')}}</p>-->
        <!--<p>{{$t('global')}}<span>{{$t('famousWatch')}}</span></p>-->
        <!--<p>{{$t('wearWatch')}}</p>-->
      <!--</div>-->
      <img :src="vipInfo.length>0&&vipInfo[bannerNum].logo_pic" class="bannerVip">
      <div class="bannerWrap">
        <mt-swipe @change="handleChange" :auto="0" :show-indicators="false">
          <mt-swipe-item v-for="item,index in vipInfo" :key="index">
            <div class="imgWrap">
              <img :src="item.icon_pic" @click="$router.push({name:'Detail',params:{key:index},query:{code:item.code}})">
            </div>
          </mt-swipe-item>
        </mt-swipe>
        <!--<div class="bannerFoo" v-if="isShow">-->
          <!--<div class="bannerTit">-->
            <!--{{vipInfo[bannerNum].name}}-->
          <!--</div>-->
          <!--<div>-->
            <!--{{vipInfo[bannerNum].money}}-->
          <!--</div>-->
          <!--<div v-html="vipInfo[bannerNum].remark" class="content"></div>-->
          <!--&lt;!&ndash;<div class="add" @click="buyClick(item)" v-if="item.is_member_auth!=2&&item.is_member_auth!=3">&ndash;&gt;-->
          <!--&lt;!&ndash;{{item.is_member_auth==0?$t('add'):''||item.is_member_auth==1?$t('district'):''}}&ndash;&gt;-->
          <!--&lt;!&ndash;</div>&ndash;&gt;-->
        <!--</div>-->
      </div>
    </div>
    <toolbar :type="1"></toolbar>
  </div>
</template>

<script>
  const toolbar = () => import('../components/toolbar')


  export default {
    data() {
      let lang = localStorage.getItem('lang');
      if (lang) {
        this.$i18n.locale = lang
      }
      return {
        uid:localStorage.getItem('userId'),
        bannerNum:0,
        userInfo:{},
        vipInfo:[],
        topNavNum:1,
        isShow:false,
        messageBtn :{
          message:this.$t('isLogin'),
          title:this.$t('prompt'),
          confirmButtonText:this.$t('confirm'),
          cancelButtonText:this.$t('cancel'),
          showCancelButton:true,
          showConfirmButton:true
        },
      }
    },
    methods: {
      handleChange(index) {
        this.bannerNum = index
      },
      topNavClick(){
        location.href = `${process.env.URL.NEWS}/#/`
      },
      buyClick(item){
        let self = this
        if(!self.uid){
          self.messageBtn.message = this.$t('isLogin');
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if(self.userInfo&&self.userInfo.is_auth!=1){
          self.messageBtn.message = this.$t('isAuth');
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/realname`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if(item.is_member_auth==1){
          this.$router.push({name:'Viplist',params:item})
        }else{
          this.$router.push({name:'Protocol',params:item})
        }
      }
    },
    created() {
      document.title = this.$t('tb3')
    },
    mounted() {
      let self = this
      self.uid = localStorage.getItem('userId')
      self.$http.get(`${process.env.API.VIP}/vip/memlevel`).then(res=>{
        if(res.data.errcode=='0'){
          self.vipInfo = res.data.data.data
        }
      }).catch(err=>{
        console.log(err)
      })
      setTimeout(()=>{
        this.isShow = true
        self.userInfo = self.$store.state.userInfo
      },300)
    },
    components: {
      toolbar
    }//公共底部
  }
</script>
<!--当前页面样式-->
<style lang="less" scoped type="text/less">
  @media screen and (min-width: 410px) {
    .processMain{
      width: 400px!important;
      p{
        width: 105px!important;
      }
    }
    .processDown{
      width: 400px!important;
      padding: 0 45px!important;
    }
  }
  .content{
    font-size: 12px;
    color: #999;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    word-break: break-all;
    height: 32px;
    box-sizing: border-box;
    width: 100%;
  }
  .vip{
    background: #fff;
    .topNav{
      display: flex;
      align-items: center;
      height: 44px;
      width: 100%;
      justify-content: center;
      background: #fff;
      font-size: 14px;
      div{
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        height: 44px;
        min-width: 100px;
        color: #666;
        &.topNavActive{
          color: #333;
          font-weight: bold;
          &:before{
            content: '';
            position: absolute;
            width: 20px;
            height: 2px;
            background: #333;
            left: calc(~'50% - 10px');
            bottom: 0;
          }
        }
      }
    }
  }
  .addColor{
    color: #e9bf76!important;
  }
  .banner {
    display: flex;
    flex-direction: column;
    position: relative;
    .bannerVip{
      width: 100%;
      object-fit: cover;
      height: calc(~'100vh - 44px');
      position: absolute;
      top: 0;
      left: 0;
    }
    .bannerHead{
      position: absolute;
      display: flex;
      flex-direction: column;
      align-items: center;
      font-size: 23px;
      color: #fff;
      width: 100%;
      font-weight: bold;
      top: 50px;
      p{
        font-family: PingFangSC-Regular, sans-serif;
        text-align: center;
      }
      p:nth-child(2){
        margin: 15px 0;
        span{
          color: #ffcf4c;
          font-family: PingFangSC-Regular, sans-serif;
        }
      }
      p:nth-child(3){
        color: #ffcf4c;
      }
    }
    .bannerWrap{
      .mint-swipe {
        height: calc(~'100vh - 44px');
        box-sizing: border-box;
        .mint-swipe-item{
          overflow: hidden!important;
        }
        .imgWrap{
          padding: 0 15px;
          min-height: 400px;
          img {
            display: block;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
            width: 100%!important;
            margin: auto;
            border-radius: 10px;
            -o-object-fit: cover;
            object-fit: cover;
            /*-webkit-box-shadow: 10px 10px 5px #ccc;*/
            /*box-shadow: 0 3px 5px rgba(0,0,0,0.3);*/
          }
        }
      }
    }
    .bannerFoo {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-direction: column;
      box-sizing: border-box;
      width: 100%;
      padding: 0 15px;
      .bannerTit{
        font-size: 20px;
        margin-bottom: 10px;
      }
      div{
        max-width: 300px;
        display: flex;
        justify-content: center;
        align-items: center;
        &.content{
          margin-top: 50px;
        }
      }
      p {
        display: flex;
        font-size: 16px;
        color: #333;
        span {
          min-width: 80px;
          margin-top: 5px;
          font-size: 12px;
          color: #999;
        }
      }
      span {
        font-size: 16px;
        color: #333;
      }
      .add{
        width: 250px;
        height: 44px;
        line-height: 44px;
        text-align: center;
        background: #333;
        color: #fff;
        font-size: 16px;
        margin-top: 30px;
      }
    }
  }
  .process{
    width: 100%;
    box-sizing: border-box;
    font-size: 14px;
    color: #333;
    margin-bottom: 80px;
    padding: 15px 0;
    .processTit{
      padding: 12px 15px 30px;
    }
    .processMain{
      display: flex;
      width: 340px;
      margin: auto;
      align-items: flex-start;
      justify-content: flex-end;
      box-sizing: border-box;
      font-size: 12px;
      color: #666;
      p{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 85px;
        text-align: center;
        word-break: break-word;
        img{
          width: 44px;
          height: 44px;
          display: block;
          margin-bottom: 5px;
        }
      }
      div{
        padding-top: 20px;
        box-sizing: border-box;
        img{
          height: 5px;
          display: block;
        }
      }
    }
    .processDown{
      width:340px;
      display: flex;
      justify-content: flex-end;
      box-sizing: border-box;
      padding: 0 40px;
      margin: 5px auto;
      img{
        width: 5px;
        height: 42.22px;
      }
    }
  }
</style>
