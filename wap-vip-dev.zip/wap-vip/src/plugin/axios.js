import axios from 'axios'
import store from '@/store'
import SHA1 from '@/plugin/sha1'

let service = axios.create({
  headers: {}
})
const AppId = 'swisstimevip';
const AppSecret = '469d8b353e271ea4750793fb656cc331d8fd6bc1';
let ClientType = 3;
let ClientId;
let AppDigest;
let u = navigator.userAgent;
if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {
  ClientType = 32
  //安卓手机
} else if (u.indexOf('iPhone') > -1) {
  ClientType = 31
  //苹果手机
} else {
  ClientType = 33
  //winphone手机
}
AppDigest = SHA1(AppId + AppSecret);
ClientId = SHA1(new Date().getTime() + Math.floor(Math.random() * 9999));

// 添加请求拦截器
service.interceptors.request.use(function (config) {
  // 在发送请求之前做些什么
  config.headers['Accept-Language'] = localStorage.getItem('lang')?localStorage.getItem('lang'):'zh-cn'
  //当前移除AccessToken
  if(localStorage.getItem('userId')){
    config.headers['Authorization'] = localStorage.getItem('userId')
  }
  config.headers['RequestToken'] = AppDigest
  config.headers['ClientType'] = ClientType
  config.headers['ClientId'] = ClientId
  // if (localStorage.getItem('AccessToken')) {
  //   config.headers['AccessToken'] = localStorage.getItem('AccessToken')
  //   if (localStorage.getItem('userId')) {
  //     config.headers['Authorization'] = localStorage.getItem('userId')
  //   }
  // } else {
  //   config.headers['RequestToken'] = AppDigest
  //   config.headers['ClientType'] = ClientType
  //   config.headers['ClientId'] = ClientId
  // }
  return config
}, function (error) {
  // 对请求错误做些什么
  return Promise.reject(error)
})

// 添加响应拦截器
service.interceptors.response.use(function (response) {
  // 对响应数据做点什么
  if(response.data.errcode=='40001'){
    localStorage.removeItem('AccessToken')
    localStorage.removeItem('userId')
    setTimeout(()=>{
      location.reload()
    },1000)
  }else if(response.data.errcode=='40004' || response.data.errcode=='40023'){
    localStorage.removeItem('userId')
    window.location.href = `${process.env.URL.USER}/#/login`
  }
  return response
}, function (error) {
  // 对响应错误做点什么
  return Promise.reject(error)
})

export default service
