// getters.js      // 工具接口为了方便构建全局state自定义方法

export const msg = state => state.msg
