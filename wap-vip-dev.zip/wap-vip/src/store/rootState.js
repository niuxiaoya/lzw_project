// rootState.js       //  保存顶层的数据  （原始数据）
const state = {
  msg: '我是原始数据',
  language:'zh-cn',
  userId:''
}
export default state
