<template>
  <div class="vip">
    <div class="vipHead">
      <p class="tit">{{protocolInfo.title}}</p>
      <p class="time">{{$t('editTime')}}：<span>{{protocolInfo.publish_time}}</span></p>
    </div>
    <div class="main" v-html="protocolInfo.content">
    </div>
    <div class="subBtn" @click="buyClick">
      {{$t('agree')}}
    </div>
  </div>
</template>

<script>

  export default {
    data() {
      return {
        uid: localStorage.getItem('userId'),
        protocolInfo: {}
      }
    },
    methods: {
      buyClick() {
        location.href = `${process.env.URL.VIP}/#/order?code=${this.$route.params.code}`
      }
    },
    created() {
      let self = this
      document.title = this.$t('agreement')
    },
    mounted() {
      let self = this
      self.$http.get(`${process.env.API.NEWS}/news/agreement?uid=${self.uid}&name=VIP`).then(res => {
        if (res.data.errcode == '0') {
          self.protocolInfo = res.data.data
          self.protocolInfo.publish_time = self.$moment(self.protocolInfo.publish_time * 1000).format('YYYY年MM月DD日')
        }
        console.log(res)
      }).catch(err => {
        console.log(err)
      })
    }
  }
</script>
<!--当前页面样式-->
<style lang="less" scoped type="text/less">
  .vip {
    min-height: 100vh;
    background: #fff;
    .vipHead {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 15px;
      color: #333;
      border-bottom: 1px solid #f2f2f2;
      .tit {
        font-size: 16px;
        margin-bottom: 10px;
      }
      .time {
        font-size: 12px;
        color: #999;
      }
    }
    .main {
      padding: 30px 15px;
      box-sizing: border-box;
    }
    .subBtn {
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      line-height: 44px;
      width: 100%;
      font-size: 16px;
      background: #333;
      position: fixed;
      bottom: 0;
      left: 0;
    }
  }
</style>
