<template>
  <div class="order">
    <div class="orderTit">
      <div class="titFirst">
        <img :src="orderInfo.icon_pic">
        <div>
          <p>{{orderInfo.name}}</p>
          <span>{{orderInfo.money}}</span>
        </div>
      </div>
      <div class="titLast">
        <p>{{$t('payMethod')}}<span>{{orderInfo.pay_method}}{{pay_method=='1'?$t('offlinePayment'):$t('no')}}</span></p>
      </div>
    </div>
    <div class="orderMain">
      <p class="orderMainTit">{{$t('companyInfo')}}</p>
      <ul>
        <li>
          <div><p>{{$t('companyName1')}}：</p><span>{{$t('companyName')}}</span></div>
          <span class="fuzhi" :data-clipboard-text="$t('companyName')" @click="fuzhiClick($event)">{{$t('copy')}}</span>
        </li>
        <li>
          <div><p>{{$t('companyName2')}}：</p><span>{{$t('companyBankNum')}}</span></div>
          <span class="fuzhi" :data-clipboard-text="$t('companyBankNum')" @click="fuzhiClick($event)" >{{$t('copy')}}</span>
        </li>
        <li>
          <div><p>{{$t('companyName3')}}：</p><span>{{$t('companyBank')}}</span></div>
          <span class="fuzhi" :data-clipboard-text="$t('companyBank')" @click="fuzhiClick($event)">{{$t('copy')}}</span>
        </li>
      </ul>
    </div>
    <div class="prove">
      <p @click="">{{$t('prove')}} <span>（{{$t('tenImg')}}）</span></p>
      <div class="imgWrap">
        <ul>
          <li v-for="item,index in imgList">
            <img :src="item">
            <span @click.stop="imgDel(index)">
              <img src="../assets/images/vip/redClose.png">
            </span>
          </li>
          <li v-if="imgList.length<10">
            <el-upload
              class="avatar-uploader add"
              :action="imgHead"
              :headers="head"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload">
              <img v-if="imageUrl" :src="imageUrl" class="avatar">
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </li>
        </ul>
      </div>
    </div>
    <div class="btn" @click="sub">{{$t('subProve')}}</div>
  </div>
</template>
<script>
  import Clipboard from 'clipboard'
  export default {
    data(){
      return {
        imageUrl:require('../assets/images/vip/detail/add.png'),
        imgHead:`${process.env.API.USER}/user/upload`,
        imgNum:0,
        head:{
          AccessToken:localStorage.getItem('AccessToken'),
          Authorization:localStorage.getItem('userId')
        },
        orderInfo:{
        },
        imgList:[
        ],
        pay_method:'',
        code:'',
        postData:{
          bill_sn:'',
          file_id:[],
          uid:'',
          bank_id:'6'
        }
      }
    },
    methods : {
      handleAvatarSuccess(res, file) {
        if(res.errcode=='0'){
          this.postData.file_id.push(res.fileinfo.fid)
          this.imgList.push(URL.createObjectURL(file.raw))
        }else{
          this.$toast(res.errmsg)
        }
        this.$indicator.close();
      },
      beforeAvatarUpload(file) {
//        const isJPG = file.type === 'image/jpeg';
        const isLt5M = file.size / 1024 / 1024 < 5;
        if(file.type=='image/jpeg'||file.type=='image/jpg'||file.type=='image/png'||file.type=='image/bmp'){

        }else{
          this.$toast(this.$t('isImg'));
          return false
        }
        if (!isLt5M) {
          this.$toast(this.$t('is5MB'));
          return false
        }
        this.$indicator.open();
        return isLt5M;
      },
      imgDel(index){
        this.postData.file_id.splice(index,1)
        this.imgList.splice(index,1)
      },
      fuzhiClick(e){
        let self = this
        let ele = e.target;
        let clipboard = new Clipboard(ele);
        clipboard.on("success",function () {
          self.$toast({
            message: self.$t('copySuccess'),
            className:'bg'
          });
        });
        clipboard.on("error",function () {
          self.$toast(self.$t('copyError'));
        });
      },
      sub(){
        let self = this
        if(!self.postData.bill_sn){
          self.$toast(this.$t('isOrder'))
          return false
        }else if(self.imgList.length<=0){
          self.$toast(this.$t('upProve'))
          return false
        }else{
          self.$http.post(`${process.env.API.VIP}/vip/memberpaycertify`,self.postData).then(res=>{
            if(res.data.errcode=='0'){
              self.$toast({
                message: this.$t('subSuccess'),
                className:'bg'
              });
              setTimeout(()=>{
                self.$router.push('/')
              },2000)
            }
          }).catch(err=>{
            console.log(err)
          })
        }
      }
    },
    created(){
      document.title = this.$t('subProve')
    },
    mounted() {
      let self = this
      const clipboard = new Clipboard('.fuzhi')
      clipboard.on("success",function () {
        self.$toast({
          message: this.$t('copySuccess'),
          className:'bg'
        });
      });
      clipboard.on("error",function () {
        self.$toast(this.$t('copyError'));
      });

      self.postData.bill_sn = self.$fun.GetQueryString('id','ordershow')
      self.postData.uid = self.$fun.GetQueryString('uid','ordershow')
      self.pay_method = self.$fun.GetQueryString('pay_method','ordershow')
      self.code = self.$fun.GetQueryString('code','ordershow')

      self.$http.get(`${process.env.API.VIP}/vip/leveinfo?uid=${self.postData.uid}&code=${self.code}`).then(res => {
        if (res.data.errcode=='0') {
          self.orderInfo = res.data.data
        }
      }).catch(err => {
        console.log(err)
      })

    }
  }
</script>
<style lang="less" type="text/less" scoped>
  @media screen and (min-width: 410px) {
    .imgWrap{
      padding: 15px 15px 30px;
      background: #fff;
      .add{
        width: 90px!important;
        height: 90px!important;
      }
      ul{
        li{
          img{
            width: 90px!important;
            height: 90px!important;
            object-fit: cover;
          }
          span{
            img{
              width: 14px!important;
              height: 14px!important;
              border-radius: 50%!important;
            }
          }
        }
      }
    }
  }

  .order{
    .orderTit{
      margin: 10px 0;
      background: #fff;
      padding: 15px 15px 15px 0;
      .titFirst{
        display: flex;
        font-size: 14px;
        color: #333;
        padding: 15px;
        div{
          max-width: 230px;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          p{
            max-width: 230px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
          span{
            font-size: 20px;
          }
        }
        img{
          width: 105px;
          height: 65px;
          display: inline-block;
          margin-right: 15px;
          object-fit: cover;
        }
      }
      .titLast{
        height: 44px;
        line-height: 44px;
        padding-left:15px;
        p{
          display: flex;
          align-items: center;
          font-size: 14px;
          padding-right:15px;
          border-top: 1px solid #f2f2f2;
          color: #999;
          justify-content: space-between;
          span{
            color: #333;
          }
        }
      }
    }
    .orderMain{
      background: #fff;
      color: #333;
      padding-left: 15px;
      .orderMainTit{
        height: 44px;
        display: flex;
        align-items: center;
      }
      ul{
        li{
          border-top: 1px solid #f2f2f2;
          font-size: 14px;
          color: #333;
          display: flex;
          justify-content: space-between;
          height: 44px;
          align-items: center;
          flex-wrap: nowrap;
          padding-right: 5px;
          div{
            display: flex;
            align-items: center;
            p{
              font-size: 14px;
              color: #333;
              width: 120px;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
              display: block;
            }
            span{
              display: block;
              width: calc(~'100% - 100px');
            }
          }
          span{
            font-size: 12px;
            color: #999;
          }
        }
      }
    }
    .prove{
      margin-top: 10px;
      background:#fff;
      font-size: 14px;
      color: #333;
      padding-left: 15px;
      box-sizing: border-box;
      margin-bottom: 50px;
      p{
        height: 44px;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #f2f2f2;
        span{
          color: #999;
          font-size: 12px;
          display: block;
          &:first-child{
            max-width: 140px;
          }
          &:last-child{
            width: calc(~'100% - 140px');
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
      }
      .imgWrap{
        padding:15px 15px 0 0;
        min-height: 100px;
        display: flex;
        flex-wrap: wrap;
        ul{
          display: flex;
          flex-wrap: wrap;
          width: 100%;
          padding-bottom: 15px;
          li{
            box-sizing: border-box;
            position: relative;
            width: 25%;
            padding: 2px;
            span{
              position: absolute;
              right: 0;
              top: -7px;
              img{
                width: 14px;
                height: 14px;
                border-radius: 50%;
              }
            }
            img{
              width: 80px;
              height: 80px;
              object-fit: cover;
            }
          }
        }
        .imgShow{
          width: 80px;
          height: 80px;
          position: relative;
          img{
            width:80px;
            height: 80px;
          }
          input{
            height: 80px;
            width: 80px;
            position: absolute;
            left: 0;
            top:0;
            opacity: 0;
          }
        }
      }
    }
    .btn{
      position: fixed;
      width: 100%;
      height: 44px;
      line-height: 44px;
      background: #333;
      color: #fff;
      text-align: center;
      bottom: 0;
      left: 0;
      font-size: 16px;
    }
  }

</style>
<style lang="less">
  body{
    background: #ecf0f4;
    padding: 0;
  }
  //成功的toast样式
  .bg{
    background: rgba(3,3,3,0.6)!important;
  }
</style>

