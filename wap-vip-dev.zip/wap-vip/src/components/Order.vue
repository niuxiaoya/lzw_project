<template>
  <div class="order">
    <div class="main">
      <div class="mainTit">
        <img :src="orderInfo.icon_pic">
        <div>
          <p>{{orderInfo.name}}</p>
          <span>{{orderInfo.money}}</span>
        </div>
      </div>
    </div>
    <div class="pay">
      <div class="payTit">
        <p>{{$t('payMethod')}} </p>
        <span>（{{$t('isOfflinePayment')}}）</span>
      </div>
      <div class="payMain">
        <div class="firstMain">
          <img src="../assets/images/vip/detail/bank.png">
          <div>
            <p>{{$t('accounts')}}</p>
            <span>{{$t('accountsSwissTime')}}</span>
          </div>
        </div>
        <mt-radio
          title=""
          v-model="postData.pay_method"
          :options="[{label: ' ',value: '1' }]">
        </mt-radio>
      </div>
    </div>
    <div class="foo">
      <div>
        <span>{{$t('orderPrice')}}：</span>
        <span>{{orderInfo.money}}</span>
      </div>
      <p @click="sub">{{$t('submit')}}</p>
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        addressName: this.$t('choice'),
        uid: localStorage.getItem('userId'),
        orderInfo: {},
        postData: {
          code: '',
          pay_method: '1'
        },
        messageBtn :{
          message:this.$t('isLogin'),
          title:this.$t('prompt'),
          confirmButtonText:this.$t('confirm'),
          cancelButtonText:this.$t('cancel'),
          showCancelButton:true,
          showConfirmButton:true
        },
      }
    },
    methods: {
      sub() {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/realname`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        } else if (!self.postData.code) {
          self.$toast(this.$t('isOrder'))
          return false
        } else {
          self.$http.post(`${process.env.API.VIP}/vip/memberorder`, self.postData).then(res => {
            if (res.data.errcode == '0') {
              location.href = `${process.env.URL.VIP}/#/ordershow?id=${res.data.data}&pay_method=${self.postData.pay_method}&code=${self.postData.code}`
            } else {
              self.$messagebox.confirm(res.data.errmsg, this.$t('prompt')).then(action => {
                if (action == 'confirm') {
                  location.href = `${process.env.URL.USER}/#/orderlist?key=1`
                }
              })
            }
          }).catch(err => {
            console.log(err)
          })
        }
      }
    },
    created() {
      document.title = this.$t('inputOrder')
    },
    mounted() {
      let self = this
      self.postData.code = self.$fun.GetQueryString('code', 'order')

      if (self.postData.code) {
        self.$http.get(`${process.env.API.VIP}/vip/leveinfo?code=${self.postData.code}`).then(res => {
          if (res.data.errcode == '0') {
            self.orderInfo = res.data.data
          }
        }).catch(err => {
          console.log(err)
        })
      }
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .order {
    .address {
      background: #fff;
      margin: 10px 0;
      padding: 15px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 14px;
      .addressNone {
        display: flex;
        justify-content: space-between;
        width: 100%;
        span {
          color: #999;
          font-size: 12px;
          display: flex;
          align-items: center;
          img {
            width: 7px;
            height: 12px;
            margin-left: 10px;
          }
        }
      }
      .addressTrue {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        font-size: 14px;
        img {
          width: 7px;
          height: 12px;
          margin-left: 10px;
        }
        div {
          p {
            max-width: 280px;
            &:first-child {
              margin-bottom: 10px;
            }
            span {
              margin-left: 10px;
            }
          }
        }
      }

    }
    .main {
      background: #fff;
      padding-left: 15px;
      .mainTit {
        padding: 15px 15px 15px 0;
        display: flex;
        font-size: 14px;
        color: #333;
        border-bottom: 1px solid #f2f2f2;
        div {
          display: flex;
          width: calc(~'100% - 120px');
          flex-direction: column;
          justify-content: space-between;
          span {
            font-size: 20px;
          }
        }
        img {
          width: 105px;
          height: 65px;
          display: inline-block;
          margin-right: 15px;
          object-fit: cover;
        }
      }
      .mainFoo {
        padding-right: 15px;
        display: flex;
        justify-content: space-between;
        height: 44px;
        align-items: center;
        font-size: 14px;
        span {
          font-size: 12px;
          background: #ecf0f7;
          padding: 5px 20px;
          margin-left: 10px;
          &.active {
            background: #333;
            color: #fff;
          }
        }
      }
    }
    .pay {
      margin-top: 10px;
      background: #fff;
      padding-left: 15px;
      font-size: 14px;
      .payTit {
        height: 44px;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #f2f2f2;
        color: #666;
        p{
          max-width: 70px;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
        }
        span {
          color: #999;
          font-size: 12px;
          width: calc(~'100% - 70px');
          display: block;
        }
      }
      .payMain {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 15px 0;
        .firstMain {
          display: flex;
          align-items: center;
          div {
            display: flex;
            flex-direction: column;
            p {
              font-size: 14px;
              color: #666;
              margin-bottom: 5px;
            }
            span {
              max-width: 200px;
              font-size: 12px;
              color: #999;
            }
          }
          img {
            width: 49px;
            height: 37px;
            display: inline-block;
            margin-right: 15px;
          }
        }
      }
    }
    .foo {
      position: fixed;
      width: 100%;
      z-index: 999;
      bottom: 0;
      left: 0;
      display: flex;
      justify-content: space-between;
      border-top: 1px solid #f2f2f2;
      box-sizing: border-box;
      div{
        width: 50%;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        background: #fff;
        color: #999;
        span {
          color: #333;
          &:first-child{
            max-width: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
        }
      }
      p {
        width: 50%;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        background: #333;
        color: #fff;
      }
    }
  }
</style>
