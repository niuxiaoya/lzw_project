<template>

</template>
<script>
  export default {
    created() {
      let self = this
      if (self.$fun.GetQueryString('uid','login')){
        localStorage.setItem('userId', self.$fun.GetQueryString('uid','login'))
        localStorage.setItem('AccessToken', self.$fun.GetQueryString('AccessToken','login'))
        let uid =  localStorage.getItem('userId')
        let AccessToken =  localStorage.getItem('AccessToken')
        location.href = `${process.env.URL.MARKET}/#/login?uid=${uid}&AccessToken=${AccessToken}`
      }
    }
  }
</script>
