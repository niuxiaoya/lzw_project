<template>
  <div class="vip">
    <div class="vipNav">
      <p @click="popupClick(1)">{{locationName}} <img src="../assets/images/vip/down.png"></p>
      <p @click="popupClick(2)">{{levelName}}<img src="../assets/images/vip/down.png"></p>
    </div>
    <div class="main">
      <ul :class="{'no-data':vipList.list.length<=0}">
        <li v-for="item in vipList.list " @click="openDetail(item)">
          <div>
            <div class="wrapImg">
              <img :src="item.cover_pic">
            </div>
            <div class="tit">{{item.title}}</div>
            <p>{{item.price}}<span v-if="false">{{item.status_name}}</span></p>
            <div class="foo">
              <span>{{item.location}}</span>
              <span>{{item.pv}}{{$t('pv')}}</span>
            </div>
          </div>
        </li>
        <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="vipList.page.p>2">
            {{$t('noMore')}}
          </span>
          <span slot="no-results" v-show="vipList.page.p>2">
            {{$t('noMore')}}
          </span>
        </InfiniteLoading>
        <li style="height: 60px;width: 100%"></li>
      </ul>
    </div>
    <mt-popup v-model="popupVisible" position="top" class="mint-popup-2 btnPop">
      <ul>
        <li @click="locationClick()">{{$t('all')}}<img src="../assets/images/vip/ok.png" v-if="locationNum==100"></li>
        <li v-for="item,key in levelTop.location" @click="locationClick(item,key)">
          {{item.location}}<img src="../assets/images/vip/ok.png" v-if="key==locationNum">
        </li>
      </ul>
    </mt-popup>
    <mt-popup v-model="popupVisible1" position="top" class="mint-popup-2 btnPop">
      <ul>
        <li @click="levelClick()">{{$t('all')}}<img src="../assets/images/vip/ok.png" v-if="levelNum==100"></li>
        <li v-for="item,key in levelTop.level" @click="levelClick(item,key)">
          {{item.name}} <img src="../assets/images/vip/ok.png" v-if="key==levelNum">
        </li>
      </ul>
    </mt-popup>
  </div>
</template>

<script>
  const InfiniteLoading = () => import('vue-infinite-loading')

  export default {
    data() {
      let lang = localStorage.getItem('lang');
      if (lang) {
        this.$i18n.locale = lang
      }
      return {
        uid: localStorage.getItem('userId'),
        location: '',
        level: '',
        locationName: this.$t('experienceAll'),
        levelName: this.$t('levelName'),
        levelTop: {},
        popupVisible: false,
        popupVisible1: false,
        vipShow: true,
        levelNum: 100,
        locationNum: 100,
        vipList: {
          list: [],
          page: {
            p: 0,
            total_pages: 1
          }
        },
      }
    },
    methods: {
      onInfinite() {
        setTimeout(() => {
          this.vipList.page.p++
          if (this.vipList.page.p > this.vipList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          this.$http.get(`${process.env.API.MARKET}/market/buyer/memberwatchlist?location=${this.location}&level=${this.level}&p=${this.vipList.page.p}&rows=10`).then(res => {
            if (res.data.errcode == '0') {
              this.vipList.list = this.vipList.list.concat(res.data.data)
              this.vipList.page = res.data.page
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              if (this.vipList.page.p == 1 || this.vipList.page.p < 1) {
                this.vipShow = false
              }
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 300);
      },
      popupClick(index) {
        switch (index) {
          case 1:
            this.popupVisible = !this.popupVisible
            this.popupVisible1 = false
            break;
          case 2:
            this.popupVisible1 = !this.popupVisible1
            this.popupVisible = false
            break;
        }
      },
      levelClick(item, key) {
        let self = this
        self.levelNum = key
        this.popupVisible1 = !this.popupVisible1
        if (item) {
          self.level = item.code
          self.levelName = item.name
        } else {
          self.level = ''
          self.levelName = this.$t('levelName')
          self.levelNum = 100
        }
        //重新刷新数据
        self.vipShow = true
        self.vipList.page.p = 0
        self.vipList.list = []
        self.$nextTick(() => {
          self.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
        });
      },
      locationClick(item, key) {
        let self = this
        self.locationNum = key
        this.popupVisible = !this.popupVisible
        if (item && item.location) {
          self.location = item.hall_code
          self.locationName = item.location
        } else {
          self.location = ''
          self.locationName = this.$t('experienceAll')
          self.locationNum = 100
        }
        //重新刷新数据
        self.vipShow = true
        self.vipList.page.p = 0
        self.vipList.list = []
        self.$nextTick(() => {
          self.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
        });
      },
      openDetail(item) {
        location.href = `${process.env.URL.VIP}/#/watchdetail?id=${item.gid}`
      }
    },
    created() {
      localStorage.removeItem('bankInfo')
    },
    mounted() {
      let self = this
      self.$http.get(`${process.env.API.MARKET}/market/buyer/topsearch`).then(res => {
        if (res.data.errcode == '0') {
          self.levelTop = res.data.data
        } else {
          self.$messagebox.alert(res.data.errmsg)
        }
      }).catch(err => {
        console.log(err)
      })
    },
    components: {InfiniteLoading}//公共底部
  }
</script>
<!--当前页面样式-->
<style lang="less" scoped type="text/less">
  .vip {
    .btnPop {
      top: 44px;
      width: 100%;
      ul {
        padding-left: 15px;
        li {
          display: flex;
          align-items: center;
          height: 44px;
          border-bottom: 1px solid #f2f2f2;
          justify-content: space-between;
          padding-right: 15px;
        }
      }
    }
  }

  .vipNav {
    display: flex;
    height: 44px;
    width: 100%;
    align-items: center;
    background: #fff;
    box-sizing: border-box;
    border-bottom: 1px solid #f2f2f2;
    position: fixed;
    z-index: 5000;
    top: 0;
    left: 0;
    font-size: 14px;
    color: #666;
    p {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      img {
        width: 5px;
        height: 4px;
        margin-left: 5px;
      }
    }
  }

  .main {
    margin-top: 44px;
    height: calc(~'100vh - 44px');
    background: #fff;
    overflow-x: hidden;
    overflow-y: scroll;
    ul {
      display: flex;
      padding: 15px;
      flex-wrap: wrap;
      position: relative;
      li {
        width: 50%;
        box-sizing: border-box;
        font-size: 14px;
        margin-bottom: 10px;
        &:nth-child(2n-1) {
          padding-right: 7.5px;
        }
        &:nth-child(2n) {
          padding-left: 7.5px;
        }
        div {
          color: #333;
          .wrapImg {
            width: 165px;
            height: 165px;
            overflow: hidden;
            img {
              object-fit: cover !important;
              width: 100%;
              height: 100%;
            }
          }
          .tit {
            color: #666;
            font-size: 14px;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            margin-top: 10px;
          }
          p {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 16px;
            margin-top: 10px;
            span {
              background: #ecf0f4;
              padding: 0 5px;
              font-size: 12px;
              display: block;
            }
          }
          .foo {
            margin-top: 15px;
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #999;
          }
        }
      }
      .infinite-loading-container {
        width: 100%;
      }
    }
  }
</style>
<!--公共less样式-->
<style lang="less">

</style>
