<template>
  <div class="vip">
    <div v-html="vipInfo.description">

    </div>
    <!--<div class="banner">-->
      <!--<div class="bannerWrap">-->
        <!--<mt-swipe @change="handleChange" :auto="0" :show-indicators="false" :defaultIndex="bannerNum">-->
          <!--<mt-swipe-item v-for="item,index in vipInfo" :key="index">-->
            <!--<div class="imgWrap">-->
              <!--<img :src="item.icon_pic">-->
            <!--</div>-->
            <!--<div class="bannerTit" :class="{'fontColor':item.is_member_auth==2}">-->
              <!--<p v-if="item.is_member_auth==0||item.is_member_auth==3||item.is_member_auth==1&&item.is_member_name==''">-->
                <!--{{item.name}}：-->
                <!--<span>-->
                 <!--{{item.money}}-->
                <!--</span>-->
              <!--</p>-->
              <!--{{item.is_member_auth==1&&item.is_member_name!=''?$t('isAdd'):''||item.is_member_auth==2?$t('audit'):''}}-->
            <!--</div>-->
            <!--<div v-html="item.description" class="bannerMain">-->
            <!--</div>-->
            <!--<div style="width: 100%;height: 80px"></div>-->
          <!--</mt-swipe-item>-->
        <!--</mt-swipe>-->
      <!--</div>-->
    <!--</div>-->
    <!--<div class="subBtn">-->
      <!--<p class="kefu" @click="kefuClick">-->
        <!--<img src="../assets/images/vip/kefu.png">-->
        <!--<span>-->
          <!--{{$t('customerServiceTel')}}-->
        <!--</span>-->
      <!--</p>-->
      <!--<p class="buy" @click="buyClick(vipInfo[bannerNum])"-->
         <!--v-if="vipInfo[bannerNum].is_member_auth!=3&&vipInfo[bannerNum].is_member_auth!=2">-->
        <!--{{vipInfo[bannerNum].is_goods_name}}</p>-->
    <!--</div>-->
  </div>
</template>

<script>
  export default {
    data() {
      return {
        bannerNum: 0,
        vipInfo: {},
        isShow: false,
        messageBtn :{
          message:this.$t('isLogin'),
          title:this.$t('prompt'),
          confirmButtonText:this.$t('confirm'),
          cancelButtonText:this.$t('cancel'),
          showCancelButton:true,
          showConfirmButton:true
        },
      }
    },
    methods: {
      sethtml (html) {
        return html
          .replace(html ? /&(?!#?\w+;)/g : /&/g, '&amp;')
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
          .replace(/&quot;/g, "\"")
          .replace(/&#39;/g, "\'");
      },
      handleChange(index) {
        this.bannerNum = index
        switch (this.bannerNum) {
          case 0:
            document.title = this.$t('leve1')
            break;
          case 1:
            document.title = this.$t('leve2')
            break;
          case 2:
            document.title = this.$t('leve3')
            break;
        }
      },
      buyClick(item) {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if (this.vipInfo[this.bannerNum].is_member_auth == 1) {
          this.$router.push({name: 'Viplist', params: item})
        } else {
          this.$router.push({name: 'Protocol', params: item})
        }
      },
      kefuClick() {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        } else {
          location.href = `${process.env.URL.USER}/#/email`
        }
      }
    },
    created() {
      let self = this
      self.bannerNum = this.$route.params.key ? this.$route.params.key : 0
      switch (this.$route.params.key) {
        case 0:
          document.title = this.$t('leve1')
          break;
        case 1:
          document.title = this.$t('leve2')
          break;
        case 2:
          document.title = this.$t('leve3')
          break;
      }
      self.uid = localStorage.getItem('userId')
    },
    mounted() {
      let self = this
      self.$http.get(`${process.env.API.VIP}/vip/leveinfo?code=${this.$route.query.code}`).then(res => {
        if (res.data.errcode == '0') {
          self.vipInfo = res.data.data
          self.vipInfo.description = self.sethtml(self.vipInfo.description)
        }
      }).catch(err => {
        console.log(err)
      })
      setTimeout(() => {
        self.isShow = true
      }, 300)
    }
  }
</script>
<!--当前页面样式-->
<style lang="less" scoped type="text/less">
  .vip {
    background: #fff;
    img{
      width: 100%;
    }
  }

  /*.fontColor {*/
    /*color: #e9bf76 !important;*/
  /*}*/

  /*.banner {*/
    /*min-height: 100vh;*/
    /*overflow: scroll;*/
    /*.bannerWrap {*/
      /*padding-top: 15px;*/
      /*box-sizing: border-box;*/
      /*.mint-swipe {*/
        /*height: 100vh;*/
        /*min-height: 100vh;*/
        /*box-sizing: border-box;*/
        /*overflow: scroll;*/
        /*.imgWrap {*/
          /*padding: 0 15px;*/
          /*min-height: 220px;*/
          /*img {*/
            /*display: block;*/
            /*-webkit-box-sizing: border-box;*/
            /*box-sizing: border-box;*/
            /*width: 100% !important;*/
            /*height: 100%;*/
            /*border-radius: 10px;*/
            /*-o-object-fit: cover;*/
            /*object-fit: cover;*/
            /*-webkit-box-shadow: 10px 10px 5px #ccc;*/
            /*box-shadow: 0 3px 5px rgba(0, 0, 0, 0.3);*/
          /*}*/
        /*}*/
      /*}*/
    /*}*/
    /*.bannerTit {*/
      /*display: flex;*/
      /*justify-content: space-between;*/
      /*align-items: center;*/
      /*flex-direction: column;*/
      /*box-sizing: border-box;*/
      /*width: 100%;*/
      /*padding: 30px 0;*/
      /*position: relative;*/
      /*font-size: 20px;*/
      /*&:after {*/
        /*content: '';*/
        /*width: calc(~'100% - 15px');*/
        /*height: 1px;*/
        /*background: #f2f2f2;*/
        /*position: absolute;*/
        /*bottom: 0;*/
        /*right: 0;*/
      /*}*/
      /*p {*/
        /*display: flex;*/
        /*align-items: center;*/
        /*font-size: 16px;*/
        /*color: #333;*/
        /*span {*/
          /*font-size: 20px;*/
          /*color: #333;*/
        /*}*/
      /*}*/
    /*}*/
    /*.bannerMain {*/
      /*padding: 15px;*/
    /*}*/
  /*}*/

  /*.subBtn {*/
    /*width: 100%;*/
    /*height: 44px;*/
    /*display: flex;*/
    /*position: fixed;*/
    /*background: #fff;*/
    /*bottom: 0;*/
    /*left: 0;*/
    /*align-items: center;*/
    /*border-top: 1px solid #f2f2f2;*/
    /*p {*/
      /*flex: 1;*/
      /*font-size: 16px;*/
      /*display: flex;*/
      /*align-items: center;*/
      /*justify-content: center;*/
      /*&.kefu {*/
        /*color: #333;*/
        /*min-width: 50%;*/
        /*img {*/
          /*width: 23px;*/
          /*height: 23px;*/
          /*margin-right: 5px;*/
        /*}*/
        /*span{*/
          /*display: block;*/
          /*max-width: calc(~'100% - 50px');*/
          /*overflow: hidden;*/
          /*white-space: nowrap;*/
          /*text-overflow: ellipsis;*/
        /*}*/
      /*}*/
      /*&.buy {*/
        /*height: 100%;*/
        /*background: #333;*/
        /*color: #fff;*/
      /*}*/
    /*}*/
  /*}*/
</style>
<style lang="less" type="text/less">
  /*.bannerWrap {*/
    /*.mint-swipe-items-wrap {*/
      /*overflow: scroll !important;*/
    /*}*/
  /*}*/
</style>
