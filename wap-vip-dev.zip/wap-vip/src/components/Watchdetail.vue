<template>
  <div class="detail">
    <div class="head">
      <mt-swipe :show-indicators="false" @change="handleChange" :auto="0">
        <mt-swipe-item v-for="(item,key) in watchInfo.file_pic" :key="key"><img :src="item"></mt-swipe-item>
        <p class="num">{{swiperNum}}/{{watchInfo.file_pic ? watchInfo.file_pic.length : ''}}</p>
      </mt-swipe>
      <div class="wrap">
        <div class="tit">{{watchInfo.title}}</div>
        <div class="money">
          <p>{{watchInfo.price}} <span>原价：{{watchInfo.original_price}}</span></p>
          <span>{{watchInfo.pv}}次浏览</span>
        </div>
      </div>
    </div>
    <div class="address">
      <div class="time"><span>{{$t('goodsTime')}}</span><span>{{$t('location')}}：{{watchInfo.location}}</span></div>
      <div class="addressMain" @click='popShow = true'>
        <ul>
          <li>
            <img src="../assets/images/vip/detail/selected.png">
            {{$t('freeFreight')}}
          </li>
          <li>
            <img src="../assets/images/vip/detail/selected.png">
            {{$t('threeDays')}}
          </li>
          <li>
            <img src="../assets/images/vip/detail/selected.png">
            {{$t('authorityAppraisal')}}
          </li>
        </ul>
        <img class="arrow" src="../assets/images/vip/arrow.png">
      </div>
    </div>
    <div class="nav">
      <ul>
        <li @click="navNum=0" :class="{'active':navNum==0}">
          {{$t('commodity')}}
        </li>
        <li @click="navNum=1" :class="{'active':navNum==1}">
          {{$t('wearService')}}
        </li>
      </ul>
    </div>
    <div class="info" v-if="navNum==0">
      <div class="infoTit">{{$t('info')}}</div>
      <ul class="infoUl">
        <li><p>{{$t('brand')}}</p><span>{{watchInfo.brand_name}}</span></li>
        <li><p>{{$t('movement')}}</p><span>{{watchInfo.movement_name?watchInfo.movement_name:$t('no')}}</span></li>
        <li><p>{{$t('shape')}}</p><span>{{watchInfo.shape_name?watchInfo.shape_name:$t('no')}}</span></li>
        <li><p>{{$t('diameter')}}</p><span>{{watchInfo.diameter}}mm</span></li>
        <li><p>{{$t('material')}}</p><span>{{watchInfo.material_name?watchInfo.material_name:$t('no')}}</span></li>
        <li><p>{{$t('function_name')}}</p><span>{{watchInfo.function_name?watchInfo.function_name:$t('no')}}</span></li>
        <li><p>{{$t('condition')}}</p><span>{{watchInfo.fineness_name}}</span></li>
        <li><p>{{$t('releaseTime')}]}</p><span>{{watchInfo.publish_time}}</span></li>
      </ul>
    </div>
    <div class="describe" v-if="navNum==0">
      <div class="describeTit">{{$t('commodityInfo')}}</div>
      <div class="publisher"><p>{{$t('watchRelease')}}</p><span><img src="../assets/images/vip/detail/user.png">{{watchInfo.publish_user}}</span>
      </div>
      <div class="describeMain">
        <p>{{$t('commodityDescribe')}}</p>
        <span v-html="watchInfo.details"></span>
      </div>
    </div>
    <div class="service" v-if="navNum==1">
      <div class="serviceMain">
        <img src="../assets/images/bulid.png">
      </div>
    </div>
    <div style="width: 100%;height: 100px"></div>
    <mt-popup v-model="popShow" position="bottom" class="mint-popup-4" style="height: 320px!important;">
      <div class="wrap">
        <p><img src="../assets/images/vip/detail/selected.png">{{$t('freeFreight')}}</p>
        <span>{{$t('watchFreeFreight')}}</span>
      </div>
      <div class="wrap">
        <p><img src="../assets/images/vip/detail/selected.png">
          {{$t('threeDays')}}
        </p>
        <span> {{$t('isThreeDays')}}</span>
      </div>
      <div class="wrap">
        <p><img src="../assets/images/vip/detail/selected.png">{{authorityAppraisal}}</p>
        <span style="border: none;">
          {{$t('swisstimevipText')}}
        </span>
      </div>
    </mt-popup>
    <div class="foo" @click="kefuClick">
      <img src="../assets/images/vip/kefu.png">
      {{$t('customerServiceTel')}}
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        uid: '',
        navNum: 0,
        popShow: false,
        swiperNum: 1,
        watchInfo: {}
      }
    },
    methods: {
      sub(index) {
        let self = this
        if (!self.$store.state.userId || !localStorage.getItem('userId')) {
          self.$messagebox.confirm(this.$t('isLogin'),this.$t('prompt')).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        switch (index) {
          case 1:
            break;
          case 2:
            if (self.watchInfo.is_collect == 1) {
              self.$fun.deleteObj.delete_data(self, `${process.env.API.USER}/user/collect?collect_id=${self.watchInfo.gid}&publish_id=${self.watchInfo.user_uid}&type=goods`, '/user/collect')
            } else {
              self.$fun.postObj.post_data(self, `${process.env.API.USER}/user/collect`, {
                id: self.watchInfo.gid,
                publish_id: self.watchInfo.user_uid,
                type: 'goods',
                uid: self.uid
              }, '/user/collect')
            }
            setTimeout(() => {
              self.$fun.getObj.get_info(self, `${process.env.API.MARKET}/market/buyer/watchinfo?gid=${self.$fun.GetQueryString('id', 'detail')}`, '/market/buyer/watchinfo')
            }, 300)
            break;
          case 3:
            if (!self.$store.state.userId || !localStorage.getItem('userId')) {
              self.$messagebox.confirm(this.$t('isLogin'),this.$t('prompt')).then(action => {
                location.href = `${process.env.URL.USER}/#/login`
              }).catch(err => {
                console.log(err)
              })
            } else {
              self.$router.push(`/order?gid=${self.watchInfo.gid}&user_uid=${self.watchInfo.user_uid}`)
            }
            break;
        }
      },
      handleChange(index) {
        this.swiperNum = index + 1
      },
      kefuClick(){
        location.href = `${process.env.URL.USER}/#/email`
      }
    },
    created() {
      document.title = this.$t('commodity')
    },
    mounted() {
      let self = this
      self.uid = localStorage.getItem('userId')
      // 调用url参数方法
      if (self.$fun.GetQueryString('id', 'watchdetail')) {
        let id = self.$fun.GetQueryString('id', 'watchdetail')
        self.$http.get(`${process.env.API.MARKET}/market/buyer/memberwatchinfo?gid=${id}`).then(res => {
          if (res.data.errcode=='0') {
            self.watchInfo = res.data.manage
            self.watchInfo.file_pic = self.watchInfo.file_pic.split(',')
            self.watchInfo.publish_time = self.$moment(self.watchInfo.publish_time*1000).format('YYYY-MM-DD HH:mm:ss')
          }
        }).catch(err => {
          console.log(err)
        })
      } else {
        self.$messagebox.alert(this.$t('noOrder')).then((action) => {
          self.$router.push('/')
        })
      }

    }
  }
</script>
<style lang="less" scoped type="text/less">
  @media screen and (min-width: 410px) {
    .mint-swipe {
      height: 414px !important;
    }
  }

  .detail {
    .mint-swipe-items-wrap {
      min-height: 100% !important;
    }
    .head {
      color: #333;
      img {
        width: 100%;
        display: block;
        object-fit: cover;
      }
      .wrap {
        padding: 15px 15px 30px;
        background: #fff;
        .tit {
          font-size: 14px;
          margin-bottom: 30px;
        }
        .money {
          display: flex;
          justify-content: space-between;
          align-items: center;
          p {
            display: flex;
            align-items: center;
            font-size: 20px;
            span {
              margin-left: 15px;
            }
          }
          span {
            font-size: 12px;
            color: #999;
          }
        }
      }
    }
    .address {
      background: #fff;
      margin: 10px 0;
      padding-left: 15px;
      font-size: 12px;
      color: #999;
      .time {
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #f2f2f2;
        box-sizing: border-box;
        padding-right: 15px;
      }
      .addressMain {
        height: 44px;
        padding-right: 15px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        ul {
          display: flex;
          li {
            margin-right: 10px;
            display: flex;
            align-items: center;
            img {
              width: 12px;
              height: 12px;
              border-radius: 50%;
              margin-right: 8px;
            }
          }
        }
        .arrow {
          width: 7px;
          height: 12px;
        }
      }
    }
    .nav {
      background: #fff;
      height: 44px;
      display: flex;
      align-items: center;
      border-bottom: 1px solid #f2f2f2;
      ul {
        color: #666;
        font-size: 14px;
        display: flex;
        width: 100%;
        justify-content: center;
        align-items: center;
        height: 44px;
        li {
          position: relative;
          padding: 0 20px;
          height: 44px;
          line-height: 44px;
          &.active {
            color: #333;
          }
          &.active:before {
            content: '';
            position: absolute;
            bottom: 0;
            width: 20px;
            height: 3px;
            background: #333;
            left: calc(~'50% - 10px');
          }
        }
      }
    }
    .info {
      background: #fff;
      padding-left: 15px;
      margin-bottom: 10px;
      color: #333;
      font-size: 14px;
      .infoTit {
        height: 44px;
        line-height: 44px;
        box-sizing: border-box;
      }
      .infoUl {
        li {
          display: flex;
          font-size: 14px;
          padding: 15px 15px 15px 0;
          min-height: 44px;
          box-sizing: border-box;
          border-top: 1px solid #f2f2f2;
          p {
            color: #999;
            width: 110px;
          }
          span {
            color: #333;
            width: calc(~'100% - 110px');
            display: inline-block;
          }
        }
      }
    }
    .describe {
      color: #333;
      font-size: 14px;
      background: #fff;
      padding-left: 15px;
      .describeTit {
        height: 44px;
        line-height: 44px;
        box-sizing: border-box;
      }
      .publisher {
        color: #999;
        display: flex;
        align-items: center;
        height: 44px;
        border-top: 1px solid #f2f2f2;
        border-bottom: 1px solid #f2f2f2;
        p {
          width: 100px;
        }
        span {
          img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 5px;
          }
          display: flex;
          align-items: center;
        }
      }
      .describeMain {
        padding: 30px 15px 30px 0;
        box-sizing: border-box;
        word-break: break-all;
        p {
          color: #999;
          padding-bottom: 30px;
        }
      }
    }
    .shop {
      font-size: 14px;
      background: #fff;
      color: #333;
      padding-left: 15px;
      .shopWrap {
        .shopTit {
          height: 44px;
          line-height: 44px;
        }
        .shopMain {
          border-top: 1px solid #f2f2f2;
          padding: 0 15px 30px 0;
          p {
            padding: 30px 0;
          }
          img {
            width: 100%;
          }
        }
      }
    }
    .service {
      padding-left: 15px;
      background: #fff;
      font-size: 14px;
      p {
        height: 44px;
        line-height: 44px;
        border-bottom: 1px solid #f2f2f2;
      }
      .serviceMain {
        padding-right: 15px;
        div {
          padding: 30px 0;
        }
        img {
          width: 100%;
        }
      }
    }
    .foo{
      display: flex;
      height: 44px;
      align-items: center;
      justify-content: center;
      width: 100%;
      background: #fff;
      position: fixed;
      bottom: 0;
      left: 0;
      font-size: 16px;
      a{
        text-decoration: none;
        color: #333;
      }
      img{
        width: 23px;
        height: 23px;
        margin-right: 5px;
      }
    }
  }

  .mint-popup-4 {
    padding: 15px 0;
    box-sizing: border-box;
    .wrap {
      padding-top: 15px;
      padding-left: 15px;
      p {
        display: flex;
        align-items: center;
        img {
          width: 12px;
          height: 12px;
          margin-right: 15px;
        }
      }
      span {
        font-size: 12px;
        color: #999;
        padding: 15px 15px 15px 27px;
        width: 100%;
        display: block;
        box-sizing: border-box;
        border-bottom: 1px solid #f2f2f2;
      }
    }
  }

  .mint-swipe {
    position: relative;
    .num {
      position: absolute;
      bottom: 15px;
      right: 15px;
      width: 50px;
      height: 30px;
      font-size: 14px;
      background: rgba(3, 3, 3, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    height: 375px;
    color: #fff;
    font-size: 30px;
    text-align: center;
    margin-bottom: 0;
    img {
      width: 100%;
      height: 100%;
    }
  }
</style>
