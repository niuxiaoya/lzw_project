const Share = () => import('@/components/Share')

// 导出组件
export default {
  install: function (Vue) {
    Vue.component('publish-share', Share);    //  分享悬浮
  }
}
