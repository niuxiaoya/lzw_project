let config = require('./common')

module.exports = {
  NODE_ENV: '"production"',
  URL: config.prov_url,
  API: config.prov_api
}
