<template>
  <div class="friends">
    <div class="nav" v-show="!isSearch">
      <span @click="isSearch=!isSearch">
        <img src="../assets/images/friends/searchFriend.png">
      </span>
      <span>
        <img src="../assets/images/friends/phone.png" @click="postImg">
      </span>
    </div>
    <div class="search" v-show="isSearch">
      <div class="tit">
        <img class="" src="../assets/images/friends/search.png">
        <input type="text" :placeholder="$t('searchText')" v-model="keyword" @keyup.13="isShowSearch($event)">
        <img src="../assets/images/friends/close.png" @click="keyword=''" v-if="keyword!=''">
      </div>
      <span @click="isShowSearch">{{$t('confirm')}}</span>
    </div>
    <div class="hot">
      <div style="width: 100%;height: 44px"></div>
      <div class="hotNav" v-show="topNavShow">
        <ul>
          <li v-for="item in hotList.top_list" @click.stop="followClick(item)">
            <div :class="{'is_activity':item.is_activity==1,'is_new_date':item.have_data>0}">
              <img :src="item.avatar_pic?item.avatar_pic:require('../assets/images/friends/user.png')">
            </div>
            <p>{{item.username?item.username:item.tel}}</p>
          </li>
        </ul>
      </div>
      <no-more v-if="hotList.data.length<=0"></no-more>
      <ul class="main">
        <li class="mainLi" v-for="item,index in hotList.data">
          <div class="head">
            <div class="headLeft" @click.stop="followClick(item)">
              <div>
                <img :src="item.avatar_pic?item.avatar_pic:require('../assets/images/friends/user.png')">
              </div>
              <div>
                <p>{{item.username ? item.username : item.tel}}</p>
              </div>
            </div>
            <div class="headRight">
              <span></span>
              <span></span>
              <span></span>
              <select v-model="sel" @change.stop="selChange(item,index)" v-if="item.user_uid!=userInfo.uid">
                <option value="attention">{{item.relations==1?$t('attentionCancel'):$t('attention')}}</option>
                <option value="blacklist">{{$t('blackAdd')}}</option>
                <option value="jb">{{item.is_report==1?$t('isReport'):$t('report')}}</option>
                <option value="cancel">{{$t('cancel')}}</option>
              </select>
              <select v-model="sel" @change.stop="selChange(item,index)" v-if="item.user_uid==userInfo.uid">
                <option value="delete">{{$t('delete')}}</option>
                <option value="cancel">{{$t('cancel')}}</option>
              </select>
            </div>
          </div>
          <div class="content">
            <!--<ul v-if="item.kind==1" @click="detailClick(item)">-->
            <!--<li v-for="(el, index) in item.file_pic" :data-index="index">-->
            <!--<img :src="el" @click.stop="selectImg(index,key,item)">-->
            <!--</li>-->
            <!--</ul>-->
            <div class="banner" v-if="item.kind ==1" @click="detailClick(item)">
              <mt-swipe @change="handleChange" :auto="0" :show-indicators="false">
                <mt-swipe-item v-for="el,index in item.file_pic" :key="index">
                  <img :src="el">
                  <span class="bannerNum">{{index+1}}/{{item.file_pic?item.file_pic.length:0}}</span>
                </mt-swipe-item>
              </mt-swipe>
            </div>
            <div v-if="item.kind ==2" class="videoShow">
              <video controls :poster="item.cover_pic" class="videoMain" webkit-playsinline>
                <source :src="item.file_pic[0]" type="video/mp4">
              </video>
            </div>
            <div class="starDynamic" @click="detailClick(item)">
              <div class="dynamicStatus">
                <p>
                  <span :class="{'praiseActive':item.is_like==1}" @click.stop="likeClick(item)"></span>
                  <img src="../assets/images/friends/message.png" @click.stop="detailClick(item)">
                </p>
                <span class="star" @click.stop="starClick(item)" :class="{'starActive':item.is_collect==1}">
                </span>
              </div>
              <div class="dynamicContent">
                <p>{{item.like_num}}{{$t('like')}}</p>
                <P class="isContent" v-html="item.content">
                </P>
                <div class="comment">
                  <p>{{item.comment_num}}{{$t('comments')}}</p>
                  <span>{{item.publish_time}}</span>
                </div>
              </div>
            </div>
          </div>
        </li>
        <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="hotList.page.p>2">{{$t('noMore')}}</span>
          <span slot="no-results" v-show="hotList.page.p>2">{{$t('noMore')}}</span>
        </InfiniteLoading>
      </ul>
    </div>
    <toolbar></toolbar>
  </div>
</template>
<script>
  const InfiniteLoading = () => import('vue-infinite-loading')
  const toolbar = () => import('../components/toolbar')

  export default {
    data() {
      return {
        imageUrl: '',
        bannerNum: 1,
        keyword: '',
        bannerInfo: [],
        uid: '',
        isSearch: false,
        imgList: [],
        sel: '',
        topNavShow: false,
        messageBtn: {
          message: this.$t('isLogin'),
          title: this.$t('prompt'),
          confirmButtonText: this.$t('confirm'),
          cancelButtonText: this.$t('cancel'),
          showCancelButton: true,
          showConfirmButton: true
        },
        imgHead: `${process.env.API.USER}/user/upload`,
        hotList: {
          data: [],
          top_list: [],
          page: {
            p: 0,
            total_pages: 1
          }
        },
        userInfo: {},
        bankList: []
      }
    },
    methods: {
      appraisalClick() {
        let self = this
        if (!self.uid) {
          self.messageBtn.message = this.$t('isLogin')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        self.$router.push('/appraisal')
      },
      evaluationClick() {
        //跳转会籍
        location.href = `${process.env.URL.VIP}/#/`
      },
      selChange(item, index) {
        let self = this
        if (self.sel == 'cancel') {
          self.sel = ''
          return false
        } else if (!self.uid) {
          self.sel = ''
          self.messageBtn.message = this.$t('isLogin')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        } else if (self.sel == 'jb') {
          this.$http.post(`${process.env.API.FRIENDS}/friends/report`, {
            cid: item.cid,
            user_uid: item.user_uid
          }).then(res => {
            if (res.data.errcode == '0') {
              this.$toast(this.$t('reportSuccess'))
              item.is_report = 1
            } else {
              this.$toast(res.data.errmsg)
            }
            self.sel = ''
          }).catch(err => {
            this.$toast(err)
          })
          return false
        }
        if (self.sel == 'delete') {
          this.$http.delete(`${process.env.API.FRIENDS}/friends/trends?cid=${item.cid}`).then(res => {
            if (res.data.errcode == '0') {
              self.hotList.data.splice(index, 1)
            } else {
              this.$toast(res.data.errmsg)
            }
            self.sel = ''
          }).catch(err => {
            console.log(err)
          })
        } else if (self.sel == 'attention') {
          if (item.relations == 1) {
            self.messageBtn.message = self.$t('noAttention')
            self.$messagebox(self.messageBtn).then(action => {
              if (action == 'confirm') {
                this.$http.delete(`${process.env.API.FRIENDS}/friends/relations?type=${self.sel}&other_uid=${item.user_uid}`).then(res => {
                  if (res.data.errcode == '0') {
                    item.relations = 3
                    self.hotList = {
                      data: [],
                      page: {
                        p: 0,
                        total_pages: 1
                      },
                    }
                    this.$nextTick(() => {
                      this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
                    });
                  } else {
                    this.$toast(res.data.errmsg)
                  }
                  self.sel = ''
                }).catch(err => {
                  console.log(err)
                })
              } else {
                self.sel = ''
              }
            }).catch(err => {
              console.log(err)
            })
            return false
          } else {
            this.$http.post(`${process.env.API.FRIENDS}/friends/relations`, {
              type: self.sel,
              other_uid: item.user_uid
            }).then(res => {
              if (res.data.errcode == '0') {
                this.$toast(this.$t('attentionSuccess'))
                item.relations = 1
              } else {
                this.$toast(res.data.errmsg)
              }
              self.sel = ''
            }).catch(err => {
              console.log(err)
            })
          }
        } else if (self.sel == 'blacklist') {
          this.$http.post(`${process.env.API.FRIENDS}/friends/relations`, {
            type: self.sel,
            other_uid: item.user_uid
          }).then(res => {
            if (res.data.errcode == '0') {
              this.$toast(this.$t('blackListSuccess'))
            } else {
              this.$toast(res.data.errmsg)
            }
            self.sel = ''
          }).catch(err => {
            console.log(err)
          })
        }
        self.hotList = {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          },
        }
        this.$nextTick(() => {
          this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
        });
        self.$http.post(`${process.env.API.FRIENDS}/friends/relations`).then(res => {
          if (res.data.errcode == '0') {

          }
        }).catch(err => {
          console.log(err)
        })
      },
      selectImg(index, key, item) {
        document.body.style.height = '100vh'
        document.body.style.overflow = 'hidden'
        this.show = true
        this.imageIndex = index
        this.imgKey = key
      },
      followClick(item) {
        if (item && item.is_activity == 1) {
          location.href = `${process.env.URL.NEWS}/#/detail?article_id=${item.user_uid}`
        } else {
          location.href = `${process.env.URL.FRIENDS}/#/follow?id=${item.user_uid}`
        }
      },
      saveImg(index, key) {
        window.open(`${this.hotList.data[this.imgKey].file_pic[this.imageIndex]}?download=1&source=1`)
      },
      openSell() {
        let self = this
        if (!self.uid) {
          self.messageBtn.message = this.$t('isLogin')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if (self.userInfo && self.userInfo.is_auth != 1) {
          self.messageBtn.message = this.$t('isAuth')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/realname`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if (self.bankList.length <= 0) {
          self.messageBtn.message = this.$t('isBank')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.MARKET}/#/banklist`

            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        location.href = `${process.env.URL.MARKET}/#/sell`
      },
      handleChange(index) {
        this.bannerNum = index + 1
      },
      postImg() {
        let self = this
        if (!self.uid) {
          self.messageBtn.message = this.$t('isLogin')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
//        if(self.userInfo&&self.userInfo.is_auth!=1){
//          self.$messagebox.confirm('请先完成实名认证，再进行相应操作','提示').then(action=>{
//            if(action == 'confirm'){
//              location.href = `${process.env.URL.USER}/#/realname`
//            }
//          }).catch(err=>{
//            console.log(err)
//          })
//          return false
//        }
        location.href = `${process.env.URL.FRIENDS}/#/release`
      },
      isShowSearch() {
        let self = this
        self.isSearch = !self.isSearch
        if (!self.keyword) {
          return false
        } else {
          self.hotList = {
            data: [],
            page: {
              p: 0,
              total_pages: 1
            },
          }
          this.$nextTick(() => {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
          });
        }
      },
      likeClick(item) {
        let self = this
        let data = {
          type: 'circle',
          publish_uid: item.user_uid,
          like_id: item.cid
        }
        if (item.is_like == 1) {
          self.$http.delete(`${process.env.API.USER}/user/userlike?type=circle&publish_uid=${item.user_uid}&like_id=${item.cid}`).then(res => {
            if (res.data.errcode == '0') {
              item.is_like = 0
              item.like_num = item.like_num - 1
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          self.$http.post(`${process.env.API.USER}/user/userlike`, data).then(res => {
            if (res.data.errcode == '0') {
              item.is_like = 1
              item.like_num = item.like_num + 1
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      starClick(item) {
        let self = this
        if (!self.uid) {
          self.messageBtn.message = this.$t('isLogin')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        let data = {
          publish_uid: item.user_uid,
          collect_id: item.cid,
          type: 'circle'
        }
        if (item.is_collect == 1) {
          self.$http.delete(`${process.env.API.USER}/user/collect?type=circle&publish_uid=${item.user_uid}&collect_id=${item.cid}`).then(res => {
            if (res.data.errcode == '0') {
              item.is_collect = 0
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          self.$http.post(`${process.env.API.USER}/user/collect`, data).then(res => {
            if (res.data.errcode == '0') {
              item.is_collect = 1
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      detailClick(item) {
        this.$router.push({name:'Detail',query:{cid:item.cid}})
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.hotList.page.p > self.hotList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.hotList.page.p++
          self.$http.get(`${process.env.API.FRIENDS}/friends/trends?p=${self.hotList.page.p}&rows=5&keyword=${self.keyword}`).then(res => {
            if (res.data.errcode == '0') {
              for (let i = 0; i < res.data.data.length; i++) {
                res.data.data[i].file_pic = res.data.data[i].file_pic.split(',')
                res.data.data[i].file_fid_list = res.data.data[i].file_fid_list.split(',')
                res.data.data[i].source_pic = res.data.data[i].source_pic.split(',')
                res.data.data[i].publish_time = self.$moment(res.data.data[i].publish_time * 1000).format('YYYY-MM-DD HH:mm')
              }
              self.hotList.data = self.hotList.data.concat(res.data.data)
              self.hotList.top_list = res.data.top_list
              self.hotList.page = res.data.page
              if (res.data.page && res.data.page.new_data_sum > 0) {
                self.$toast({
                  message: `${self.$t('have')}${res.data.page.new_data_sum}${self.$t('newData')}`,
                  className: 'bg'
                });
              }
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 300)
      }
    },
    created() {
      document.title = 'SwissTime Club'
      let self = this
    },
    mounted() {
      let self = this
      self.uid = localStorage.getItem('userId')
      window.history.pushState('forward', null, `${process.env.URL.FRIENDS}/#/`); //在IE中必须得有这两行
      setTimeout(() => {
        self.userInfo = self.$store.state.userInfo
      }, 300)
      setTimeout(() => {
        self.topNavShow = true
      }, 500)
    },
    //获取底部组件
    components: {toolbar, InfiniteLoading}
  }
  //监听后退时间 只允许在当前页
  window.addEventListener("popstate", function (e) {
    if (window.history.state == 'forward') {
      location.reload()
    }
  }, false);
</script>
<style lang="less" scoped type="text/less">
  source {
    min-width: 100%;
    min-height: 100%;
    height: auto;
    width: auto;
  }

  html, body {
    -webkit-overflow-scrolling: touch;
  }

  @media screen and (max-width: 360px) {
    .content {
      ul {
        li {
          width: 108px !important;
          height: 108px !important;

        }
      }
    }
  }

  .hotNav {
    min-width: 100%;
    overflow: scroll;
    overflow-y: hidden;
    height: 90px;
    box-sizing: border-box;
    background: #fafafa;
    -webkit-overflow-scrolling: touch;
    display: flex;
    align-items: center;
    ul{
      display: flex;
      align-items: center;
      width: auto;
      overflow: scroll;
      li {
        width: 20%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin-right: 2%;
        min-width: 65px;
        /*&:first-child{*/
        /*div{*/
        /*border:none;*/
        /*}*/
        /*}*/
        div {
          width: 52px !important;
          height: 52px !important;
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 50% !important;
          border: 2px solid #333;
          position: relative;
          &.is_new_date{
            &:before{
              content: "";
              position: absolute;
              width: 8px;
              height: 8px;
              background: #ff6969;
              right: -5px;
              top: 0;
              border-radius: 50%;
            }
          }
          &.is_activity {
            border-color: #fafafa !important;
          }
          img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50% !important;
          }
        }
      }
    }
    p {
      max-width: 58px;
      overflow: hidden;
      white-space: nowrap;
      word-break: normal;
      text-overflow: ellipsis;
      font-size: 11px;
      margin-top: 5px;
      padding: 0 5px;
      box-sizing: border-box;
    }
  }

  .banner {
    position: relative;
    .mint-swipe {
      height: 375px;
      .mint-swipe-item {
        box-sizing: border-box;
      }
      img {
        width: 100% !important;
        height: 375px;
        object-fit: cover;
      }
    }
    .bannerNum {
      position: absolute;
      top: 15px;
      right: 15px;
      padding: 2px 8px;
      border-radius: 10px;
      background: rgba(3, 3, 3, 0.3);
      color: rgba(255, 255, 255, 0.9);
      font-size: 12px;
    }
    .bannerFoo {
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-sizing: border-box;
      p {
        display: flex;
        flex-direction: column;
        font-size: 16px;
        color: #333;
        span {
          margin-top: 5px;
          font-size: 12px;
          color: #666;
        }
      }
      span {
        font-size: 16px;
        color: #333;
      }
    }
  }

  .hide {
    position: absolute;
    left: 0;
    top: 0;
    opacity: 0;
    z-index: 1;
  }

  .nav {
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 15px;
    background: #fff;
    border-bottom: 1px solid #f2f2f2;
    box-sizing: border-box;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 999;
    span {
      position: relative;
      &:first-child {
        img {
          width: 19px;
          height: 19px;
        }
      }
      &:last-child {
        img {
          width: 22.5px;
          height: 20px;
        }
      }
    }
  }

  .search {
    height: 44px;
    display: flex;
    align-items: center;
    background: #fff;
    padding: 15px;
    box-sizing: border-box;
    border-bottom: 1px solid #f2f2f2;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 999;
    .tit {
      display: flex;
      align-items: center;
      flex-wrap: nowrap;
      background: #ecf0f4;
      flex: 2;
      padding: 0 15px 0 10px;
      height: 24px;
      box-sizing: border-box;
      img {
        width: 15px;
        font-size: 15px;
        margin-right: 5px;
        &:last-child {
          width: 7px;
          height: 7px;
        }
      }
      input {
        background-color: #ecf0f4 !important;
        height: 100%;
        width: 100%;
      }
    }
    span {
      font-size: 16px;
      color: #333;
      display: inline-block;
      margin-left: 15px;
    }
  }

  .entrance {
    width: 100%;
    display: flex;
    justify-content: space-between;
    padding: 15px 15px 30px;
    box-sizing: border-box;
    background: #fff;
    margin-bottom: 10px;
    .first {
      width: 45%;
      height: 170px;
      background: rgb(247, 247, 247);
      display: flex;
      align-items: center;
      flex-direction: column;
      justify-content: center;
      overflow: hidden;
      position: relative;
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .last {
      width: calc(~'55% - 2px');
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 170px;
      box-sizing: border-box;
      div {
        /*width: 192px;*/
        height: 84px;
        display: flex;
        align-items: center;
        box-sizing: border-box;
        justify-content: center;
        &:first-child {
          background: rgb(242, 252, 255);
        }
        &:last-child {
          background: rgb(255, 249, 228);
        }
        position: relative;
        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      }
    }
    p {
      position: absolute;
      color: #fff;
      font-size: 14px;
    }
  }

  .hot {
    .tit {
      font-size: 20px;
      color: #666;
      display: flex;
      flex-direction: column;
      height: 70px;
      justify-content: center;
      box-sizing: border-box;
      span {
        font-size: 12px;
        color: #999;
      }
    }
    .main {
      margin-bottom: 120px;
      .mainLi {
        box-sizing: border-box;
        background: #fff;
        .contenP {
          padding: 0 15px 15px;
          overflow: hidden;
          font-size: 14px;
          width: 100%;
          left: 0;
          top: 14px;
          z-index: 999;
          color: #333;
          text-overflow: ellipsis;
          white-space: nowrap;
          box-sizing: border-box;
        }
        .head {
          display: flex;
          box-sizing: border-box;
          align-items: center;
          justify-content: space-between;
          .headLeft {
            display: flex;
            align-items: center;
            height: 49px;
            width: 100%;
            div {
              &:first-child {
                padding: 0 15px;
                box-sizing: border-box;
                img {
                  width: 29px;
                  border-radius: 50%;
                  height: 29px;
                  object-fit: cover;
                }
              }
              &:last-child {
                font-size: 14px;
                color: #333;
                width: calc(~'100% - 60px');
                height: 100%;
                display: flex;
                align-items: center;
                span {
                  margin-top: 5px;
                  display: block;
                  font-size: 12px;
                  color: #999;
                }
                p {
                  font-weight: bold;
                }
              }
            }
          }
          .headRight {
            display: flex;
            align-items: center;
            position: relative;
            margin-right: 15px;
            select {
              opacity: 0;
              position: absolute;
              right: 0;
              top: calc(~'50% - 15px');
              max-width: 200px;
            }
            span {
              width: 5px;
              height: 5px;
              border-radius: 50%;
              background: #333;
              margin-left: 5px;
            }
          }
        }
        .content {
          ul {
            display: flex;
            flex-wrap: wrap;
            li {
              width: 113px;
              height: 113px;
              overflow: hidden;
              padding-right: 3px;
              padding-bottom: 3px;
              img {
                width: 100%;
                height: 100%;
                object-fit: cover;
              }
            }
          }
          .starDynamic {
            .dynamicStatus {
              padding: 12px 15px;
              display: flex;
              justify-content: space-between;
              align-items: center;
              p {
                display: flex;
                span {
                  display: block;
                  background-image: url("../assets/images/friends/praise.png");
                  background-repeat: no-repeat;
                  width: 25px;
                  height: 20px;
                  background-size: 23px 20px;
                  margin-right: 15px;
                  &.praiseActive {
                    background-image: url("../assets/images/friends/praiseActive.png");
                  }
                }
                img {
                  width: 22px;
                  height: 20px;
                }
              }
              .star {
                display: block;
                background-image: url("../assets/images/friends/detail/star.png");
                background-repeat: no-repeat;
                width: 25px;
                height: 20px;
                background-size: 23px 20px;
                margin-right: 10px;
                &.starActive {
                  background-image: url("../assets/images/friends/detail/starActive.png");
                }
              }
            }
            .dynamicContent {
              padding: 0 15px 30px;
              font-size: 14px;
              color: #333;
              p {
                &:first-child {
                  margin-bottom: 15px;
                }
                &.isContent {
                  overflow: hidden;
                  text-overflow: ellipsis;
                  word-break: break-all;
                  white-space: nowrap;
                  margin-bottom: 15px;
                }
              }
              .comment {
                font-size: 14px;
                color: #999;
                span {
                  font-size: 12px;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
<style lang="less" type="text/less">
  @media screen and (min-width: 410px) {
    .friends {
      .content {
        ul {
          li {
            width: 125px !important;
            height: 125px !important;
          }
        }
      }
      .mint-swipe {
        height: 414px !important;
        img {
          height: 100% !important;
        }
      }
    }
  }

  .videoShow {
    box-sizing: border-box;
    width: 100%;
    height: 250px;
    .videoMain {
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
  }
</style>
