import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/pages/Index'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index
    },
    {
      path: '/detail',
      name: 'Detail',
      component:resolve=>require(['@/components/Detail'],resolve)
    },
    {
      path: '/release',
      name: 'Release',
      component:resolve=>require(['@/components/Release'],resolve)
    },
    {
      path: '/comment',
      name: 'Comment',
      component:resolve=>require(['@/components/Comment'],resolve)
    },
    {
      path: '/appraisal',
      name: 'Appraisal',
      component:resolve=>require(['@/components/Appraisal'],resolve)
    },
    {
      path: '/logout',
      name: 'Logout',
      component:resolve=>require(['@/components/Logout'],resolve)
    },
    {
      path: '/login',
      name: 'Login',
      component:resolve=>require(['@/components/Login'],resolve)
    },
    {
      path: '/evaluation',
      name: 'Evaluation',
      component:resolve=>require(['@/components/Evaluation'],resolve)
    },
    {
      path: '/follow',
      name: 'Follow',
      component:resolve=>require(['@/components/Follow'],resolve)
    },
    {
      path: '/fans',
      name: 'Fans',
      component:resolve=>require(['@/components/Fans'],resolve)
    }
  ]
})
