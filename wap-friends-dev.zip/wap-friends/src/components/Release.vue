<template>
  <div class="fabu">
    <div class="text">
      <textarea rows="6" :placeholder="$t('sayText')" maxlength="300" v-model="postData.content">
      </textarea>
      <span>{{postData.content.length}}/300</span>
    </div>
    <div class="images">
      <ul>
        <li v-for="(item,index) in imgList">
          <img :src="item">
          <span @click.stop="imgDel(index)">
            <img src="../assets/images/friends/redClose.png">
          </span>
        </li>
        <li v-if="imgList.length<9">
          <el-upload
            class="avatar-uploader add"
            :action="imgHead"
            :headers="head"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
            :before-upload="beforeAvatarUpload">
            <img v-if="imageUrl" :src="imageUrl" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </li>
      </ul>
    </div>
    <div class="btn" @click="sub">
      {{$t('release')}}
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        img: require('../assets/images/no_data.png'),
        imgList: [],
        imageUrl: require('../assets/images/friends/detail/add.png'),
        imgHead: `${process.env.API.USER}/user/upload`,
        userInfo: {},
        head: {
          AccessToken: localStorage.getItem('AccessToken'),
          Authorization: localStorage.getItem('userId')
        },
        messageBtn :{
          message:this.$t('isLogin'),
          title:this.$t('prompt'),
          confirmButtonText:this.$t('confirm'),
          cancelButtonText:this.$t('cancel'),
          showCancelButton:true,
          showConfirmButton:true
        },
        postData: {
          file_fid_list: [],
          content: '',
          uid: localStorage.getItem('userId'),
          publish_status: 1,
          kind: 1
        }
      }
    },
    methods: {
      ok(data) {
        let $image = new Image();

        $image.src = data;
        $image.addEventListener('load', e => {
          console.log($image.width, $image.height);
        }, false);
      },
      handleAvatarSuccess(res, file) {
        if (res.errcode == '0') {
          this.postData.file_fid_list.push(res.fileinfo.fid)
          this.imgList.push(URL.createObjectURL(file.raw))
        } else{
          this.$toast(res.errmsg)
        }
        this.$indicator.close();
      },
      beforeAvatarUpload(file) {
        let self = this
        if (!self.postData.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        const isLt5M = file.size / 1024 / 1024 < 5;
        if (file.type == 'image/jpeg' || file.type == 'image/jpg' || file.type == 'image/png' || file.type == 'image/bmp') {

        } else {
          this.$toast(this.$t('isImg'));
          return false
        }
        if (!isLt5M) {
          this.$toast(this.$t('is5MB'));
          return false
        }
        this.$indicator.open();
        return isLt5M;
      },
      imgDel(index) {
        this.postData.file_fid_list.splice(index, 1)
        this.imgList.splice(index, 1)
      },
      sub() {
        let self = this
        if (!self.postData.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
//          if (self.userInfo.is_auth != 1) {
//            self.$messagebox.confirm('请先完成实名认证，再进行相应操作', '提示').then(action => {
//              if (action == 'confirm') {
//                location.href = `${process.env.URL.USER}/#/realname`
//              }
//            }).catch(err => {
//              console.log(err)
//            })
//            return false
//          }
        if (self.postData.file_fid_list.length <= 0) {
          self.$toast(this.$t('selImg'))
          return false
        }
        self.$indicator.open();
        if(self.$route&&self.$route.query.cid){
          setTimeout(() => {
            this.$http.put(`${process.env.API.FRIENDS}/friends/trends`, {file_fid_list:self.postData.file_fid_list,content:self.postData.content,cid:self.$route.query.cid, publish_status:1,kind:1}).then(res => {
              if (res.data.errcode == '0') {
                self.$toast({
                  message: this.$t('releaseSuccess'),
                  className: 'bg'
                });
                setTimeout(() => {
                  self.$indicator.close();
                  this.$router.push('/')
                }, 2000)
              }else{
                self.$toast(res.data.errmsg)
                self.$indicator.close();
              }
            }).catch(err => {
              self.$indicator.close();
              console.log(err)
            })
          }, 2000)
        }else{
          this.$http.post(`${process.env.API.FRIENDS}/friends/trends`, this.postData).then(res => {
            if (res.data.errcode == '0') {
              self.$toast({
                message: this.$t('releaseSuccess'),
                className: 'bg'
              });
              setTimeout(() => {
                self.$indicator.close();
                this.$router.push('/')
              }, 2000)
            }else{
              self.$toast(res.data.errmsg)
              self.$indicator.close();
            }
          }).catch(err => {
            self.$indicator.close();
            console.log(err)
          })
        }
      }
    },
    created() {
      document.title = this.$t('releaseDynamics')
      let self = this
      setTimeout(() => {
        self.userInfo = self.$store.state.userInfo
      }, 300)
    },
    watch: {
      'postData.content'() {
        if (this.postData.content.length > 300) {
          return false
        }
      }
    }
  }
</script>
<style lang="less" scoped type="text/less">
  @media screen and (min-width: 410px) {
    .images {
      padding: 15px 15px 30px;
      background: #fff;
      .add {
        width: 90px !important;
        height: 90px !important;
      }
      ul {
        li {
          span {
            img {
              width: 14px!important;
              height: 14px!important;
              border-radius: 50%;
            }
          }
          img {
            width: 90px !important;
            height: 90px !important;
            object-fit: cover;
          }
        }
      }
    }
  }

  .fabu {
    display: flex;
    flex-direction: column;
    .text {
      background: #fff;
      textarea {
        overflow: scroll;
        width: 100%;
        box-sizing: border-box;
        resize: none;
        border: none;
        padding: 15px;
        font-size: 14px;
      }
      span {
        width: 100%;
        text-align: right;
        display: block;
        font-size: 12px;
        color: #999;
        padding-right: 15px;
        box-sizing: border-box;
      }
    }
    .images {
      padding: 15px 15px 30px;
      background: #fff;
      .add {
        width: 75px;
        height: 75px;
      }
      ul {
        display: flex;
        flex-wrap: wrap;
        li {
          width: 25%;
          display: flex;
          justify-content: center;
          align-items: center;
          margin-bottom: 10px;
          position: relative;
          span {
            position: absolute;
            right: 0;
            top: -7px;
            img {
              width: 14px;
              height: 14px;
              border-radius: 50%;
            }
          }
          img {
            width: 75px;
            height: 75px;
            object-fit: cover;
          }
        }
      }
    }
    .btn {
      width: 100%;
      height: 44px;
      line-height: 44px;
      background: #333;
      color: #fff;
      position: fixed;
      bottom: 0;
      left: 0;
      text-align: center;
    }
  }
</style>
