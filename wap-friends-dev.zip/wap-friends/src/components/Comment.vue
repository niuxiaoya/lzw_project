<template>
  <div class="comment">
    <div class="tit" @click.stop="messageClick(info)">
      <div>
        <img :src="info.avatar_pic?info.avatar_pic:require('../assets/images/friends/user.png')">
        <p>{{info.comment_username?info.comment_username:info.tel}} <span>{{info.create_time}}</span></p>
      </div>
      <div>
        <img src="../assets/images/friends/message.png">
        <p :class="{'praiseActive':info.is_like==1}" class="praise" @click="titLikeClick(info)"><span></span>{{info.like_num}}</p>
      </div>
    </div>
    <div class="content">
      {{info.content}}
    </div>
    <div class="message">
      <ul>
        <li v-for="item in messageList.data">
          <div class="tit messageTit" @click.stop="messageClick(item)">
            <div>
              <img :src="item.avatar_pic?item.avatar_pic:require('../assets/images/friends/user.png')">
              <p>{{item.comment_username?item.comment_username:item.tel}} <span>{{item.create_time}}</span></p>
            </div>
            <div>
              <img src="../assets/images/friends/message.png">
              <p @click="lickClick(item)" class="praise" :class="{'praiseActive':item.is_like==1}" ><span></span>{{item.like_num}}</p>
            </div>
          </div>
          <div class="messageMain" v-if="item.target_username">
            {{$t('reply')}} <span>{{item.target_username}}：</span>{{item.content}}
          </div>
          <div class="messageMain" v-if="!item.target_username">
            {{item.content}}
          </div>
        </li>
        <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="messageList.page.p>2">{{$t('noMore')}}</span>
          <span slot="no-results" v-show="messageList.page.p>2">{{$t('noMore')}}</span>
        </InfiniteLoading>
      </ul>
    </div>
    <div class="sub">
      <input type="text" v-model="postData.content" :placeholder="defaultText" ref="ipt">
      <span @click.stop="sub">
        <!--{{$t('release')}}-->
        <img src="../assets/images/friends/release.png">
      </span>
    </div>
  </div>
</template>
<script>
  import InfiniteLoading from 'vue-infinite-loading';
  export default {
    data(){
      return{
        info:{},
        defaultText:this.$t('sayText'),
        uid:localStorage.getItem('userId'),
        bannerInfo:{},
        messageList:{
          data:[],
          page:{
            p:0,
            total_pages:1
          }
        },
        postData:{
          content:'',
          ccid:'',//楼id
          target_uid:'',//楼主id
        },
      }
    },
    methods:{
      messageClick(item){
        let self = this
        self.postData.target_uid = item.comment_uid
        self.defaultText = `${this.$t('reply')}：${item.comment_username?item.comment_username:item.tel}`
        this.$refs.ipt.select()
      },
      lickClick(item){
        let self = this
        let data = {
          type:'circle_discuss',
          publish_uid:item.comment_uid,
          like_id:item.did
        }
        if(item.is_like==1){
          self.$http.delete(`${process.env.API.USER}/user/userlike?type=circle_discuss&publish_uid=${item.comment_uid}&like_id=${item.did}`).then(res=>{
            if(res.data.errcode=='0'){
              item.is_like=0
              item.like_num=item.like_num-1
            }
          }).catch(err=>{
            console.log(err)
          })
        }else{
          self.$http.post(`${process.env.API.USER}/user/userlike`,data).then(res=>{
            if(res.data.errcode=='0'){
              item.is_like=1
              item.like_num=item.like_num+1
            }
          }).catch(err=>{
            console.log(err)
          })
        }
      },
      titLikeClick(item){
        let self = this
        let data = {
          type:'circle_comment',
          publish_uid:item.comment_uid,
          like_id:item.ccid
        }

        if(item.is_like==1){
          self.$http.delete(`${process.env.API.USER}/user/userlike?type=circle_comment&publish_uid=${item.comment_uid}&like_id=${item.ccid}`).then(res=>{
            if(res.data.errcode=='0'){
              item.is_like=0
              item.like_num=item.like_num-1
            }
          }).catch(err=>{
            console.log(err)
          })
        }else{
          self.$http.post(`${process.env.API.USER}/user/userlike`,data).then(res=>{
            if(res.data.errcode=='0'){
              item.is_like=1
              item.like_num=item.like_num+1
            }
          }).catch(err=>{
            console.log(err)
          })
        }
      },
      sub(){
        let self  = this
        if(!self.postData.content){
          self.$toast(this.$t('isContent'))
          return false
        }
        self.$http.post(`${process.env.API.FRIENDS}/friends/comment`,self.postData).then(res=>{
          if(res.data.errcode=='0'){
            self.$http.get(`${process.env.API.FRIENDS}/friends/discuss?ccid=${self.info.circle_comment_ccid||self.info.ccid}&rows=10`).then(res=>{
              self.messageList.page = res.data.page
              for (let i=0;i<res.data.data.length;i++){
                res.data.data[i].create_time = this.$moment(res.data.data[i].create_time * 1000).format('YYYY-MM-DD HH:mm')
                res.data.data[i].tel = `${res.data.data[i].tel.substring(0,3)}****${res.data.data[i].tel.substring(res.data.data[i].tel.length-4)}`
              }
              self.messageList.data = []
              self.messageList.data =  self.messageList.data.concat(res.data.data)
              self.postData.content = ''
            }).catch(err=>{
              console.log(err)
            })
          }else{
            self.$messagebox.alert(res.data.errmsg)
          }
        }).catch(err=>{
          console.log(err)
        })
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.messageList.page.p > self.messageList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.messageList.page.p++
          self.$http.get(`${process.env.API.FRIENDS}/friends/discuss?ccid=${self.info.circle_comment_ccid||self.info.ccid}&p=${self.messageList.page.p}&rows=10`).then(res=>{
            if(res.data.errcode=='0'){
              self.messageList.page = res.data.page
              for (let i=0;i<res.data.data.length;i++){
                res.data.data[i].create_time = this.$moment(res.data.data[i].create_time * 1000).format('YYYY-MM-DD HH:mm')
                res.data.data[i].tel = `${res.data.data[i].tel.substring(0,3)}****${res.data.data[i].tel.substring(res.data.data[i].tel.length-4)}`
              }
              self.messageList.data =  self.messageList.data.concat(res.data.data)
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            }else{
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            }

          }).catch(err=>{
            console.log(err)
          })
        }, 300);
      }
    },
    created(){
      let self = this
      self.info = this.$route.params
      if(!self.info.comment_uid){
        self.$router.push('/')
      }

      self.postData.ccid = self.info.ccid||self.info.circle_comment_ccid
      self.postData.target_uid = self.info.comment_uid
    },
    mounted(){
      let self = this
      this.$refs.ipt.select()
      self.defaultText = `${this.$t('reply')}：${self.info.comment_username?self.info.comment_username:self.info.tel}`
      document.title = `${self.info.discuss_num}${this.$t('comment')}`
    },
    components: {
      InfiniteLoading:InfiniteLoading
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .comment{
    height: 100vh;
    overflow-y: scroll;
  }
  .tit{
    width: 100%;
    display: flex;
    justify-content: space-between;
    padding: 15px;
    background: #fff;
    box-sizing: border-box;
    align-items: center;
    div{
      &:first-child{
        display: flex;
        img{
          width: 40px;
          height: 40px;
          border-radius: 50%;
          margin-right: 10px;
        }
        p{
          font-size: 14px;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          color: #333;
          span{
            font-size: 12px;
            color: #999;
          }
        }
      }
      &:last-child{
        display: flex;
        align-items: center;
        color: #999;
        .praise{
          display: flex;
          align-items: center;
          &.praiseActive {
            color: #333;
            span{
              background-image: url("../assets/images/friends/praiseActive.png");
            }
          }
          span {
            width: 14px;
            height: 12px;
            background-image: url("../assets/images/friends/praise.png");
            display: block;
            background-repeat: no-repeat;
            background-size: 13px 12px;
            margin-right: 5px;
          }
        }
        img{
          width: 10px;
          height: 10px;
          display: block;
          margin-right: 20px;
        }
      }
    }
  }
  .content{
    padding:0  15px 15px;
    background: #fff;
    font-size: 12px;
    color: #333;
  }
  .message{
    margin-bottom: 80px;
    ul{
      padding-left:15px;
      li{
        border-bottom: 1px solid #e6e6e6;
        box-sizing: border-box;
        .messageTit{
          background: #ecf0f4;
          padding: 15px 15px 15px 0;
        }
        .messageMain{
          padding: 0 15px 15px 0;
          font-size: 12px;
          color: #666;
          span{
            color: #333;
          }
        }
      }
    }
  }

  .sub {
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: space-between;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 50px;
    border-top: 1px solid #f2f2f2;
    box-sizing: border-box;
    background: #fff;
    padding: 0 15px;
    input {
      width: calc(~'100% - 35px');
      height: 30px;
      background: #ecf0f4;
      padding-left: 15px;
      font-size: 14px;
      box-sizing: border-box;
    }
    span {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      img{
        width: 25px;
      }
    }
  }

</style>
