<template>
  <div class="follow">
    <div class="userInfo">
      <div class="user">
        <img :src="info.avatar_pic?info.avatar_pic:require('../assets/images/friends/user.png')">
        <div>
          {{info.username?info.username:info.tel}}
          <p v-if="info.is_auth==1">
            <img src="../assets/images/friends/real.png">
            {{$t('auth')}}
          </p>
        </div>
      </div>
      <div class="isFollow" @click="isFollow(info)" :class="{'active':relations==1}" v-if="btnShow">
        {{relations==1?$t('attentionCancel'):$t('attention')}}
      </div>
    </div>
    <div class="followInfo">
      <div @click="isPosts">
        {{info.circle_num}}
        <span>{{$t('posts')}}</span>
      </div>
      <div @click="isFans(1)">
        {{info.fans_num}}
        <span>{{$t('fans')}}</span>
      </div>
      <div @click="isFans(2)">
        {{info.attention_num}}
        <span>{{$t('attention')}}</span>
      </div>
    </div>
    <div style="position: relative">
      <no-more v-if="hotList.data.length<=0"></no-more>
    </div>
    <ul class="main">
      <li class="mainLi" v-for="item,index in hotList.data">
        <div class="head">
          <div class="headLeft">
            <div @click.stop="followClick(item)">
              <img :src="item.avatar_pic?item.avatar_pic:require('../assets/images/friends/user.png')">
            </div>
            <div @click="detailClick(item)">
              <p>{{item.username ? item.username : item.tel}}</p>
            </div>
          </div>
          <div class="headRight">
            <span></span>
            <span></span>
            <span></span>
            <select v-model="sel" @change.stop="selChange(item,index)" v-if="btnShow">
              <option value="attention">{{item.relations==1?$t('attentionCancel'):$t('attention')}}</option>
              <option value="blacklist">{{item.relations==2?$t('blackListRemove'):$t('blackAdd')}}</option>
              <option value="jb">{{item.is_report==1?$t('isReport'):$t('report')}}</option>
              <option value="cancel">{{$t('cancel')}}</option>
            </select>
            <select v-model="sel" @change.stop="selChange(item,index)" v-if="!btnShow">
              <option value="delete">{{$t('delete')}}</option>
              <option value="cancel">{{$t('cancel')}}</option>
            </select>
          </div>
        </div>
        <div class="content">
          <!--<ul v-if="item.kind==1" @click="detailClick(item)">-->
          <!--<li v-for="(el, index) in item.file_pic" :data-index="index">-->
          <!--<img :src="el" @click.stop="selectImg(index,key,item)">-->
          <!--</li>-->
          <!--</ul>-->
          <div class="banner" v-if="item.kind ==1" @click="detailClick(item)">
            <mt-swipe @change="handleChange" :auto="0" :show-indicators="false">
              <mt-swipe-item v-for="el,index in item.file_pic" :key="index">
                <img :src="el">
                <span class="bannerNum">{{index+1}}/{{item.file_pic?item.file_pic.length:0}}</span>
              </mt-swipe-item>
            </mt-swipe>
          </div>
          <div v-if="item.kind ==2" class="videoShow">
            <video controls :poster="item.cover_pic" class="videoMain" webkit-playsinline>
              <source :src="item.file_pic[0]" type="video/mp4">
            </video>
          </div>
          <div class="starDynamic">
            <div class="dynamicStatus" @click="detailClick(item)">
              <p>
                <span :class="{'praiseActive':item.is_like==1}" @click.stop="likeClick(item)"></span>
                <img src="../assets/images/friends/message.png" @click.stop="detailClick(item)">
              </p>
              <span class="star" @click.stop="starClick(item)" :class="{'starActive':item.is_collect==1}">
                </span>
            </div>
            <div class="dynamicContent">
              <p>{{item.like_num}}{{$t('like')}}</p>
              <P class="isContent">
                {{item.content}}
              </P>
              <div class="comment">
                <p>{{item.comment_num}}{{$t('comments')}}</p>
                <span>{{item.publish_time}}</span>
              </div>
            </div>
          </div>
        </div>
      </li>
      <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
        <span slot="no-more" v-show="hotList.page.p>2">{{$t('noMore')}}</span>
        <span slot="no-results" v-show="hotList.page.p>2">{{$t('noMore')}}</span>
      </InfiniteLoading>
    </ul>
  </div>
</template>
<script>
  const InfiniteLoading = () => import('vue-infinite-loading')
  export default {
    data(){
      return{
        sel:'',
        uid:'',
        user_uid:'',
        btnShow:false,
        info:{},
        userInfo:{},
        relations:null,
        messageBtn :{
          message:this.$t('isLogin'),
          title:this.$t('prompt'),
          confirmButtonText:this.$t('confirm'),
          cancelButtonText:this.$t('cancel'),
          showCancelButton:true,
          showConfirmButton:true
        },
        hotList: {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          }
        }
      }
    },
    methods:{
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.hotList.page.p > self.hotList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.hotList.page.p++
          self.$http.get(`${process.env.API.FRIENDS}/friends/userpublish?other_uid=${self.user_uid}&p=${self.hotList.page.p}&rows=5`).then(res => {
            if (res.data.errcode == '0') {
              for (let i = 0; i < res.data.data.length; i++) {
                res.data.data[i].file_pic = res.data.data[i].file_pic.split(',')
                res.data.data[i].file_fid_list = res.data.data[i].file_fid_list.split(',')
                res.data.data[i].source_pic = res.data.data[i].source_pic.split(',')
                res.data.data[i].publish_time = self.$moment(res.data.data[i].publish_time * 1000).format('YYYY-MM-DD HH:mm')
              }
              self.hotList.data = self.hotList.data.concat(res.data.data)
              self.hotList.page = res.data.page
              self.info = res.data.userinfo
              document.title = self.info.username?self.info.username:self.info.tel
              self.relations = res.data.relations
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
              self.userInfo.uid==self.info.uid?self.btnShow = false:self.btnShow = true
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        },500)
      },
      isPosts(){
        window.scrollTo(0,178);
      },
      selChange(item) {
        let self = this
        if (!self.uid) {
          self.sel = ''
          self.messageBtn.message = this.$t('isLogin')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if(self.sel=='cancel'){
          self.sel = ''
          return false
        }else if(self.sel=='jb'){
          this.$http.post(`${process.env.API.FRIENDS}/friends/report`,{cid:item.cid,user_uid:item.user_uid}).then(res=>{
            if(res.data.errcode=='0'){
              this.$toast(this.$t('reportSuccess'))
              item.is_report = 1
            }else{
              this.$toast(res.data.errmsg)
            }
            self.sel = ''
          }).catch(err=>{
            this.$toast(err)
          })
          return false
        }
        if(self.sel == 'delete'){
          this.$http.delete(`${process.env.API.FRIENDS}/friends/trends?cid=${item.cid}`).then(res=>{
            self.sel = ''
            if(res.data.errcode=='0'){
              self.hotList.data.splice(index,1)
            }else{
              this.$toast(res.data.errmsg)
            }
          }).catch(err=>{
            console.log(err)
          })
        }else if(self.sel=='attention'){
          if(item.relations==1){
            self.messageBtn.message = self.$t('noAttention')
            self.$messagebox(self.messageBtn).then(action => {
              if (action == 'confirm') {
                this.$http.delete(`${process.env.API.FRIENDS}/friends/relations?type=${self.sel}&other_uid=${item.user_uid}`).then(res=>{
                  if(res.data.errcode=='0'){
                    item.relations=3
                    self.hotList = {
                      data: [],
                      page: {
                        p: 0,
                        total_pages: 1
                      },
                    }
                    this.$nextTick(() => {
                      this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
                    });
                  }else{
                    this.$toast(res.data.errmsg)
                  }
                  self.sel = ''
                }).catch(err=>{
                  console.log(err)
                })
              }else{
                self.sel = ''
              }
            }).catch(err => {
              console.log(err)
            })
            return false
          }else{
            this.$http.post(`${process.env.API.FRIENDS}/friends/relations`,{type:self.sel,other_uid:item.user_uid}).then(res=>{
              if(res.data.errcode=='0'){
                this.$toast(this.$t('attentionSuccess'))
              }else{
                this.$toast(res.data.errmsg)
              }
              self.sel = ''
            }).catch(err=>{
              console.log(err)
            })
          }
        }else if(self.sel=='blacklist'){
          if(item.relations==2){
            this.$http.delete(`${process.env.API.FRIENDS}/friends/relations`,{params:{type:self.sel,other_uid:item.user_uid}}).then(res=>{
              if(res.data.errcode=='0'){
                this.$toast(this.$t('blackListRemove'))
              }else{
                this.$toast(res.data.errmsg)
              }
              self.sel = ''
            }).catch(err=>{
              console.log(err)
            })
          }else{
            this.$http.post(`${process.env.API.FRIENDS}/friends/relations`,{type:self.sel,other_uid:item.user_uid}).then(res=>{
              if(res.data.errcode=='0'){
                this.$toast(this.$t('blackListSuccess'))
              }else{
                this.$toast(res.data.errmsg)
              }
              self.sel = ''
            }).catch(err=>{
              console.log(err)
            })
          }
        }
        self.hotList = {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          },
        }
        this.$nextTick(() => {
          this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
        });
      },
      handleChange(index) {
        this.bannerNum = index + 1
      },
      followClick(item) {
        location.href = `${process.env.URL.FRIENDS}/#/follow?id=${item.user_uid}`
      },
      isFans(index){
        let self = this
        location.href = `${process.env.URL.FRIENDS}/#/fans?key=${index}&other_uid=${self.user_uid}`
      },
      isFollow(item){
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if(self.relations==1){
          self.messageBtn.message = self.$t('noAttention')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              this.$http.delete(`${process.env.API.FRIENDS}/friends/relations?type=attention&other_uid=${self.user_uid}`).then(res=>{
                if(res.data.errcode=='0'){
                  item.relations=3
                  self.hotList = {
                    data: [],
                    page: {
                      p: 0,
                      total_pages: 1
                    },
                  }
                  this.$nextTick(() => {
                    this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
                  });
                }else{
                  this.$toast(res.data.errmsg)
                }
                self.sel = ''
              }).catch(err=>{
                console.log(err)
              })
            }else{
              self.sel = ''
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }else{
          this.$http.post(`${process.env.API.FRIENDS}/friends/relations`,{type:'attention',other_uid:self.user_uid}).then(res=>{
            if(res.data.errcode=='0'){
              this.$toast(this.$t('attentionSuccess'))
              self.relations=1
            }else{
              this.$toast(res.data.errmsg)
            }
          }).catch(err=>{
            console.log(err)
          })
        }
        self.hotList = {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          },
        }
        this.$nextTick(() => {
          this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
        });
      },
      likeClick(item) {
        let self = this
        let data = {
          type: 'circle',
          publish_uid: item.user_uid,
          like_id: item.cid
        }
        if (item.is_like == 1) {
          self.$http.delete(`${process.env.API.USER}/user/userlike?type=circle&publish_uid=${item.user_uid}&like_id=${item.cid}`).then(res => {
            if (res.data.errcode == '0') {
              item.is_like = 0
              item.like_num = item.like_num - 1
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          self.$http.post(`${process.env.API.USER}/user/userlike`, data).then(res => {
            if (res.data.errcode == '0') {
              item.is_like = 1
              item.like_num = item.like_num + 1
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      starClick(item) {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        let data = {
          publish_uid: item.user_uid,
          collect_id: item.cid,
          type: 'circle'
        }
        if(item.is_collect==1){
          self.$http.delete(`${process.env.API.USER}/user/collect?type=circle&publish_uid=${item.user_uid}&collect_id=${item.cid}`).then(res => {
            if (res.data.errcode == '0') {
              item.is_collect = 0
            }
          }).catch(err => {
            console.log(err)
          })
        }else{
          self.$http.post(`${process.env.API.USER}/user/collect`, data).then(res => {
            if (res.data.errcode == '0') {
              item.is_collect = 1
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      detailClick(item) {
        location.href = `${process.env.URL.FRIENDS}/#/detail?cid=${item.cid}`
      },
    },
    mounted(){
      let self = this
      self.user_uid = this.$fun.GetQueryString('id', 'follow')
      self.uid = localStorage.getItem('userId')
      setTimeout(()=>{
        self.userInfo = this.$store.state.userInfo
      },300)
    },
    components: {toolbar, InfiniteLoading}
  }
</script>
<style type="text/less" lang="less" scoped>
  .follow{
    .userInfo{
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: #fff;
      padding: 25px 15px;
      box-sizing: border-box;
      position: relative;
      &:before{
        position: absolute;
        content: '';
        bottom: 0;
        left: 15px;
        width: calc(~'100% - 30px');
        height: 1px;
        background: #f2f2f2;
      }
      .user{
        display: flex;
        align-items: center;
        img{
          width: 60px;
          height: 60px;
          display: block;
          margin-right: 15px;
          border-radius: 50%;
          object-fit: cover;
        }
        div{
          font-size: 20px;
          color: #333;
          p{
            font-size: 12px;
            color: #666;
            margin-top: 10px;
            display: flex;
            align-items: center;
            img{
              width: 11px;
              height: 12px;
              margin-right: 3px;
            }
          }
        }
      }
      .isFollow{
        min-width: 95px;
        max-width: 200px;
        padding: 0 5px;
        height: 30px;
        background: #333;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        color: #ebebeb;
        &.active{
          color: #333;
          background: #fff;
          border: 1px solid #ccc;
        }
      }
    }
    .followInfo{
      display: flex;
      justify-content: center;
      padding: 15px 0;
      background: #fff;
      border-bottom: 1px solid #f2f2f2;
      div{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-width: 120px;
        span{
          font-size: 12px;
          color: #999;
        }
      }
    }
    .mint-swipe {
      height: 375px;
      .mint-swipe-item {
        box-sizing: border-box;
      }
      img {
        width: 100% !important;
        height: 375px;
        object-fit: cover;
      }
    }
    .main {
      margin-bottom: 120px;
      .mainLi {
        box-sizing: border-box;
        background: #fff;
        .contenP {
          padding: 0 15px 15px;
          overflow: hidden;
          font-size: 14px;
          width: 100%;
          left: 0;
          top: 14px;
          z-index: 999;
          color: #333;
          text-overflow: ellipsis;
          white-space: nowrap;
          box-sizing: border-box;
        }
        .head {
          display: flex;
          box-sizing: border-box;
          align-items: center;
          justify-content: space-between;
          .headLeft {
            display: flex;
            align-items: center;
            height: 49px;
            width: 100%;
            div {
              &:first-child {
                padding: 0 15px;
                box-sizing: border-box;
                img {
                  width: 29px;
                  border-radius: 50%;
                  height: 29px;
                  object-fit: cover;
                }
              }
              &:last-child {
                font-size: 14px;
                color: #333;
                width: calc(~'100% - 60px');
                height: 100%;
                display: flex;
                align-items: center;
                span {
                  margin-top: 5px;
                  display: block;
                  font-size: 12px;
                  color: #999;
                }
                p{
                  font-weight: bold;
                }
              }
            }
          }
          .headRight {
            display: flex;
            align-items: center;
            position: relative;
            margin-right: 15px;
            select {
              opacity: 0;
              position: absolute;
              right: 0;
              top: calc(~'50% - 15px');
              max-width: 200px;
            }
            span {
              width: 5px;
              height: 5px;
              border-radius: 50%;
              background: #333;
              margin-left: 5px;
            }
          }
        }
        .content {
          ul {
            display: flex;
            flex-wrap: wrap;
            li {
              width: 113px;
              height: 113px;
              overflow: hidden;
              padding-right: 3px;
              padding-bottom: 3px;
              img {
                width: 100%;
                height: 100%;
                object-fit: cover;
              }
            }
          }
          .starDynamic{
            .dynamicStatus{
              padding: 12px 15px;
              display: flex;
              justify-content: space-between;
              align-items: center;
              p{
                display: flex;
                span{
                  display: block;
                  background-image: url("../assets/images/friends/praise.png");
                  background-repeat:no-repeat ;
                  width: 25px;
                  height: 20px;
                  background-size: 23px 20px;
                  margin-right: 15px;
                  &.praiseActive{
                    background-image: url("../assets/images/friends/praiseActive.png");
                  }
                }
                img{
                  width: 22px;
                  height: 20px;
                }
              }
              .star{
                display: block;
                background-image: url("../assets/images/friends/detail/star.png");
                background-repeat:no-repeat ;
                width: 25px;
                height: 20px;
                background-size: 23px 20px;
                margin-right: 10px;
                &.starActive{
                  background-image: url("../assets/images/friends/detail/starActive.png");
                }
              }
            }
            .dynamicContent{
              padding: 0 15px 30px;
              font-size: 14px;
              color: #333;
              p{
                &:first-child{
                  margin-bottom: 15px;
                }
                &.isContent{
                  overflow: hidden;
                  text-overflow: ellipsis;
                  word-break: break-all;
                  white-space: nowrap;
                  margin-bottom: 15px;
                }
              }
              .comment{
                font-size: 14px;
                color: #999;
                span{
                  font-size: 12px;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
<style lang="less" type="text/less">
  @media screen and (min-width: 410px) {
    .follow{
      .mint-swipe{
        height: 414px!important;
        img{
          height: 100% !important;
        }
      }
    }
  }
  .videoShow {
    box-sizing: border-box;
    width: 100%;
    height: 250px;
    .videoMain {
      width: 100%;
      height: 100%;
      box-sizing: border-box;
    }
  }
</style>
