<template>
  <div class="appraisal">
    <div class="text">
      <div class="first">
        {{$t('postscript')}} <span>（{{$t('optional')}}）</span>
      </div>
      <div class="last">
        <textarea rows="1" :placeholder="$t('say')" maxlength="100" v-model="content">
        </textarea>
        <span>{{content.length}}/100</span>
      </div>
    </div>
    <div class="watchImg">
      <div class="tit">
        {{$t('watchImg')}} <span>（{{$t('sevenImportant')}}）</span>
      </div>
      <div class="img">
        <el-upload
          class="avatar-uploader"
          :headers="head"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg1"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[0].img" :src="img[0].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[0]" @click.stop="removeImg(1)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[0]==''">{{$t('img1')}}</p>
        </el-upload>
        <el-upload
          class="avatar-uploader"
          :headers="head"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg2"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[1].img" :src="img[1].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[1]" @click.stop="removeImg(2)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[1]==''">{{$t('img2')}}</p>
        </el-upload>
        <el-upload
          :headers="head"
          class="avatar-uploader"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg3"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[2].img" :src="img[2].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[2]" @click.stop="removeImg(3)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[2]==''">{{$t('img3')}}</p>
        </el-upload>
        <el-upload
          :headers="head"
          class="avatar-uploader"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg4"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[3].img" :src="img[3].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[3]" @click.stop="removeImg(4)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[3]==''">{{$t('img4')}}</p>
        </el-upload>
        <el-upload
          :headers="head"
          class="avatar-uploader"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg5"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[4].img" :src="img[4].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[4]" @click.stop="removeImg(5)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[4]==''">{{$t('img5')}}</p>
        </el-upload>
        <el-upload
          :headers="head"
          class="avatar-uploader"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg6"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[5].img" :src="img[5].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[5]" @click.stop="removeImg(6)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[5]==''">{{$t('img6')}}</p>
        </el-upload>
        <el-upload
          :headers="head"
          class="avatar-uploader"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg7"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[6].img" :src="img[6].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[6]" @click.stop="removeImg(7)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[6]==''">{{$t('img7')}}</p>
        </el-upload>
        <el-upload
          :headers="head"
          class="avatar-uploader"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg8"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[7].img" :src="img[7].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[7]" @click.stop="removeImg(8)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[7]==''">{{$t('img8')}}</p>
        </el-upload>
        <el-upload
          :headers="head"
          class="avatar-uploader"
          :action="upload"
          :show-file-list="false"
          :on-success="successImg9"
          :before-upload="beforeAvatarUpload">
          <img v-if="img[8].img" :src="img[8].img" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          <span v-if="imgData[8]" @click.stop="removeImg(9)">
            <img src="../assets/images/friends/redClose.png">
          </span>
          <p v-if="imgData[8]==''">{{$t('img9')}}</p>
        </el-upload>
      </div>
    </div>
    <div class="subBtn" @click="subClick">
      {{$t('submit')}}
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        upload: `${process.env.API.USER}/user/upload`,
        head: {
          AccessToken: localStorage.getItem('AccessToken'),
          Authorization: localStorage.getItem('userId')
        },
        flag:false,
        content: '',
        imgData: [
          '', '', '', '', '', '', '', '', ''
        ],
        img: [
          {img: require('@/assets/images/friends/watch/img1.jpg')},
          {img: require('@/assets/images/friends/watch/img2.jpg')},
          {img: require('@/assets/images/friends/watch/img3.jpg')},
          {img: require('@/assets/images/friends/watch/img4.jpg')},
          {img: require('@/assets/images/friends/watch/img5.jpg')},
          {img: require('@/assets/images/friends/watch/img6.jpg')},
          {img: require('@/assets/images/friends/watch/img7.jpg')},
          {img: require('@/assets/images/friends/watch/img8.jpg')},
          {img: require('@/assets/images/friends/watch/img9.jpg')}
        ],
      }
    },
    methods: {
      subClick() {
        let self = this
        if(!self.flag){
          if (self.content.length > 100) {
            self.$toast(`${this.$t('contentBeyond')}`)
            return false
          }
          if (!self.imgData[0] || !self.imgData[1] || !self.imgData[2] || !self.imgData[3] || !self.imgData[4] || !self.imgData[5] || !self.imgData[6]) {
            self.$toast(`${this.$t('sevenImg')}`)
            return false
          }
          let data = {
            uid: localStorage.getItem('userId'),
            remark: self.content,
            file_fid_list: []
          }
          for (let i = 0; i < self.imgData.length; i++) {
            if (self.imgData[i]) {
              data.file_fid_list.push(self.imgData[i])
            }
          }
          self.flag = true
          self.$http.post(`${process.env.API.MARKET}/market/buyer/goodscertify`, data).then(res => {
            if (res.data.errcode == '0') {
              self.$toast(`${this.$t('success')}`)
              setTimeout(() => {
                location.href = `${process.env.URL.USER}/#/releaselist?key=2`
                self.flag = false
              }, 2000)
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      removeImg(index) {
        let key = index - 1
        this.imgData[key] = ''
        switch (index) {
          case 1:
            this.img[key].img = require('@/assets/images/friends/watch/img1.jpg')
            break;
          case 2:
            this.img[key].img = require('@/assets/images/friends/watch/img2.jpg')
            break;
          case 3:
            this.img[key].img = require('@/assets/images/friends/watch/img3.jpg')
            break;
          case 4:
            this.img[key].img = require('@/assets/images/friends/watch/img4.jpg')
            break;
          case 5:
            this.img[key].img = require('@/assets/images/friends/watch/img5.jpg')
            break;
          case 6:
            this.img[key].img = require('@/assets/images/friends/watch/img6.jpg')
            break;
          case 7:
            this.img[key].img = require('@/assets/images/friends/watch/img7.jpg')
            break;
          case 8:
            this.img[key].img = require('@/assets/images/friends/watch/img8.jpg')
            break;
          case 9:
            this.img[key].img = require('@/assets/images/friends/watch/img9.jpg')
            break;
        }
      },
      successImg1(res, file) {
        if (res.errcode == '0') {
          this.img[0].img = URL.createObjectURL(file.raw);
          this.imgData[0] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg2(res, file) {
        if (res.errcode == '0') {
          this.img[1].img = URL.createObjectURL(file.raw);
          this.imgData[1] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg3(res, file) {
        if (res.errcode == '0') {
          this.img[2].img = URL.createObjectURL(file.raw);
          this.imgData[2] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg4(res, file) {
        if (res.errcode == '0') {
          this.img[3].img = URL.createObjectURL(file.raw);
          this.imgData[3] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg5(res, file) {
        if (res.errcode == '0') {
          this.img[4].img = URL.createObjectURL(file.raw);
          this.imgData[4] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg6(res, file) {
        if (res.errcode == '0') {
          this.img[5].img = URL.createObjectURL(file.raw);
          this.imgData[5] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg7(res, file) {
        if (res.errcode == '0') {
          this.img[6].img = URL.createObjectURL(file.raw);
          this.imgData[6] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg8(res, file) {
        if (res.errcode == '0') {
          this.img[7].img = URL.createObjectURL(file.raw);
          this.imgData[7] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg9(res, file) {
        if (res.errcode == '0') {
          this.img[8].img = URL.createObjectURL(file.raw);
          this.imgData[8] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      beforeAvatarUpload(file) {
//        const isJPG = file.type === 'image/jpeg';
        const isLt5M = file.size / 1024 / 1024 < 5;
        if (file.type == 'image/jpeg' || file.type == 'image/jpg' || file.type == 'image/png' || file.type == 'image/bmp') {

        } else {
          this.$message.error(this.$t('isImg'));
          return false
        }
        if (!isLt5M) {
          this.$message.error(this.$t('is5MB'));
        }
        return isLt5M;
      },
    },
    created() {
      let self = this

    }
  }
</script>
<style lang="less" scoped type="text/less">
  .img {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    box-sizing: border-box;
    margin-top: 15px;
    padding-right: 15px;
    div {
      margin-bottom: 15px;
    }
  }

  .text {
    background: #fff;
    .first {
      display: flex;
      align-items: center;
      height: 44px;
      margin: 10px 0 0 15px;
      border-bottom: 1px solid #f2f2f2;
      box-sizing: border-box;
      span {
        font-size: 12px;
        color: #999;
      }
    }
    .last {
      position: relative;
      textarea {
        overflow: scroll;
        width: 100%;
        box-sizing: border-box;
        resize: none;
        border: none;
        padding: 15px;
      }
      span {
        position: absolute;
        right: 15px;
        bottom: 10px;
        font-size: 12px;
        color: #999;
        z-index: 999;
      }
    }

  }

  .watchImg {
    margin-top: 10px;
    background: #fff;
    padding-left: 15px;
    .tit {
      height: 44px;
      display: flex;
      align-items: center;
      border-bottom: 1px solid #f2f2f2;
      span {
        font-size: 12px;
        color: #999;
      }
    }
  }

  .subBtn {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 44px;
    background: #333;
    color: #fff;
    font-size: 16px;
    text-align: center;
    line-height: 44px;
  }
</style>
<style lang="less" type="text/less">

  /*图片样式*/
  /*提交图片*/
  .el-upload {
    position: relative;
  }

  @media screen and (min-width: 410px) {
    .img {
      .avatar-uploader .el-upload {
        width: 120px !important;
        height: 120px !important;
      }

      .avatar {
        width: 120px !important;
        height: 120px !important;
      }

      .avatar-uploader {
        height: 120px !important;
        margin-bottom: 15px !important;
        width: 32%;
      }
    }
  }

  @media screen and (min-width: 500px) {
    .img {
      .avatar-uploader .el-upload {
        width: 135px !important;
        height: 135px !important;
      }

      .avatar {
        width: 135px !important;
        height: 135px !important;
      }
    }
  }

  .img {
    .avatar-uploader {
      height: 105px;
      span {
        position: absolute;
        right: -7px;
        top: -7px;
        img {
          width: 14px;
          height: 14px;
          border-radius: 50%;
        }
      }
      p{
        position: absolute;
        bottom: 0;
        width: 100%;
        left: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #fff;
        border: none;
        padding: 0;
        margin: 0;
        font-size: 14px;
      }
    }
    .avatar-uploader .el-upload {
      border-radius: 0;
      cursor: pointer;
      position: relative;
      box-sizing: border-box;
      width: 105px;
      height: 105px;
      img {
        object-fit: cover
      }
    }
    .avatar-uploader .el-upload:hover {
      border-color: #20a0ff;
    }
    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      text-align: center;
    }
    .avatar {
      width: 105px;
      height: 105px;
      display: block;
      &.avatar {
        width: 100% !important;
      }
    }

    .avatar-uploader {
      width: 30%;
    }
  }
</style>
