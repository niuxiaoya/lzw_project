<template>
  <div class="detail">
    <div class="head">
      <div class="banner" v-if="info.kind ==1">
        <mt-swipe @change="handleChange" :auto="0" :show-indicators="false" :style="{height:hei}">
          <mt-swipe-item v-for="item,index in info.file_pic" :key="index">
            <img :src="item" @click.stop="selectImg(index,item)">
          </mt-swipe-item>
        </mt-swipe>
        <span>{{bannerNum}}/{{info.file_pic?info.file_pic.length:0}}</span>
      </div>
      <div v-if="info.kind ==2" class="videoShow">
        <video controls :poster="info.cover_pic" class="videoMain">
          <source :src="info.file_pic[0]" type="video/mp4">
        </video>
      </div>
      <div class="tit">
        <div class="headLeft" @click.stop="followClick(info)">
          <div>
            <img :src="info.avatar_pic?info.avatar_pic:require('../assets/images/friends/user.png')">
          </div>
          <p>
            {{info.username?info.username:info.tel}}
          </p>
        </div>
        <div class="headRight">
          <span></span>
          <span></span>
          <span></span>
          <select v-model="sel" @change.stop="selChange(info)" v-if="userInfo.uid!=info.user_uid">
            <option value="attention">{{info.relations==1?$t('attentionCancel'):$t('attention')}}</option>
            <option value="blacklist">{{info.relations==2?$t('blackListRemove'):$t('blackAdd')}}</option>
            <option value="jb">{{info.is_report==1?$t('isReport'):$t('report')}}</option>
            <option value="cancel">{{$t('cancel')}}</option>
          </select>
          <select v-model="sel" @change.stop="selChange(info)" v-if="userInfo.uid==info.user_uid">
            <option value="delete">{{$t('delete')}}</option>
            <option value="cancel">{{$t('cancel')}}</option>
          </select>
        </div>
      </div>
      <div class="titMain" v-if="info.content">
        <p class="few" v-if="!showP" @click="showP=!showP" v-html="info.content"></p>
        <p class="many" v-if="showP" @click="showP=!showP" v-html="info.content"></p>
        <span @click="showP=!showP" :class="{'showP':showP}">
          <img src="../assets/images/friends/downP.png">
        </span>
      </div>
      <div class="starDynamic">
        <div class="dynamicStatus">
          <div>
            <img src="../assets/images/friends/eye.png">{{info.pv}}
          </div>
          <div>
            <p>
              <span :class="{'praiseActive':info.is_like==1}" @click.stop="likeTopClick"></span>
              {{info.like_num}}
            </p>
            <span class="star" @click.stop="starTopClick" :class="{'starActive':info.is_collect==1}"></span>
          </div>
        </div>
      </div>
    </div>
    <div class="content">
      <div class="contentTit">
        {{$t('comment')}}（{{info.comment_num}}）
      </div>
      <ul>
        <li v-for="item in comment.data" @click.stop="messageClick(item)">
          <div class="contentUser">
            <div>
              <img :src="item.avatar_pic?item.avatar_pic:require('../assets/images/friends/user.png')">
              <p>
                {{item.comment_username?item.comment_username:item.tel}}
                <span>{{item.create_time}}</span>
              </p>
            </div>
            <div :class="{'praiseActive':item.is_like==1}">
              <span><img src="../assets/images/friends/message.png">{{item.discuss_count}}</span>
              <p @click.stop="likeClick(item)"><span></span>{{item.like_num}}</p>
            </div>
          </div>
          <div class="contentMain">
            <p v-html="item.content"></p>
            <ul v-if="item.discuss.length>=1" class="comment">
              <li v-for="el,key in item.discuss" v-if="key<2">
                <span>{{el.comment_username?el.comment_username:el.tel}}</span>
                {{$t('reply')}}
                <span>{{el.target_username}}：</span>
                {{el.content}}
              </li>
              <li class="num" v-if="item.discuss_count>=2">
                {{$t('all')}} <img src="../assets/images/friends/arrow.png">
              </li>
            </ul>
          </div>
        </li>
        <infinite-loading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="comment.page.p>2">{{$t('noMore')}}</span>
          <span slot="no-results" v-show="comment.page.p>2">{{$t('noMore')}}</span>
        </infinite-loading>
      </ul>
    </div>
    <div style="width: 100%;height: 80px;"></div>
    <div class="message">
      <input type="text" :placeholder="$t('sayText')" ref="ipt" v-model="content" v-on:focus="isAuth">
      <span @click.stop="sub">
        <!--{{$t('release')}}-->
        <img src="../assets/images/friends/release.png">
      </span>
    </div>
    <transition name="slide-fade" class="fadeView">
      <div v-if="show">
        <image-view :imgArr="info.source_pic"
                    :showImageView="true"
                    :imageIndex="imageIndex"
                    v-on:hideImage="hideImageView"
        >
        </image-view>
      </div>
    </transition>
    <div v-if="show" class="btnActive" id="saveBtn">
      <span @click.stop="starClick">{{$t('collection')}}</span>
      <span @click.stop="saveImg">{{$t('save')}}</span>
    </div>
  </div>
</template>
<script>
  const InfiniteLoading = () => import('vue-infinite-loading')
  const imageView = () => import('vue-imageview')

  export default {
    data() {
      return {
        hei:0,
        bannerNum: 1,
        content: '',
        uid: '',
        userInfo: {},
        info: {},
        sel: '',
        messageBtn: {
          message: this.$t('isLogin'),
          title: this.$t('prompt'),
          confirmButtonText: this.$t('confirm'),
          cancelButtonText: this.$t('cancel'),
          showCancelButton: true,
          showConfirmButton: true
        },
        showP: false,
        comment: {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          }
        },
        // 显示组件
        show: false,
        // 从哪一张图片开始
        imageIndex: 0,
        imgKey: 0,
      }
    },
    methods: {
      isAuth() {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
//        if(self.userInfo&&self.userInfo.is_auth!=1){
//          self.$messagebox.confirm('请先完成实名认证，再进行相应操作','提示').then(action=>{
//            if(action == 'confirm'){
//              location.href = `${process.env.URL.USER}/#/realname`
//            }
//          }).catch(err=>{
//            console.log(err)
//          })
//          return false
//        }
      },
      selChange(item) {
        let self = this
        if (self.sel == 'cancel') {
          self.sel = ''
          return false
        } else if (self.sel == 'jb') {
          this.$http.post(`${process.env.API.FRIENDS}/friends/report`, {
            cid: item.cid,
            user_uid: item.user_uid
          }).then(res => {
            if (res.data.errcode == '0') {
              this.$toast(this.$t('reportSuccess'))
              item.is_report = 1
            } else {
              this.$toast(res.data.errmsg)
            }
            self.sel = ''
          }).catch(err => {
            this.$toast(err)
          })
          return false
        }
        if(self.sel == 'delete'){
          this.$http.delete(`${process.env.API.FRIENDS}/friends/trends?cid=${item.cid}`).then(res=>{
            if(res.data.errcode=='0'){
              setTimeout(()=>{
                history.back(-1)
              },500)
            }else{
              this.$toast(res.data.errmsg)
            }
            self.sel = ''
          }).catch(err=>{
            console.log(err)
          })
        }else if (self.sel == 'attention') {
          if (item.relations == 1) {
            self.messageBtn.message = self.$t('noAttention')
            self.$messagebox(self.messageBtn).then(action => {
              if (action == 'confirm') {
                this.$http.delete(`${process.env.API.FRIENDS}/friends/relations?type=${self.sel}&other_uid=${item.user_uid}`).then(res => {
                  if (res.data.errcode == '0') {
                    item.relations = 3
                  } else {
                    this.$toast(res.data.errmsg)
                  }
                  self.sel = ''
                }).catch(err => {
                  console.log(err)
                })
              } else {
                self.sel = ''
              }
            }).catch(err => {
              console.log(err)
            })
          } else {
            this.$http.post(`${process.env.API.FRIENDS}/friends/relations`, {
              type: self.sel,
              other_uid: item.user_uid
            }).then(res => {
              if (res.data.errcode == '0') {
                this.$toast(this.$t('attentionSuccess'))
                item.relations = 1
              } else {
                this.$toast(res.data.errmsg)
              }
              self.sel = ''
            }).catch(err => {
              console.log(err)
            })
          }
        } else if (self.sel == 'blacklist') {
          if (item.relations == 2) {
            this.$http.delete(`${process.env.API.FRIENDS}/friends/relations`, {
              params: {
                type: self.sel,
                other_uid: item.user_uid
              }
            }).then(res => {
              if (res.data.errcode == '0') {
                this.$toast(this.$t('blackListRemove'))
                item.relations = 3
              } else {
                this.$toast(res.data.errmsg)
              }
              self.sel = ''
            }).catch(err => {
              console.log(err)
            })
          } else {
            this.$http.post(`${process.env.API.FRIENDS}/friends/relations`, {
              type: self.sel,
              other_uid: item.user_uid
            }).then(res => {
              if (res.data.errcode == '0') {
                this.$toast(this.$t('blackListSuccess'))
                item.relations = 2
              } else {
                this.$toast(res.data.errmsg)
              }
              self.sel = ''
            }).catch(err => {
              console.log(err)
            })
          }
        }
//        self.hotList = {
//          data: [],
//          page: {
//            p: 0,
//            total_pages: 1
//          },
//        }
//        this.$nextTick(() => {
//          this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
//        });
      },
      followClick(item) {
        location.href = `${process.env.URL.FRIENDS}/#/follow?id=${item.user_uid}`
      },
      handleChange(index) {
        this.bannerNum = index + 1
      },
      hideImageView() {
        document.body.style.overflow = 'visible'
        setTimeout(() => {
          this.show = false
        }, 300)
      },
      selectImg(index, item) {
        document.body.style.height = '100vh'
        document.body.style.overflow = 'hidden'
        this.show = true
        this.imageIndex = index
//        this.imgKey = key
      },
      saveImg(index, key) {
        window.open(`${this.info.file_pic[this.imageIndex]}?download=1&source=1`)
      },
      messageClick(item) {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
//        if(self.userInfo&&self.userInfo.is_auth!=1){
//          self.$messagebox.confirm('请先完成实名认证，再进行相应操作','提示').then(action=>{
//            if(action == 'confirm'){
//              location.href = `${process.env.URL.USER}/#/realname`
//            }
//          }).catch(err=>{
//            console.log(err)
//          })
//          return false
//        }
        self.$router.push({name: 'Comment', params: item})
      },
      likeTopClick() {
        let data = {
          type: 'circle',
          publish_uid: this.info.user_uid,
          like_id: this.info.cid
        }
        if (this.info.is_like == 1) {
          this.$http.delete(`${process.env.API.USER}/user/userlike?type=circle&publish_uid=${this.info.user_uid}&like_id=${this.info.cid}`).then(res => {
            if (res.data.errcode == '0') {
              this.info.is_like = 0
              this.info.like_num = this.info.like_num - 1
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.$http.post(`${process.env.API.USER}/user/userlike`, data).then(res => {
            if (res.data.errcode == '0') {
              this.info.is_like = 1
              this.info.like_num = this.info.like_num + 1
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      starTopClick() {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        let data = {
          type: 'circle',
          publish_uid: self.info.user_uid,
          collect_id: self.info.cid
        }

        if (self.info.is_collect == 1) {
          self.$http.delete(`${process.env.API.USER}/user/collect?type=circle&publish_uid=${self.info.user_uid}&collect_id=${self.info.cid}`).then(res => {
            if (res.data.errcode == '0') {
              self.info.is_collect = 0
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          self.$http.post(`${process.env.API.USER}/user/collect`, data).then(res => {
            if (res.data.errcode == '0') {
              self.info.is_collect = 1
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      starClick() {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        let data = {
          type: 'picture',
          collect_id: self.info.file_fid_list[this.imageIndex],
          publish_uid: self.info.user_uid
        }
        this.$http.post(`${process.env.API.USER}/user/collect`, data).then(res => {
          if (res.data.errcode == '0') {
            this.$toast(this.$t('starSuccess'))
          } else {
            this.messagebox.alert({message: res.data.errmsg, showCancelButton: this.$t('confirm')})
          }
        }).catch(err => {
          console.log(err)
        })
      },
      praiseClick(el, index) {
        let self = this
        if (index == 1) {
          if (!self.uid) {
            self.$messagebox(self.messageBtn).then(action => {
              if (action == 'confirm') {
                location.href = `${process.env.URL.USER}/#/login`
              }
            }).catch(err => {
              console.log(err)
            })
            return false
          }
          let data = {
            publish_uid: self.info.user_uid,
            collect_id: self.info.cid,
            type: 'circle'
          }
          if (self.info.is_collect == 1) {
            self.$http.delete(`${process.env.API.USER}/user/collect?type=circle&publish_uid=${self.info.user_uid}&collect_id=${self.info.cid}`).then(res => {
              if (res.data.errcode == '0') {
                el.is_collect = 0
              }
            }).catch(err => {
              console.log(err)
            })
          } else {
            self.$http.post(`${process.env.API.USER}/user/collect`, data).then(res => {
              if (res.data.errcode == '0') {
                el.is_collect = 1
              }
            }).catch(err => {
              console.log(err)
            })
          }
        } else {
          let data = {
            type: 'circle',
            publish_uid: self.info.user_uid,
            like_id: self.info.cid
          }
          if (self.info.is_like == 1) {
            self.$http.delete(`${process.env.API.USER}/user/userlike?type=circle&publish_uid=${self.info.user_uid}&like_id=${self.info.cid}`).then(res => {
              if (res.data.errcode == '0') {
                el.is_like = 0
                el.like_num = el.like_num - 1
              }
            }).catch(err => {
              console.log(err)
            })
          } else {
            self.$http.post(`${process.env.API.USER}/user/userlike`, data).then(res => {
              if (res.data.errcode == '0') {
                el.is_like = 1
                el.like_num = el.like_num + 1
              }
            }).catch(err => {
              console.log(err)
            })
          }
        }
      },
      likeClick(item) {
        let self = this
        let data = {
          type: 'circle_comment',
          publish_uid: item.comment_uid,
          like_id: item.ccid
        }
        console.log(item)
        if (item.is_like == 1) {
          self.$http.delete(`${process.env.API.USER}/user/userlike?type=circle_comment&publish_uid=${item.comment_uid}&like_id=${item.ccid}`).then(res => {
            if (res.data.errcode == '0') {
              item.is_like = 0
              item.like_num = item.like_num - 1
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          self.$http.post(`${process.env.API.USER}/user/userlike`, data).then(res => {
            if (res.data.errcode == '0') {
              item.is_like = 1
              item.like_num = item.like_num + 1
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      sub() {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
//        if(self.userInfo&&self.userInfo.is_auth!=1){
//          self.$messagebox.confirm(this.$t('isAuth'),this.$t('prompt')).then(action=>{
//            if(action == 'confirm'){
//              location.href = `${process.env.URL.USER}/#/realname`
//            }
//          }).catch(err=>{
//            console.log(err)
//          })
//          return false
//        }
        if (!self.content) {
          self.$toast(this.$t('isContent'))
          return false
        }
        let data = {
          circle_cid: self.info.cid,
          author_uid: self.info.user_uid,
          content: self.content,
        }

        self.$http.post(`${process.env.API.FRIENDS}/friends/comment`, data).then(res => {
          if (res.data.errcode == '0') {
            self.$http.get(`${process.env.API.FRIENDS}/friends/trendsinfo?cid=${self.$fun.GetQueryString('cid', 'detail')}&rows=10`).then(res => {
              if (res.data.errcode == '0') {
                self.info.comment_num = res.data.data.data.comment_num
                //评论
                for (let i = 0; i < res.data.data.comment.data.length; i++) {
                  res.data.data.comment.data[i].create_time = self.$moment(res.data.data.comment.data[i].create_time * 1000).format('YYYY-MM-DD')
                  res.data.data.comment.data[i].tel = `${res.data.data.comment.data[i].tel.substring(0, 3)}****${res.data.data.comment.data[i].tel.substring(res.data.data.comment.data[i].tel.length - 4)}`
                  res.data.data.comment.data[i].discuss.map((item) => {
                    item.tel = `${item.tel.substring(0, 3)}****${item.tel.substring(item.tel.length - 4)}`
                  })
                }
                self.comment.data = []
                self.comment.data = self.comment.data.concat(res.data.data.comment.data)
                self.comment.page = res.data.data.comment.page
                self.content = ''
              }
            }).catch(err => {
              console.log(err)
            })
          }
        }).catch(err => {
          console.log(err)
        })
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.comment.page.p > self.comment.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.comment.page.p++
          self.$http.get(`${process.env.API.FRIENDS}/friends/trendsinfo?cid=${self.$fun.GetQueryString('cid', 'detail')}&p=${self.comment.page.p}&rows=10`).then(res => {
            if (res.data.errcode == '0') {
              res.data.data.data.file_pic = res.data.data.data.file_pic.split(',')
              res.data.data.data.file_fid_list = res.data.data.data.file_fid_list.split(',')
              res.data.data.data.source_pic = res.data.data.data.source_pic?res.data.data.data.source_pic.split(','):[]
              res.data.data.data.publish_time = self.$moment(res.data.data.data.publish_time * 1000).format('YYYY-MM-DD')
              res.data.data.data.tel = `${res.data.data.data.tel.substring(0, 3)}****${res.data.data.data.tel.substring(res.data.data.data.tel.length - 4)}`
              //赋值
              self.info = res.data.data.data
              //评论
              for (let i = 0; i < res.data.data.comment.data.length; i++) {
                res.data.data.comment.data[i].create_time = self.$moment(res.data.data.comment.data[i].create_time * 1000).format('YYYY-MM-DD')
                res.data.data.comment.data[i].tel = `${res.data.data.comment.data[i].tel.substring(0, 3)}****${res.data.data.comment.data[i].tel.substring(res.data.data.comment.data[i].tel.length - 4)}`
                res.data.data.comment.data[i].discuss.map((item) => {
                  item.tel = `${item.tel.substring(0, 3)}****${item.tel.substring(item.tel.length - 4)}`
                })
              }
              self.comment.data = self.comment.data.concat(res.data.data.comment.data)
              if (res.data.data.comment.page) {
                self.comment.page = res.data.data.comment.page
              }
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
          })
        }, 300);
      }
    },
    created() {
      let self = this
      self.hei = document.body.clientWidth+'px'
      // 调用方法
      setTimeout(() => {
        self.uid = localStorage.getItem('userId')
        self.userInfo = self.$store.state.userInfo
//        self.$http.get(`${process.env.API.USER}/user/userinfo?nonce=${Math.random()}`).then(res => {
//          if (res.data.errcode == '0') {
//            self.userInfo = res.data.data
//          }
//        }).catch(err => {
//          console.log(err)
//        })
      }, 300)
    },
    components: {
      InfiniteLoading: InfiniteLoading,
      'image-view': imageView
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .videoShow {
    box-sizing: border-box;
    width: 100%;
    height: 250px;
    .videoMain {
      width: 100%;
      height: 100%;
    }
  }

  .detail {
    overflow-x: hidden;
    height: 100vh;
    overflow-y: scroll;
  }

  .head {
    background: #fff;
    font-size: 14px;
    color: #333;
    margin-bottom: 10px;
    .tit {
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #f2f2f2;
      height: 49px;
      width: 100%;
      padding: 0 15px;
      box-sizing: border-box;
      .headLeft {
        display: flex;
        align-items: center;
        width: calc(~'100% - 30px');
        div {
          margin-right: 10px;
          img {
            width: 29px;
            height: 29px;
            border-radius: 50%;
            object-fit: cover;
            display: block;
          }
        }
        p {
          font-size: 14px;
          font-weight: bold;
        }
      }
      .headRight {
        display: flex;
        align-items: center;
        position: relative;
        select {
          opacity: 0;
          position: absolute;
          right: 0;
          top: calc(~'50% - 15px');
          max-width: 200px;
        }
        span {
          width: 5px;
          height: 5px;
          border-radius: 50%;
          background: #333;
          margin-left: 5px;
        }
      }
    }
    .banner {
      position: relative;
      span {
        position: absolute;
        top: 15px;
        right: 15px;
        padding: 2px 8px;
        border-radius: 10px;
        background: rgba(3, 3, 3, 0.3);
        color: rgba(255, 255, 255, 0.9);
        font-size: 12px;
      }
    }
    .titMain {
      padding: 15px;
      display: flex;
      justify-content: space-between;
      p {
        width: calc(~'100% - 10px');
        &.few {
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
        }
      }
      span {
        img {
          width: 7px;
          height: 6px;
          transition: All 0.4s;
        }
        &.showP {
          img {
            transform: rotate(180deg);
          }
        }
      }
    }
  }

  .content {
    font-size: 14px;
    color: #333;
    padding-left: 15px;
    background: #fff;
    .contentTit {
      height: 44px;
      line-height: 44px;
    }
    .contentUser {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 15px 15px 0;
      div {
        &:first-child {
          display: flex;
          p {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            span {
              font-size: 12px;
              color: #999;
            }
          }
          img {
            width: 29px;
            height: 29px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
          }
        }
        &:last-child {
          width: 80px;
          display: flex;
          justify-content: space-between;
          p {
            display: flex;
            align-items: center;
          }
          &.praiseActive {
            span {
              &:last-child {
                background-image: url('../assets/images/friends/praiseActive.png');
              }
            }
          }
          span {
            &:last-child {
              display: inline-block;
              width: 14px;
              height: 12px;
              background-image: url('../assets/images/friends/praise.png');
              background-repeat: no-repeat;
              background-size: 13px 12px;
              margin-right: 5px;

            }
            img {
              width: 12px;
              margin-right: 5px;
            }
          }
        }
      }
    }
    .contentMain {
      padding: 0 15px 15px 0;
      font-size: 12px;
      color: #000;
      word-break: break-all;
      p {
        padding-bottom: 15px;
      }
      .comment {
        margin-bottom: 15px;
        background: #f9f9f9;
        padding: 15px;
        font-size: 12px;
        .num {
          img {
            width: 5.5px;
            height: 10px;
          }
        }
        li {
          margin-bottom: 15px;
          color: #666;
          word-break: break-all;
          &:last-child {
            margin: 0;
          }
          span {
            color: #333;
          }
        }
      }
    }
  }

  .starDynamic {
    .dynamicStatus {
      padding: 12px 15px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      div {
        display: flex;
        &:first-child {
          display: flex;
          align-items: center;
          img {
            width: 16px;
            display: inline-block;
            margin-right: 5px;
            height: 11px;
          }
        }
        &:last-child {
          p {
            display: flex;
            margin-right: 15px;
            align-items: center;
            span {
              display: block;
              background-image: url("../assets/images/friends/praise.png");
              background-repeat: no-repeat;
              width: 25px;
              height: 20px;
              background-size: 23px 20px;
              margin-right: 3px;
              &.praiseActive {
                background-image: url("../assets/images/friends/praiseActive.png");
              }
            }
            img {
              width: 22px;
              height: 20px;
            }
          }
          .star {
            display: block;
            background-image: url("../assets/images/friends/detail/star.png");
            background-repeat: no-repeat;
            width: 25px;
            height: 20px;
            background-size: 23px 20px;
            &.starActive {
              background-image: url("../assets/images/friends/detail/starActive.png");
            }
          }
        }
      }
    }
  }

  .message {
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    position: fixed;
    bottom: 0;
    left: 0;
    background: #fff;
    border-top: 1px solid #f2f2f2;
    box-sizing: border-box;
    padding: 15px;
    input {
      height: 30px;
      width: calc(~'100% - 35px');
      background: #ecf0f4;
      padding-left: 15px;
      box-sizing: border-box;
    }
    span {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      img {
        width: 25px;
      }
    }
  }

  .mint-swipe {
    /*height: 375px;*/
    color: #fff;
    font-size: 30px;
    text-align: center;
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }

  .btnActive {
    position: fixed;
    bottom: 15px;
    z-index: 10000;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #fff;
    width: 100%;
    display: flex;
    justify-content: space-around;
    p {
      position: absolute;
      left: calc(~'50% - 12.5px');
      top: -20px;
    }
    span {
      padding: 5px 15px;
      border-radius: 10px;
      background: rgba(3, 3, 3, 0.6);
    }
  }
</style>
<style lang="less" type="text/less">
  @media screen and (min-width: 410px) {
    .detail {
      .mint-swipe {
        /*height: 414px !important;*/
        img {
          height: 100% !important;
        }
      }
    }
  }
</style>
