<template>
  <div class="evaluation">
    <img src="../assets/images/bulid.png">
  </div>
</template>
<style lang="less" scoped type="text/less">
  .evaluation{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    img{
      width: 70%;
    }
  }
</style>
