<template>
  <div class="fans">
    <div class="nav">
      <p :class="{'navActive':navNum==1}" @click="navClick(1)">{{$t('fans')}}</p>
      <p :class="{'navActive':navNum==2}" @click="navClick(2)">{{$t('attention')}}</p>
    </div>
    <no-more v-show="mainList.data.length<=0"></no-more>
    <ul class="mainList">
      <li v-for="item,index in mainList.data" @click="openDetail(item)">
        <div class="leftFans">
          <img :src="item.other_avatar_pic?item.other_avatar_pic:require('../assets/images/friends/user.png')">
          {{item.other_username?item.other_username:item.other_tel}}
        </div>
        <div class="rightFans" :class="{'isShow':item.relations==1}" @click.stop="fansClick(item,index)" v-if="(userInfo&&userInfo.uid)!=item.other_uid">
          {{item.relations==1?$t('attentionCancel'):$t('attention')}}
        </div>
      </li>
      <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
        <span slot="no-more" v-show="mainList.page.p>2">{{$t('noMore')}}</span>
        <span slot="no-results" v-show="mainList.page.p>2">{{$t('noMore')}}</span>
      </InfiniteLoading>
    </ul>
  </div>
</template>
<script>
  const InfiniteLoading = () => import('vue-infinite-loading')
  export default {
    data(){
      return {
        other_uid:'',
        uid:'',
        navNum:1,
        mainList: {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          }
        },
        userInfo:{},
        messageBtn :{
          message:this.$t('isLogin'),
          title:this.$t('prompt'),
          confirmButtonText:this.$t('confirm'),
          cancelButtonText:this.$t('cancel'),
          showCancelButton:true,
          showConfirmButton:true
        },
      }
    },
    methods:{
      fansClick(item,index) {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        if(item.relations==1){
          this.$http.delete(`${process.env.API.FRIENDS}/friends/relations?other_uid=${item.other_uid}&type=attention`).then(res => {
            if (res.data.errcode== '0') {
              if(this.navNum==2){
                this.mainList.data.splice(index, 1)
              }else{
                item.relations=3
              }
              this.$toast(this.$t('attentionCancel'))
            }else{
              this.$toast(res.data.errmsg)
            }
          }).catch(err => {
            console.log(err)
          })
        }else{
          this.$http.post(`${process.env.API.FRIENDS}/friends/relations`,{other_uid:item.other_uid,type:'attention'}).then(res => {
            if (res.data.errcode== '0') {
              this.$toast(this.$t('attentionSuccess'))
              item.relations=1
            }else{
              this.$toast(res.data.errmsg)
            }
          }).catch(err => {
            console.log(err)
          })
        }
      },
      navClick(index) {
        let self = this
        if (index == self.navNum) {
          return false
        }
        self.navNum = index
        if(self.navNum==1) {
          self.type = 'fans'
        }else if(self.navNum==2){
          self.type = 'attention'
        }
        self.mainList = {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          },
        }
        this.$nextTick(() => {
          this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
        });
      },
      openDetail(item){
        location.href=`${process.env.URL.FRIENDS}/#/follow?id=${item.other_uid}`
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.mainList.page.p > self.mainList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.mainList.page.p++
          self.$http.get(`${process.env.API.FRIENDS}/friends/relations?other_uid=${self.other_uid}&type=${self.type}&p=${self.mainList.page.p}&rows=10`).then(res => {
            if (res.data.errcode == '0') {
              self.mainList.data = self.mainList.data.concat(res.data.data)
              self.mainList.page = res.data.page
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 300)
  },
    },
    mounted(){
      let self = this
      setTimeout(()=>{
        self.userInfo = self.$store.state.userInfo
      },300)
      self.navNum = self.$fun.GetQueryString('key','fans')
      self.other_uid = self.$fun.GetQueryString('other_uid','fans')
      self.uid = localStorage.getItem('userId')
      if(self.navNum==1) {
        self.type = 'fans'
      }else if(self.navNum==2){
        self.type = 'attention'
      }
    },
    components:{
      InfiniteLoading
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .fans{
    .nav{
      display: flex;
      align-items: center;
      justify-content: center;
      background: #fff;
      border-bottom: 1px solid #f2f2f2;
      p{
        min-width: 100px;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 44px;
        color: #666;
        font-size: 14px;
        position: relative;
        &.navActive{
          font-weight: bold;
          &:before{
            content: '';
            width: 20px;
            height: 2px;
            background: #333;
            position: absolute;
            left: calc(~'50% - 10px');
            bottom: 0;
          }
        }
      }
    }
    .mainList{
      li{
        background: #fff;
        padding-left: 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        min-height: 70px;
        padding-right: 15px;
        box-sizing: border-box;
        position: relative;
        img{
          width: 40px;
          height: 40px;
          border-radius: 50%;
          margin-right: 10px;
        }
        div{
          display: flex;
          align-items: center;
          &.leftFans{
            color: #333;
            font-size: 16px;
          }
          &.rightFans{
            max-width: 200px;
            min-width: 95px;
            padding: 0 5px;
            background: #333;
            justify-content: center;
            box-sizing: border-box;
            color: #fff;
            height: 30px;
            font-size: 14px;
            &.isShow{
              color: #333;
              background: #fff;
              border:1px solid #ccc;
            }
          }
        }
        &:before {
          content: '';
          position: absolute;
          width: calc(~'100% - 15px');
          height: 1px;
          background-color: #f2f2f2;
          bottom: 0;
          right: 0;
        }
        &:last-child:before {
          content: '';
          width: 0;
          height: 0;
        }
      }
    }
  }
</style>
