<script>
  export default {
    created(){
      localStorage.removeItem('userId')
      location.href = `${process.env.URL.USER}/#/login`
    }
  }
</script>
