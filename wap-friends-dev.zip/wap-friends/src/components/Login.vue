<template>

</template>
<script>
  export default {
    created() {
      let self = this
      if (self.$fun.GetQueryString('uid','login')){
        localStorage.setItem('userId', self.$fun.GetQueryString('uid','login'))
        localStorage.setItem('AccessToken', self.$fun.GetQueryString('AccessToken','login'))
        self.$indicator.close();
        location.href = `${process.env.URL.USER}/#/`
      }
    }
  }
</script>
