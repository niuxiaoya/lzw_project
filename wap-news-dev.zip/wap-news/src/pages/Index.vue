<template>
  <div class="news">
    <div class="topNav">
      <div @click="topNavClick">{{$t('vip')}}</div>
      <div class="topNavActive">{{$t('tb2')}}</div>
    </div>
    <div class="search">
      <div>
        <img class="" src="../assets/images/news/search.png">
        <input type="text" :placeholder="$t('searchText')" v-model="isSearch">
        <img src="../assets/images/news/close.png" @click="isSearch=''" v-if="isSearch!=''">
      </div>
      <span @click="confirmClick">
        {{$t('confirm')}}
      </span>
    </div>
    <!--<ul class="nav" :class="{'navStyle':list.nav&&list.nav.length>5,'no-style':list.nav.length<=0}" v-if="list.nav.length>=0">-->
      <!--<li v-for="(item,key) in list.nav" :class="{'active':navNum==key+1}" @click="navClick(item,key+1)">-->
        <!--{{item.name}}-->
      <!--</li>-->
    <!--</ul>-->
    <!--<div class="special" v-if="list.subject.length>0">-->
      <!--<img v-for="el,key in list.subject" @click="specialClick(el)" :src="el.cover_pic" :key="key">-->
    <!--</div>-->
    <no-more v-if="list.data.length<=0"></no-more>
    <!--<div style="width: 100%;height: 90px" v-if="!isShow"></div>-->
    <ul class="newsMain">
      <li class="mainLi" v-for="item in list.data" @click="openDetail(item)">
        <div class="tit" v-if="list.data&&item.content_pic.length>=3">{{item.title}}</div>
        <ul v-if="list.data&&item.content_pic.length>=3">
          <li><img :src="item.content_pic[0]"></li>
          <li><img :src="item.content_pic[1]"></li>
          <li><img :src="item.content_pic[2]"></li>
        </ul>
        <div v-if="list.data&&item.content_pic.length<3" class="isOne">
          <div class="oneImg">
            <img :src="item.content_pic[0]">
          </div>
          <div class="oneMain">
            <p class="oneTit">
              {{item.title}}
            </p>
            <div>
              <p>{{item.author}} <span>{{item.date}}</span></p>
              <span><img src="../assets/images/news/message.png">{{item.message}}{{item.comment_num}}</span>
            </div>
          </div>
        </div>
        <div class="foo" v-else>
          <p>{{item.name}}<span>{{item.date}}</span></p>
          <span><img src="../assets/images/news/message.png">{{item.message}}{{item.comment_num}}</span>
        </div>
      </li>
      <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
        <span slot="no-more" v-show="list.page.p>2">{{$t('noMore')}}</span>
        <span slot="no-results" v-show="list.page.p>2">{{$t('noMore')}}</span>
      </InfiniteLoading>
    </ul>
    <toolbar></toolbar>
  </div>
</template>

<script>
  import toolbar from '../components/toolbar'
  import InfiniteLoading from 'vue-infinite-loading';

  export default {
    data() {
      let lang = localStorage.getItem('lang');
      if (lang) {
        this.$i18n.locale = lang
      }
      return {
        navNum: 1,
        navTab: 'default',
        newsData: {},
        userInfo: {},
        topNavNum: 2,
        isSearch:'',
        loading: false,//滚动最底部加载
        //列表数据
        list: {
          nav: [],
          subject: [],
          data: [],
          page: {
            p: 0,
            total_pages: 1
          }
        },
        newsList: []
      }
    },
    methods: {
      openDetail(item) {
        let self = this
        location.href = `${process.env.URL.NEWS}/#/detail?article_id=${item.aid}`
      },
      topNavClick() {
        location.href = `${process.env.URL.VIP}/#/`
      },
      confirmClick(){
        let self = this
        self.navTab = 'default'
        self.list = {
          nav: [],
          subject: [],
          data: [],
          page: {
            p: 0,
            total_pages: 1
          }
        }
        this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.list.page.p > self.list.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.list.page.p++
          self.$http.get(`${process.env.API.NEWS}/news/articlelist?category_id=${self.navTab}&p=${self.list.page.p}&rows=10&keyword=${self.isSearch}`).then(res => {
            if (res.data.errcode == '0') {
              for (let i = 0; i < res.data.data.length; i++) {
                res.data.data[i].content_pic = res.data.data[i].content_pic.split(',')
              }
              if (self.list.nav.length <= 0) {
                self.list.nav = res.data.all_category
              }
              self.list.subject = res.data.all_subject
              self.list.data = self.list.data.concat(res.data.data)
              self.list.page = res.data.page
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 300);
      },
      specialClick(item) {
        this.$router.push({name: 'Special', params: {sid: item.sid}})
      },
      navClick(item, index) {
        let self = this
        self.navNum = index
        self.navTab = item.code
        self.list = {
          nav: self.list.nav,
          subject: [],
          data: [],
          page: {
            p: 0,
            total_pages: 1
          }
        }
        this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
      }
    },
    created() {
      document.title = this.$t('tb2')
    },
    mounted() {
      let self = this
      setTimeout(()=>{
        self.userInfo = self.$store.state.userInfo
      },300)
    },
    components: {
      toolbar,
      InfiniteLoading
    }//公共底部
  }
</script>
<!--当前页面样式-->
<style lang="less" scoped type="text/less">
  .no-style {
    background: none !important;
  }

  .noMore {
    color: #666;
    font-size: 14px;
    text-align: center;
  }

  .news {
    .topNav {
      display: flex;
      align-items: center;
      height: 44px;
      width: 100%;
      justify-content: center;
      background: #fff;
      font-size: 14px;
      border-bottom: 1px solid #f2f2f2;
      position: fixed;
      top:0;
      left: 0;
      div {
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        height: 44px;
        min-width: 100px;
        color: #666;
        &.topNavActive {
          color: #333;
          font-weight: bold;
          &:before {
            content: '';
            position: absolute;
            width: 20px;
            height: 2px;
            background: #333;
            left: calc(~'50% - 10px');
            bottom: 0;
          }
        }
      }
    }
    .search {
      padding: 10px 15px;
      background: #fff;
      position: fixed;
      display: flex;
      justify-content: space-between;
      box-sizing: border-box;
      width: 100%;
      top:45px;
      left: 0;
      div {
        align-items: center;
        display: flex;
        height: 24px;
        flex:2;
        background: #ecf0f4;
        padding-right: 15px;
        img {
          width: 15px;
          height: 15px;
          margin: 0 5px 0 10px;
          &:last-child{
            width: 7px;
            height: 7px;
            margin: 0;
          }
        }
        input {
          background: none;
          height: 100%;
          width: 100%;
        }
      }
      span{
        display: flex;
        align-items: center;
        padding-left: 15px;
      }
    }
  }

  .navStyle {
    overflow: scroll;
    display: inline-block !important;
    overflow-y: hidden;
    white-space: nowrap;
    li {
      display: inline-block !important;
      width: 120px;
      text-align: center;
    }
  }

  @media screen and (min-width: 410px) {
    .mainLi {
      ul {
        li {
          width: 120px !important;
          height: 120px !important;
        }
      }
    }
  }

  //导航栏样式
  .nav {
    height: 44px;
    width: 100%;
    display: flex;
    flex-wrap: nowrap;
    font-size: 14px;
    border-bottom: 1px solid #f2f2f2;
    box-sizing: border-box;
    color: #333;
    position: fixed;
    z-index: 999;
    top: 45px;
    left: 0;
    background: #fff;
    li {
      width: 20%;
      height: 44px;
      line-height: 44px;
      color: #666;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      position: relative;
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      &.active {
        color: #333;
        &:before {
          width: 20px;
          height: 3px;
          background: #333;
          content: '';
          position: absolute;
          bottom: 0;
          left: calc(~'50% - 10px');
        }
      }
    }
  }

  .newsMain {
    margin-top: 89px;
    margin-bottom: 80px;
    .mainLi {
      background: #fff;
      width: 100%;
      padding: 15px;
      box-sizing: border-box;
      color: #333;
      font-size: 14px;
      margin-bottom: 10px;
      .tit {
        width: 100%;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        word-break: break-all;
        margin-bottom: 15px;
      }
      ul {
        width: 100%;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        li {
          width: 110px;
          height: 110px;
          overflow: hidden;
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
      }
      .isOne {
        display: flex;
        .oneImg {
          width: 110px;
          height: 110px;
          overflow: hidden;
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
        .oneMain {
          width: calc(~'100% - 110px');
          padding-left: 15px;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          .oneTit {
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            word-break: break-all;
          }
          div {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #999;
            p {
              span {
                padding-left: 15px;
              }
            }
            span {
              img {
                width: 12px;
                height: 12px;
                margin-right: 5px;
              }
            }
          }
        }
      }
      .foo {
        padding-top: 15px;
        display: flex;
        justify-content: space-between;
        color: #999;
        font-size: 12px;
        p {
          span {
            padding-left: 15px;
          }
        }
        span {
          img {
            width: 12px;
            height: 12px;
            margin-right: 5px;
          }
        }
      }
    }
  }

  //专题样式
  .special {
    width: 100%;
    padding: 15px;
    box-sizing: border-box;
    background: #fff;
    margin-top: 89px;
    img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      display: block;
      margin-bottom: 10px;
      &:last-child {
        margin: 0;
      }
    }
  }
</style>
