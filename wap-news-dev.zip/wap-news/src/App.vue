<template>
  <div id="app">
    <publish-share></publish-share>
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: 'app',
    data(){
      return {
        accessToken:''
      }
    },
    created(){
      let langList=[
        'zh-CN',
        'zh-TW',
        'fr',
        'de',
        'en-US'
      ]
      let lang = navigator.browserLanguage?navigator.browserLanguage:navigator.language
      if(langList.indexOf(lang)!=-1){
        if(!localStorage.getItem('lang')){
          if(langList.indexOf(lang)!=-1){
            switch(lang){
              case 'zh-CN':
                lang='zh-cn'
                break;
              case 'zh-TW':
                lang='zh-hk'
                break;
              case 'en-US':
                lang='en-us'
                break;
              case 'fr':
                lang='fr-fr'
                break;
              case 'de':
                lang='de-de'
                break;
            }
            localStorage.setItem('lang',lang)
          }else{
            localStorage.setItem('lang','en-us')
          }
          setTimeout(()=>{
            location.reload()
          },500)
          return false
        }
      }
      this.$http.get(`${process.env.API.USER}/user/userinfo?nonce=${Math.random()}`).then(res => {
        if (res.data.errcode == '0') {
          this.$store.state.userInfo = res.data.data
          let isAuth = localStorage.getItem('isAuth')
          if(res.data.data){
            if((res.data.data&&res.data.data.is_auth==0)||(res.data.data&&res.data.data.is_auth==2)){
              localStorage.setItem('isAuth',res.data.data.is_auth)
              isAuth = localStorage.getItem('isAuth')
            }
          }
          if((res.data.data&&res.data.data.is_auth==1)&&(isAuth==0||isAuth==2)){
            this.$http.get(`${process.env.API.USER}/user/getauth`).then(res=>{
              if(res.data.errcode=='0'){
                localStorage.setItem('userId',res.data.Authorization)
                localStorage.setItem('isAuth',1)
              }
            }).catch(err=>{
              console.log(err)
            })
          }
        }
      }).catch(err => {
        console.log(err)
      })
//      this.$http.get(`${process.env.API.USER}/user/userinfo`).then(res=>{
//        if(res.data.errcode==0) {
//          this.$store.state.userInfo = res.data.data
//          let isAuth = localStorage.getItem('isAuth')
//          if(res.data.data){
//            if((res.data.data&&res.data.data.is_auth==0)||(res.data.data&&res.data.data.is_auth==2)){
//              localStorage.setItem('isAuth',res.data.data.is_auth)
//              isAuth = localStorage.getItem('isAuth')
//            }
//          }
//          if((res.data.data&&res.data.data.is_auth==1)&&(isAuth==0||isAuth==2)){
//            this.$http.get(`${process.env.API.USER}/user/getauth`).then(res=>{
//              if(res.data.errcode=='0'){
//                localStorage.setItem('userId',res.data.Authorization)
//                localStorage.setItem('isAuth',1)
//              }
//            }).catch(err=>{
//              console.log(err)
//            })
//          }
//        }
//      }).catch(err=>{
//        console.log(err)
//      })
//      if (localStorage.getItem('AccessToken') ) {
//        this.$http.get(`${process.env.API.USER}/user/userinfo`).then(res=>{
//          if(res.data.errcode==0) {
//            this.$store.state.userInfo = res.data.data
//            let isAuth = localStorage.getItem('isAuth')
//            if(res.data.data){
//              if((res.data.data&&res.data.data.is_auth==0)||(res.data.data&&res.data.data.is_auth==2)){
//                localStorage.setItem('isAuth',res.data.data.is_auth)
//                isAuth = localStorage.getItem('isAuth')
//              }
//            }
//            if((res.data.data&&res.data.data.is_auth==1)&&(isAuth==0||isAuth==2)){
//              this.$http.get(`${process.env.API.USER}/user/getauth`).then(res=>{
//                if(res.data.errcode=='0'){
//                  localStorage.setItem('userId',res.data.Authorization)
//                  localStorage.setItem('isAuth',1)
//                }
//              }).catch(err=>{
//                console.log(err)
//              })
//            }
//          }
//        }).catch(err=>{
//          console.log(err)
//        })
//      } else {
//        //如果没有accessToken请求一次
//        this.$http.get(`${process.env.API.USER}/login`).then(res=>{
//          if(!parseInt(res.data.errcode)){
//            this.accessToken = res.data.AccessToken
//            localStorage.setItem('AccessToken',res.data.AccessToken)
//           }
//        }).catch(err=>{
//          console.log(err)
//        })
//      }
    }
  }
</script>
<style lang="less">
  *{
    font-family: "Microsoft YaHei";
  }
</style>
