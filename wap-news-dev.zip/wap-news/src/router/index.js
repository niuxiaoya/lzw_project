import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/pages/Index'
// import Detail from '@/components/Detail'
// import Special from '@/components/Special'
// import Comment from '@/components/Comment'
// import Logout from '@/components/Logout'
// import Login from '@/components/Login'



Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index
    },
    {
      path: '/detail',
      name: 'Detail',
      component:resolve=>require(['@/components/Detail'],resolve)
    },
    {
      path: '/special',
      name: 'Special',
      component:resolve=>require(['@/components/Special'],resolve)
    },
    {
      path: '/comment',
      name: 'Comment',
      component:resolve=>require(['@/components/Comment'],resolve)
    },
    {
      path: '/logout',
      name: 'Logout',
      component:resolve=>require(['@/components/Logout'],resolve)
    },
    {
      path: '/login',
      name: 'Login',
      component:resolve=>require(['@/components/Login'],resolve)
    }
  ]
})
