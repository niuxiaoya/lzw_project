import Nomore from '@/components/Nomore'
const Share = () => import('@/components/Share')
// 导出组件
export default {
  install: function (Vue) {
    Vue.component('no-more', Nomore)    //  公共空白页面
    Vue.component('publish-share', Share);    //  分享悬浮
  }
}
