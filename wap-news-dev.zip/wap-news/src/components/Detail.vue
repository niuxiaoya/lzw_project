<template>
  <div class="detail">
    <div class="detailHead">
      <div class="tit">
        <div class="head">
          <p>{{newsInfo.data.title}}</p>
          <p>{{newsInfo.data.author}} <span>{{newsInfo.data.date}}</span></p>
        </div>
        <div class="news_content">
          <div v-html="newsInfo.data.content"></div>
        </div>
        <div class="titFoo">
          <p class="praise" @click.stop="praiseClick" :class="{'praiseActive':newsInfo.data.is_like_id==1}">
            <span ></span>{{newsInfo.data.like_num}}</p>
          <p class="star" @click="praiseClick(1)" :class="{'starActive':newsInfo.data.is_collection_id==1}">
            <span></span>
          </p>
        </div>
        <!--<img src="../assets/images/news/buy/lls.jpg">-->
      </div>
    </div>
    <div class="detailMessage">
      <p class="mesTit">{{$t('comment')}}</p>
      <ul class="messageMain">
        <li class="messageMainLi" v-for="item in message" @click.stop="messageClick(item)">
          <div class="mainHead">
            <div class="tit">
              <img :src="item.avatar_pic?item.avatar_pic:require('../assets/images/news/detail/user.png')">
              <p>{{item.comment_username?item.comment_username:item.tel}} <span>{{item.date}}</span></p>
            </div>
            <p class="praise">
              <span><img src="../assets/images/news/message.png">
                {{item.discuss_count}}
              </span>
              <span :class="{'active':item.is_like}" @click.stop="lickClick(item)">
              </span>
              {{item.like_num}}
            </p>
          </div>
          <div class="mainFoo">
            {{item.content}}
          </div>
          <ul class="comment" v-show="item.discuss.length>0">
            <li v-for="el,key in item.discuss" v-if="key<2">
              <span>{{el.comment_username?el.comment_username:el.tel}}</span>
              {{$t('comment')}}
              <span>{{el.target_username}}：</span>
              {{el.content}}
            </li>
            <li class="num" v-if="item.discuss_count>=2">
              {{$t('all')}} <img src="../assets/images/news/arrow.png">
            </li>
          </ul>
        </li>
        <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="newsInfo.page.p>2">{{$t('noMore')}}</span>
          <span slot="no-results" v-show="newsInfo.page.p>2">{{$t('noMore')}}</span>
        </InfiniteLoading>
      </ul>
    </div>
    <div class="foo">
      <input type="text" :placeholder="$t('sayText')" v-model="postData.content" @focus="isLogin">
      <span @click="sub">
        <!--{{$t('release')}}-->
        <img src="../assets/images/news/release.png">
      </span>
    </div>
  </div>
</template>
<script>
  import InfiniteLoading from 'vue-infinite-loading';
  export default {
    data() {
      return {
        uid: '',
        aid:'',
        userInfo:{},
        postData: {
          content: '',
          article_aid: '',
          author_uid: ''
        },
        messageBtn :{
          message:this.$t('isLogin'),
          title:this.$t('prompt'),
          confirmButtonText:this.$t('confirm'),
          cancelButtonText:this.$t('cancel'),
          showCancelButton:true,
          showConfirmButton:true
        },
        newsInfo: {
          data:{},
          page:{
            p:0,
            total_pages:1
          }
        },
        message: []
      }
    },
    methods: {
      sub() {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
//        if(self.userInfo&&self.userInfo.is_auth!=1){
//          console.log(self.userInfo)
//          self.$messagebox.confirm('请先完成实名认证，再进行相应操作','提示').then(action=>{
//            if(action == 'confirm'){
//              location.href = `${process.env.URL.USER}/#/realname`
//            }
//          }).catch(err=>{
//            console.log(err)
//          })
//          return false
//        }
        if (!self.postData.content) {
          self.$toast(this.$t('isContent'))
        } else {
          self.postData.author_uid = self.newsInfo.publish_id
          self.$http.post(`${process.env.API.NEWS}/news/comment`, self.postData).then(res => {
            if (res.data.errcode==0) {
            }else{
              self.$messagebox.alert(res.data.errmsg)
            }
            self.postData.content = ''
            setTimeout(() => {
              self.$http.get(`${process.env.API.NEWS}/news/articledetail?article_id=${self.postData.article_aid}`).then(res => {
                if (res.data.errcode==0) {
                  //评论信息
                  self.message = res.data.manage.comment
                  for (let i=0;i<self.message.length;i++){
                    self.message[i].date = this.$moment(self.message[i].create_time * 1000).format('YYYY-MM-DD HH:mm')
                  }
                }
              }).catch(err => {
                console.log(err)
              })
            }, 300)
          }).catch(err => {
            console.log(err)
          })
        }
      },
      praiseClick(index) {
        let self = this
        if (index == 1) {
          if(!self.uid){
            self.$messagebox(self.messageBtn).then(action => {
              if (action == 'confirm') {
                location.href = `${process.env.URL.USER}/#/login`
              }
            }).catch(err => {
              console.log(err)
            })
            return false
          }
          if (self.newsInfo.data.is_collection_id == 1) {
            self.$http.delete(`${process.env.API.USER}/user/collect?collect_id=${self.postData.article_aid}&type=article&publish_uid=${self.newsInfo.data.publish_id}`).then(res => {
              if (res.data.errcode=='0') {
                self.newsInfo.data.is_collection_id = 0
              } else {
                self.$messagebox.alert(res.data.errmsg);
              }
            }).catch(err => {
              console.log(err)
            })
          } else {
            self.$http.post(`${process.env.API.USER}/user/collect `, {
              collect_id: self.postData.article_aid,
              type: 'article',
              publish_uid: self.newsInfo.publish_id
            }).then(res => {
              if (res.data.errcode=='0') {
                self.newsInfo.data.is_collection_id = 1
              } else {
                self.$messagebox.alert(res.data.errmsg);
              }
            }).catch(err => {
              console.log(err)
            })
          }
        } else {
          if(self.newsInfo.data.is_like_id==1){
            self.$http.delete(`${process.env.API.USER}/user/userlike?type=article&publish_uid=${self.newsInfo.publish_id}&like_id=${self.postData.article_aid}`).then(res => {
              if (res.data.errcode=='0') {
                self.newsInfo.data.is_like_id=0
                self.newsInfo.data.like_num=self.newsInfo.data.like_num-1
              } else {
                self.$messagebox.alert(res.data.errmsg);
              }
            }).catch(err => {
              console.log(err)
            })
          }else{
            self.$http.post(`${process.env.API.USER}/user/userlike`, {
              type: 'article',
              publish_uid: self.newsInfo.publish_id,
              like_id:self.postData.article_aid
            }).then(res => {
              if (res.data.errcode=='0') {
                self.newsInfo.data.is_like_id=1
                self.newsInfo.data.like_num=self.newsInfo.data.like_num+1
              } else {
                self.$messagebox.alert(res.data.errmsg);
              }
            }).catch(err => {
              console.log(err)
            })
          }
        }
//        setTimeout(() => {
//          self.$http.get(`${process.env.API.NEWS}/news/articledetail?article_id=${self.postData.article_aid}`).then(res => {
//            if (res.data.errcode==0) {
//              self.newsInfo = {}
//              self.newsInfo.title = res.data.manage.detail.title
//              self.newsInfo.date = this.$moment(res.data.manage.detail.publish_time * 1000).format('YYYY-MM-DD HH:mm')
//              self.newsInfo.content = res.data.manage.detail.content
//              self.newsInfo.author = res.data.manage.detail.author
//              self.newsInfo.is_like = res.data.manage.detail.is_like_id
//              self.newsInfo.collect_id = res.data.manage.detail.is_collection_id
//              self.newsInfo.publish_id = res.data.manage.detail.publish_uid || 0
//              self.newsInfo.parent_id = res.data.manage.detail.parent_id || 0
//              self.postData.article_aid = res.data.manage.detail.aid
//              self.newsInfo.like_num = res.data.manage.detail.like_num
//              //评论信息
//              self.message = res.data.manage.comment
//              for (let i=0;i<self.message.length;i++){
//                self.message[i].date = this.$moment(self.message[i].create_time * 1000).format('YYYY-MM-DD HH:mm')
//              }
//            }
//          }).catch(err => {
//            console.log(err)
//          })
//        }, 500)
      },
      messageClick(item){
        this.$router.push({name:'Comment',params:item})
      },
      lickClick(item){
        let self = this
        let data = {
          type:'article_comment',
          publish_uid:item.comment_uid,
          like_id:item.cid
        }
        if(item.is_like==1){
          self.$http.delete(`${process.env.API.USER}/user/userlike?type=article_comment&publish_uid=${item.comment_uid}&like_id=${item.cid}`).then(res=>{
            if(res.data.errcode==0){
              item.is_like = 0
              item.like_num = item.like_num-1
            }
          }).catch(err=>{
            console.log(err)
          })
        }else{
          self.$http.post(`${process.env.API.USER}/user/userlike`,data).then(res=>{
            if(res.data.errcode==0){
              item.is_like = 1
              item.like_num = item.like_num+1
            }
          }).catch(err=>{
            console.log(err)
          })
        }
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.newsInfo.page.p > self.newsInfo.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.newsInfo.page.p++
          self.$http.get(`${process.env.API.NEWS}/news/articledetail?article_id=${self.aid}&p=${self.newsInfo.page.p}&rows=10`).then(res => {
            if (res.data.errcode==0) {
              self.newsInfo.data=res.data.manage.detail
              self.newsInfo.page=res.data.manage.page
              //post
              self.postData.article_aid = res.data.manage.detail.aid
              //评论信息
              self.message = self.message.concat(res.data.manage.comment)
              for (let i=0;i<self.message.length;i++){
                self.message[i].date = this.$moment(self.message[i].create_time * 1000).format('YYYY-MM-DD HH:mm')
              }
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 300);
      },
      isLogin(){
        let self = this
        if(!self.uid){
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
//        if(self.userInfo&&self.userInfo.is_auth!=1){
//          self.$messagebox.confirm('请先完成实名认证，再进行相应操作','提示').then(action=>{
//            if(action == 'confirm'){
//              location.href = `${process.env.URL.USER}/#/realname`
//            }
//          }).catch(err=>{
//            console.log(err)
//          })
//          return false
//        }
      }
    },
    mounted() {
      let self = this
      self.uid = localStorage.getItem('userId')
      self.userInfo = self.$store.state.userInfo
      self.aid = self.$fun.GetQueryString('article_id','detail')
      if (!self.aid) {
        self.$router.push('/')
        return false
      }
    },
    components: {
      InfiniteLoading
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .detail{
    /*max-height: 100vh;*/
    /*overflow-y: scroll;*/
    /*overflow-x: hidden;*/
    /*-webkit-overflow-scrolling:touch;*/
  }
  .detailHead {
    .tit {
      box-sizing: border-box;
      width: 100%;
      padding: 15px;
      background: #fff;
      font-size: 14px;
      color: #333;
      .head {
        padding-bottom: 15px;
        p {
          &:first-child {
            font-size: 16px;
            padding-bottom: 10px;
          }
          &:last-child {
            font-size: 12px;
            color: #999;
            span {
              padding-left: 5px;
            }
          }
        }
      }
      .news_content {
        color: #666;
        padding-bottom: 15px;
        display: block;
        word-break: break-all;
        box-sizing: border-box;
        img{
          max-width: 100%!important;
          height: auto;
        }
      }
      img {
        width: 100%;
        margin-top: 15px;
      }
    }
    .titFoo {
      display: flex;
      height: 40px;
      align-items: center;
      padding-left: 15px;
      background: #fff;
      border-top: 1px solid #f2f2f2;
      p {
        display: flex;
        align-items: center;
        font-size: 12px;
        color: #999;
        span {
          margin-right: 10px;
        }
      }
      .praise {
        margin-right: 30px;
        &.praiseActive {
          color: #333;
          span{
            background-image: url("../assets/images/news/praiseActive.png");

          }
        }
        span {
          width: 14px;
          height: 12px;
          background-image: url("../assets/images/news/praise.png");
          display: block;
          background-repeat: no-repeat;
          background-size: 13px 12px;
        }
      }
      .star {
        &.starActive {
          color: #333!important;
          span{
            background-image: url("../assets/images/news/detail/starActive.png");
          }
        }
        span {
          background-image: url("../assets/images/news/detail/star.png");
          background-repeat: no-repeat;
          background-size: cover;
          width: 17px;
          height: 16px;
          display: block;
          &.starActive {
            background-image: url("../assets/images/news/detail/starActive.png");
            color: #333!important;
          }
        }
      }
    }
  }

  .detailMessage {
    margin-top: 10px;
    color: #333;
    font-size: 14px;
    margin-bottom: 80px;
    .mesTit {
      height: 44px;
      line-height: 44px;
      box-sizing: border-box;
      background: #fff;
      padding-left: 15px;
      position: relative;
      &:before{
        position: absolute;
        content: '';
        bottom: 0;
        right: 0;
        width: calc(~'100% - 15px');
        height: 1px;
        background: #f2f2f2;
      }
    }
    .messageMain {
      .messageMainLi {
        background: #fff;
        padding: 15px;
        position: relative;
        &:before{
          position: absolute;
          content: '';
          bottom: 0;
          right: 0;
          width: calc(~'100% - 15px');
          height: 1px;
          background: #f2f2f2;
        }
        .mainHead {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 15px 0 15px 0;
          .tit {
            display: flex;
            p {
              display: flex;
              margin-left: 10px;
              flex-direction: column;
              justify-content: space-between;
              font-size: 14px;
              span {
                font-size: 12px;
                color: #999;
              }
            }
            img {
              width: 40px;
              height: 40px;
              border-radius: 50%;
            }
          }
          .praise {
            color: #999;
            display: flex;
            align-items: center;
            img{
              display: block;
              width: 10px;
              height: 10px;
            }
            span {
              display: flex;
              align-items: center;
              &:first-child{
                img{
                  margin-right: 5px;
                }
              }
              &:last-child{
                display: inline-block;
                width: 14px;
                height: 12px;
                background-image: url('../assets/images/news/praise.png');
                background-repeat: no-repeat;
                background-size: 13px 12px;
                margin-right: 5px;
                margin-left: 20px;
                &.active {
                  background-image: url('../assets/images/news/praiseActive.png');
                }
              }
            }
          }
        }
        .mainFoo {
          font-size: 12px;
          padding-bottom: 15px;
        }
        .comment {
          margin-bottom: 15px;
          background: #ecf0f4;
          padding: 15px;
          font-size: 12px;
          .num{
            img{
              width: 5.5px;
              height: 10px;
            }
          }
          li {
            margin-bottom: 15px;
            color: #666;
            &:last-child {
              margin: 0;
            }
            span {
              color: #333;
            }
          }
        }
      }
    }
  }

  .foo {
    position: fixed;
    display: flex;
    align-items: center;
    justify-content: space-between;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 50px;
    border-top: 1px solid #f2f2f2;
    box-sizing: border-box;
    background: #fff;
    padding: 0 15px;
    input {
      width: calc(~'100% - 35px');
      height: 30px;
      background: #ecf0f4;
      padding-left: 15px;
      font-size: 14px;
      box-sizing: border-box;
    }
    span {
      font-size: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      img{
        width: 25px;
      }
    }
  }
</style>
<style lang="less">
  .news_content{
    img{
      max-width: 100%;
      height: auto;
    }
  }
</style>
