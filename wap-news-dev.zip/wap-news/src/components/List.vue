<template>
  <div style="min-height: 300px;width: 100%;margin-bottom: 80px;" :class="{'no-data':list.subject.length<=0&&list.data.length<=0}">
    <div class="special" v-if="list.subject && list.subject.length>=1">
      <img v-for="el,key in list.subject" @click="specialClick(el)" :src="el.cover_pic" :key="key">
    </div>
    <ul class="newsMain" v-if="list.data && list.data.length>=1">
      <li class="mainLi" v-for="item in list.data" @click="openDetail(item)" >
        <div class="tit" v-if="item.content_pic&&item.content_pic.length>=3">{{item.title}}</div>
        <ul v-if="item.content_pic.length>=3">
          <li><img :src="item.content_pic[0]"></li>
          <li><img :src="item.content_pic[1]"></li>
          <li><img :src="item.content_pic[2]"></li>
        </ul>
        <div v-if="item.content_pic.length<3" class="isOne">
          <div class="oneImg">
            <img :src="item.content_pic[0]">
          </div>
          <div class="oneMain">
            <p class="oneTit">
              {{item.title}}
            </p>
            <div>
              <p>{{item.author}} <span>{{item.date}}</span></p>
              <span><img src="../assets/images/news/message.png">{{item.message}}{{item.comment_num}}</span>
            </div>
          </div>
        </div>
        <div class="foo" v-if="item.content_pic.length>=3">
          <p>{{item.name}}<span>{{item.date}}</span></p>
          <span><img src="../assets/images/news/message.png">{{item.message}}{{item.comment_num}}</span>
        </div>
      </li>
      <InfiniteLoading :on-infinite="onInfinite" ref="infiniteLoading">
        <span slot="no-more">{{$t('noMore')}}</span>
        <span slot="no-results">{{$t('noMore')}}</span>
      </InfiniteLoading>
    </ul>
  </div>
</template>
<script>
  import InfiniteLoading from 'vue-infinite-loading';

  export default {
    props: {
      type: String,
      model: Function
    },
    data () {
      return {
        newsData: {},
        list: {
          subject:[],
          data:[],
          pages:{
            p:0,
            total_pages:1
          }
        }
      }
    },
    mounted() {
      this.newsData = new this.model()
      this.newsData.type = this.type
      this.newsData.get_news(this.list)
    },
    methods: {
      openDetail(item){
        let self = this
        location.href = `${process.env.URL.NEWS}/#/detail?uid=${localStorage.getItem('userId')}&article_id=${item.aid}`
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (self.list.pages.p > self.list.pages.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          self.list.pages.p++
          self.newsData.get_news(self.list, () => {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
          })
        }, 300);
      },
      specialClick(item){
        this.$router.push({name:'Special',params:item})
      }
    },
    components: {
      InfiniteLoading:InfiniteLoading
    }
  }
</script>
<style lang="less" scoped type="text/less">
  //内容样式
  .newsMain {
    margin-top: 50px;
    margin-bottom: 80px;
    .mainLi {
      background: #fff;
      width: 100%;
      padding: 15px;
      box-sizing: border-box;
      color: #333;
      font-size: 14px;
      margin-bottom: 10px;
      .tit {
        width: 100%;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        word-break: break-all;
        margin-bottom: 15px;
      }
      ul {
        width: 100%;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        li {
          width: 110px;
          height: 110px;
          overflow: hidden;
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
      }
      .isOne {
        display: flex;
        .oneImg {
          width: 110px;
          height: 110px;
          overflow: hidden;
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
        .oneMain {
          width: calc(~'100% - 110px');
          padding-left: 15px;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          .oneTit {
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            word-break: break-all;
          }
          div {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #999;
            p {
              span {
                padding-left: 15px;
              }
            }
            span {
              img {
                width: 12px;
                height: 12px;
                margin-right: 5px;
              }
            }
          }
        }
      }
      .foo {
        padding-top: 15px;
        display: flex;
        justify-content: space-between;
        color: #999;
        font-size: 12px;
        p {
          span {
            padding-left: 15px;
          }
        }
        span {
          img {
            width: 12px;
            height: 12px;
            margin-right: 5px;
          }
        }
      }
    }
  }
  //专题样式
  .special {
    width: 100%;
    padding: 15px;
    box-sizing: border-box;
    background: #fff;
    margin-top: 44px;
    img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      display: block;
      margin-bottom: 10px;
      &:last-child{
        margin: 0;
      }
    }
  }
</style>
