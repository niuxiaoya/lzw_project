<template>
  <div class="share" v-if="shareShow">
    <div class="share_left">
      <img src="../assets/images/share/close.png" class="share_close" @click="shareShow=!shareShow">
      <div class="share_logo">
        <img src="../assets/images/share/logo.png">
        <div>
          <div>
            {{$t('shareSwisstime')}}
            <p>{{$t('shareSwisstimeText')}}</p>
          </div>
        </div>
      </div>
    </div>
    <div class="share_right" @click="downClick">
      {{$t('download')}}
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        fooNum: 0,
        shareShow:true,
        userInfo: {}
      }
    },
    methods: {
      downClick(){
        let ua = window.navigator.userAgent.toLowerCase();
        let self = this
        //微信
        if(ua.match(/MicroMessenger/i) == 'micromessenger'){
          if (navigator.userAgent.match(/(iPhone|iPod|iPad);?/i)) {
            let loadDateTime = new Date();
            window.setTimeout(function() {
              let timeOutDateTime = new Date();
              if (timeOutDateTime - loadDateTime < 3000) {
                window.location = `https://itunes.apple.com/us/app/id1298434824?ls=1&mt=8`;//ios下载地址
              }
            },2000);
            window.location = "iOSSwissTime://";
          }else if(navigator.userAgent.match(/android/i)){
            let state = null;
            try {
              let loadTime = new Date();
              if(self.$route.path=='/detail'){
                location.href = `androidswisstime://com.petter.swisstime_android?where=news&pid=${self.$route.query.article_id}`
              }else{
                location.href = `androidswisstime://com.petter.swisstime_android/`
              }
              setTimeout(function(){
                let outTime = new Date()
                if(outTime - loadTime > 800){
                  location.href = `http://a.app.qq.com/o/simple.jsp?pkgname=com.petter.swisstime_android`
                }
              },1000)
            } catch(e) {}
          }
        }else{//非微信浏览器
          if (navigator.userAgent.match(/(iPhone|iPod|iPad);?/i)) {
            let loadDateTime = new Date();
            window.setTimeout(function() {
              let timeOutDateTime = new Date();
              if (timeOutDateTime - loadDateTime < 3000) {
                window.location = `https://itunes.apple.com/us/app/id1298434824?ls=1&mt=8`;//ios下载地址
              }
            },2000);
            window.location = "iOSSwissTime://";
          }else if (navigator.userAgent.match(/android/i)) {
            let state = null;
            try {
              let loadTime = new Date();
              if(self.$route.path=='/detail'){
                location.href = `androidswisstime://com.petter.swisstime_android?where=news&pid=${self.$route.query.article_id}`
              }else{
                location.href = `androidswisstime://com.petter.swisstime_android/`
              }
              setTimeout(function(){
                let outTime = new Date()
                if(outTime - loadTime > 800){
                  location.href = `http://a.app.qq.com/o/simple.jsp?pkgname=com.petter.swisstime_android`
                }
              },1000)
            } catch(e) {}
          }
        }
      }
    },
    mounted() {
      setTimeout(() => {
        this.userInfo = this.$store.state.userInfo
      }, 600)
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .share{
    width: 100%;
    min-height: 64px;
    padding: 10px 8px 10px 15px;
    background: rgba(3,3,3,0.6);
    position: fixed;
    top:0;
    left: 0;
    z-index: 9999;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-sizing: border-box;
    .share_left{
      display: flex;
      align-items: center;
      .share_close{
        width: 11px;
        height: 11px;
      }
      .share_logo{
        display: flex;
        font-size: 14px;
        align-items: center;
        color: #fff;
        img{
          width: 40px;
          height: 40px;
          display: block;
          margin: 0 7px 0 15px;
        }
        div{
          display: flex;
          flex-direction: column;
          max-width: 160px;
          p{
            font-size: 12px;
            color: #e5e5e5;
          }
        }
      }
    }
    .share_right{
      min-width: 80px;
      max-width: 200px;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 32px;
      background: #333;
      color: #fff;
      border-radius: 5px;
      font-size: 12px;
      padding: 0 5px;
      box-sizing: border-box;
    }
  }
</style>
