<template>

</template>
<script>
  export default {
    created(){
      let self = this
      localStorage.removeItem('userId')
      location.href = `${process.env.URL.FRIENDS}/#/logout`
    }
  }
</script>
