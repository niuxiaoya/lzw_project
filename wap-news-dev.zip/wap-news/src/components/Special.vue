<template>
  <div class="specialWrap">
    <ul class="newsMain" :class="{'no-data':newsData&&newsData.data.length<=0}">
      <li class="mainLi" v-for="item in newsData.data" @click="openDetail(item)">
        <div class="tit" v-if="item.cover_pic.length>=3">{{item.title}}</div>
        <ul v-if="item.cover_pic.length>=3">
          <li><img :src="item.cover_pic[0]"></li>
          <li><img :src="item.cover_pic[1]"></li>
          <li><img :src="item.cover_pic[2]"></li>
        </ul>
        <div v-if="item.cover_pic.length<3" class="isOne">
          <div class="oneImg">
            <img :src="item.cover_pic[0]">
          </div>
          <div class="oneMain">
            <p class="oneTit">
              {{item.title}}
            </p>
            <div><p>{{item.author}} <span>{{item.publish_time}}</span></p><span><img src="../assets/images/news/message.png">{{item.comment_num}}</span></div>
          </div>
        </div>
        <div class="foo" v-if="item.cover_pic.length>=3">
          <p>{{item.name}}<span>{{item.date}}</span></p>
          <span><img src="../assets/images/news/message.png">{{item.message}}</span>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>

  export default {
    data() {
      let lang = localStorage.getItem('lang');
      if (lang) {
        this.$i18n.locale = lang
      }
      return {
        navNum: 1,
        pageNum: 1,
        pageInfo: {},
        loading: false,//滚动最底部加载
        //列表数据
        newsData:{
          data:[]
        },
      }
    },
    methods: {
      openDetail(item){
        let self = this
        location.href = `${process.env.URL.NEWS}/#/detail?article_id=${item.aid}`
      }
    },
    created() {
      document.title = this.$t('specialList')
    },
    mounted() {
      let self = this
      let uid =localStorage.getItem('userId')
      if(!self.$route.params.sid){
        self.$router.push('/')
        return false
      }

      self.$http.get(`${process.env.API.NEWS}/news/articlelist?subject_id=${self.$route.params.sid}`).then(res=>{
        if(res.data.errcode==0){
          self.newsData = res.data
          for(let i=0;i<self.newsData.data.length;i++){
            self.newsData.data[i].cover_pic = self.newsData.data[i].content_pic.split(',')
            self.newsData.data[i].publish_time = self.$moment(self.newsData.data[i].publish_time*1000).format('YYYY-MM-DD')
          }
        }
      }).catch(err=>{
        console.log(err)
      })

    },
    components: {toolbar}//公共底部
  }
</script>
<!--当前页面样式-->
<style lang="less" scoped type="text/less">
  @media screen and (min-width: 410px) {
    .mainLi{
      ul{
        li{
          width: 120px!important;
          height: 120px!important;
        }
      }
    }
  }

  //导航栏样式
  .nav {
    height: 44px;
    width: 100%;
    display: flex;
    flex-wrap: nowrap;
    /*white-space:nowrap;*/
    /*overflow-x: scroll;*/
    /*overflow-y: hidden;*/
    font-size: 14px;
    border-bottom: 1px solid #f2f2f2;
    box-sizing: border-box;
    color: #333;
    background: #fff;
    position: fixed;
    z-index: 999;
    top:0;
    left: 0;
    li {
      width: 20%;
      height: 44px;
      line-height: 44px;
      color: #666;
      /*display: inline-block;*/
      /*text-align: center;*/
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      &.active {
        color: #333;
        &:before {
          width: 20px;
          height: 3px;
          background: #333;
          content: '';
          position: absolute;
          bottom: 0;
          left: calc(~'50% - 10px');
        }
      }
    }
  }

  //专题样式
  .special {
    width: 100%;
    padding: 15px;
    box-sizing: border-box;
    background: #fff;
    margin-top: 44px;
    img {
      width: 100%;
    }
  }

  //内容样式
  .newsMain {
    margin-top: 10px;
    margin-bottom: 80px;
    .mainLi {
      background: #fff;
      width: 100%;
      padding: 15px;
      box-sizing: border-box;
      color: #333;
      font-size: 14px;
      margin-bottom: 10px;
      .tit {
        width: 100%;
        overflow: hidden;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        word-break: break-all;
        margin-bottom: 15px;
      }
      ul {
        width: 100%;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        li {
          width: 110px;
          height: 110px;
          overflow: hidden;
          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
      }
      .isOne{
        display: flex;
        .oneImg{
          width: 110px;
          height: 110px;
          overflow: hidden;
          img{
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }
        .oneMain{
          width: calc(~'100% - 110px');
          padding-left:15px ;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          .oneTit{
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            word-break: break-all;
          }
          div{
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #999;
            p{
              span{
                padding-left: 15px;
              }
            }
            span{
              img{
                width: 12px;
                height: 12px;
                margin-right: 5px;
              }
            }
          }
        }
      }
      .foo{
        padding-top: 15px;
        display: flex;
        justify-content: space-between;
        color: #999;
        font-size: 12px;
        p{
          span{
            padding-left: 15px;
          }
        }
        span{
          img{
            width: 12px;
            height: 12px;
            margin-right: 5px;
          }
        }
      }
    }
  }
</style>
<!--公共less样式-->
<style lang="less">

</style>
