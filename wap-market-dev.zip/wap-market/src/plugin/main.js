export default {
  getObj:{
    data:[],
    get_list (vm, url, oldUrl) {
      let self = this
      url = `${url}`
      switch (oldUrl){
        case '/dict/movement':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              this.data.name = res.data.data.name
              vm.movementList = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/dict/shape':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              vm.shapeList = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/dict/function':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              vm.complex = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/dict/fineness':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              vm.conditionList = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/dict/material':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              vm.watchCase = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/dict/brand':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              vm.brandList = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/dict/bank':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              vm.bankList = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/user/bankcard':
          vm.$http.get(url).then((res) => {
            if(res.data.errcode=='0') {
              for (let i = 0; i <  res.data.data.length; i++) {
                res.data.data[i].cardnum =  res.data.data[i].cardnum.substring(0, 4)
              }
              vm.bankcardList = res.data.data
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        //请求我要买列表数据
        case '/market/buyer/goodsList':
          vm.$http.get(url).then((res) => {
            self.data = []
            if(res.data.errcode=='0') {
              for (let i=0;i<res.data.data.length;i++){
                self.data[i] = {}
                self.data[i].watchName = res.data.data[i].title //产品标题
                self.data[i].id = res.data.data[i].gid//产品id
                self.data[i].price = res.data.data[i].price //售价
                self.data[i].status_name = res.data.data[i].exchange_status_name//状态名称
                self.data[i].address = res.data.data[i].prov_name //地址
                self.data[i].browse = res.data.data[i].pv //浏览量
                self.data[i].imgUrl = res.data.data[i].cover_pic //封面图
              }
              vm.goodsList = vm.goodsList.concat(self.data)
              vm.pageInfo = res.data.page
              vm.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            }else {
              vm.goodsList = self.data
              console.log('error')
              vm.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        //请求收获地址列表数据
        case '/user/address':
          vm.$http.get(url).then((res) => {
            self.data = []
            if(res.data.errcode=='0') {
              for (let i=0;i<res.data.data.length;i++){
                self.data[i] = {}
                self.data[i].name = res.data.data[i].receiver
                self.data[i].tel = res.data.data[i].receiver_tel
                self.data[i].address = res.data.data[i].address
                self.data[i].is_default = res.data.data[i].is_default
                self.data[i].id = res.data.data[i].id
                self.data[i].city_name = res.data.data[i].city_name
                self.data[i].city_code = res.data.data[i].city_code
                self.data[i].prov_code = res.data.data[i].prov_code
                self.data[i].dist_code = res.data.data[i].dist_code
              }
              vm.addressList = self.data
            }else {
              vm.addressList = self.data
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
      }
    },
    get_push (vm,url,oldUrl){
      let self = this
      url = `${url}?nonce=${Math.random()}`
      self.data = {}
    },
    get_info(vm,url,oldUrl){
      let self = this
      url = `${url}`
      self.data = {}
      switch (oldUrl){
        case '/market/buyer/order':
          vm.$http.get(url).then((res)=>{
            if(res.data.errcode=='0'){
              self.data.price = res.data.data.price || ''//获取金额
              self.data.title = res.data.data.title || ''//获取标题
              self.data.name = res.data.data.name || ''//获取名字
              self.data.tel = res.data.data.tel || ''//获取号码
              self.data.address = res.data.data.address || ''//获取地址
              vm.watchInfo = self.data
            }
          }).catch((err)=>{
            console.log(err)
          })
          break;
        case '/market/buyer/orderplace':
          vm.$http.get(url).then((res)=>{
            if(res.data.errcode=='0'){
              self.data.price = res.data.data.goods.price || ''//获取金额
              self.data.title = res.data.data.goods.title || ''//获取标题
              self.data.name = res.data.data.default_address.receiver || ''//获取名字
              self.data.tel = res.data.data.default_address.receiver_tel|| ''//获取号码
              self.data.cover = res.data.data.goods.cover_pic ||''//获取封面
              self.data.address = res.data.data.default_address.address || ''//获取地址
              self.data.address_id = res.data.data.default_address.id || ''//获取地址

              self.data.paid_num = res.data.data.goods.paid_num || 0
              self.data.paid_num_cny = res.data.data.goods.paid_num_cny || 0
              self.data.unpaid_money = res.data.data.goods.unpaid_money || 0
              self.data.unpaid_money_cny = res.data.data.goods.unpaid_money_cny || 0
              vm.orderInfo = self.data
            }
          }).catch((err)=>{
            console.log(err)
          })
          break;
      }
    }
  },
  postObj:{
    data:{},
    post_data (vm, url, data,oldUrl) {
      let self = this
      url = `${url}?nonce=${Math.random()}`
      self.data = {}
      switch (oldUrl){
        case '/market/buyer/order':
          // self.data.buyer_uid = data.buyer_uid
          self.data.seller_uid = data.seller_uid
          self.data.gid = data.gid
          self.data.address_id = data.address_id
          self.data.delivery_method = data.delivery_method
          self.data.pay_method = data.pay_method
          vm.$http.post(url,self.data).then((res) => {
            if(res.data.errcode=='0') {
              // vm.movementList = res.data.data
              self.data.id =res.data.id
              location.href = `${process.env.URL.MARKET}/#/ordershow?gid=${ self.data.gid}&pay_method=${self.data.pay_method}&id=${res.data.id}`
            }else {
              vm.$messagebox.alert(res.data.msg)
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/user/upload':
          self.data.type = data.type
          self.data.file = data.file
          self.data.filename = data.filename
          vm.$http.post(url,self.data).then((res) => {
            if(res.data.errcode=='0') {
              vm.imgList.push(self.data.file)
              vm.postData.file_id.push(res.data.fileinfo.fid)
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/user/address':
          self.data.receiver = data.name
          self.data.receiver_tel = data.tel
          self.data.prov_code = data.prov_code
          self.data.city_code = data.city_code
          self.data.dist_code = data.dist_code
          self.data.address = data.address
          self.data.is_default = data.is_default
          if(!vm.flag){
            vm.flag = true
            vm.$http.post(url,self.data).then((res) => {
              if(res.data.errcode=='0') {
                vm.$toast({
                  message: vm.$t('saveSuccess'),
                  className:'bg'
                });
                setTimeout(()=>{
                  vm.$router.push('/addresslist')
                  vm.flag = true
                },2000)
              }else {
                console.log('error')
              }
            }).catch(() => {
              console.log('error')
            })
          }
          break;
        case '/user/bankcard':
          self.data.cardholder = data.cardholder
          self.data.cardnum = data.cardnum
          self.data.is_china = data.is_china
          self.data.bank_name = data.bank_name
          self.data.opening_bank = data.opening_bank
          vm.$http.post(url,self.data).then((res) => {
            if(res.data.errcode=='0') {
              vm.$toast({
                message: vm.$t('success'),
                className:'bg'
              });
              setTimeout(()=>{
                localStorage.removeItem('bankInfo')
                vm.$router.push('/banklist')
              },2000)
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/user/collect':
          self.data.collect_id = data.id
          self.data.type = data.type
          self.data.publish_uid = data.publish_uid
          vm.$http.post(url,self.data).then((res) => {
            if(res.data.errcode=='0') {
            }else{
              vm.$messagebox.alert(res.data.errmsg)
            }
          }).catch(() => {
            console.log('error')
          })
          break;
      }
    },
  },
  deleteObj:{
    delete_data (vm, url,oldUrl) {
      url = `${url}`
      switch (oldUrl){
        case '/user/bankcard':
          vm.$http.delete(url).then((res) => {
            if(res.data.errcode=='0') {
              vm.$router.push('/')
            }else {
              vm.$messagebox.alert(res.data.errmsg)
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/user/address':
          vm.$http.delete(url).then((res) => {
            if(res.data.errcode=='0') {
              // vm.countryList = res.data.data
              vm.$toast({
                message: vm.$t('deleteSuccess'),
                className:'bg'
              });
            }else {
              vm.countryList = []
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
        case '/user/collect':
          vm.$http.delete(url).then((res) => {
            if(res.data.errcode=='0') {
              // vm.countryList = res.data.data
            }else {
              vm.countryList = []
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
      }
    }
  },
  putObj:{
    data:{},
    put_data(vm,url,data,oldUrl){
      let self = this
      switch (oldUrl){
        case '/user/address':
          self.data.is_default = data.is_default
          self.data.id = data.id
          self.data.address = data.address
          self.data.receiver = data.name
          self.data.receiver_tel = data.tel
          self.data.prov_code = data.prov_code
          self.data.city_code = data.city_code
          self.data.dist_code = data.dist_code
          vm.$http.put(url,self.data).then((res) => {
            if(res.data.errcode=='0') {
              vm.$toast({
                message: vm.$t('editSuccess'),
                className:'bg'
              });
              for(let i =0;i<vm.addressList.length;i++){
                vm.addressList[i].is_default = 0
              }
              for(let i =0;i<vm.addressList.length;i++){
                if(vm.addressList[i].id==data.id){
                  vm.addressList[i].is_default = 1
                }
              }
              setTimeout(()=>{
                vm.$router.push('/addresslist')
              },2000)
            }else {
              console.log('error')
            }
          }).catch(() => {
            console.log('error')
          })
          break;
      }
    }
  },
  GetQueryString(name,data) {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    data = data||''
    let r = window.location.hash.replace(`#/${data}?`, '').match(reg);
    if (r != null) return unescape(r[2]);
    return null;
  }
}
