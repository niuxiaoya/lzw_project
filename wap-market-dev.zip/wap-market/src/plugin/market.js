import axios from '@/plugin/axios'
import Vue from 'vue'

let tip = new Vue({})

export default {
  get_list(obj) {
    let p = obj.list.pages.p || 1
    let rows = obj.list.pages.rows || 10
    let params = {
      p,
      rows
    }
    if (obj.data) {
      for (let key in obj.data) {
        params[key] = obj.data[key]
      }
    }
    axios.get(obj.url,{params:params}).then(res => {
      if (res.data.errcode=='0') {
        let res_data = res.data.data
        if (typeof obj.callback === 'function') {
          obj.callback(res, obj.model)
        } else {
          if(params.title){
            if(params.title && params.p>1){
              obj.list.data = obj.list.data.concat(res_data)
            }else{
              obj.list.data = []
            }
          }
          for (let key in res_data) {
           obj.list.data.push(new obj.model(res_data[key]))
          }
          obj.list.pages=res.data.page
          if (typeof obj.resultCallback === 'function') {
            obj.resultCallback(res, obj.model)
          }
        }
      } else {
        tip.$messagebox.alert(res.data.msg)
      }
    }).catch(err => {
      console.log(err)
    })
  },
  GetQueryString(name, data) {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    data = data || ''
    let r = window.location.hash.replace(`#/${data}?`, '').match(reg);
    if (r != null) return unescape(r[2]);
    return null;
  }
}
