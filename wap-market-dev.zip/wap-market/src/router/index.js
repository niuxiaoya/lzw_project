import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/pages/Index'

Vue.use(Router)

export default new Router({
  // mode: 'history',//打包项目要把mode: history注释掉
  // mode:'history',
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index
    },
    {
      path: '/sell',
      name: 'Sell',
      component:resolve=>require(['@/components/Sell'],resolve)
    },
    {
      path: '/bankcard',
      name: 'Bankcard',
      component:resolve=>require(['@/components/Bankcard'],resolve)
    },
    {
      path: '/confirm',
      name: 'Confirm',
      component:resolve=>require(['@/components/Confirm'],resolve)
    },
    {
      path: '/banklist',
      name: 'Banklist',
      component:resolve=>require(['@/components/Banklist'],resolve)
    },
    {
      path: '/search',
      name: 'Search',
      component:resolve=>require(['@/components/Search'],resolve)
    },
    {
      path: '/screen',
      name: 'Screen',
      component:resolve=>require(['@/components/Screen'],resolve)
    },
    {
      path: '/detail',
      name: 'Detail',
      component:resolve=>require(['@/components/Detail'],resolve)
    },
    {
      path: '/order',
      name: 'Order',
      component:resolve=>require(['@/components/Order'],resolve)
    },
    {
      path: '/ordershow',
      name: 'Ordershow',
      component:resolve=>require(['@/components/Ordershow'],resolve)
    },
    {
      path: '/addresslist',
      name: 'Addresslist',
      component:resolve=>require(['@/components/Addresslist'],resolve)
    },
    {
      path: '/address',
      name: 'Address',
      component:resolve=>require(['@/components/Address'],resolve)
    },
    {
      path: '/ios',
      name: 'Ios',
      component:resolve=>require(['@/components/Ios'],resolve)
    },
    {
      path: '/guarantee',
      name: 'Guarantee',
      component:resolve=>require(['@/components/Guarantee'],resolve)
    },
    {
      path: '/ground',
      name: 'Ground',
      component:resolve=>require(['@/components/Ground'],resolve)
    },
    {
      path: '/ground/list',
      name: 'GroundList',
      component:resolve=>require(['@/components/GroundList'],resolve)
    },
    {
      path: '/pay/explain',
      name: 'PayExplain',
      component:resolve=>require(['@/components/pay/Explain'],resolve)
    },
    {
      path: '/pay',
      name: 'Pay',
      component:resolve=>require(['@/components/pay/Pay'],resolve)
    },
    {
      path: '/pay/state',
      name: 'PayState',
      component:resolve=>require(['@/components/pay/PayState'],resolve)
    },
    {
      path: '/pay/retainage',
      name: 'PayRetainage',
      component:resolve=>require(['@/components/pay/Retainage'],resolve)
    },
    {
      path: '/pay/order',
      name: 'PayOrder',
      component:resolve=>require(['@/components/pay/Order'],resolve)
    }
  ]
})
