import Base from '@/model/base'
import Moment from 'moment'
import xhr from '@/plugin/market'
import Vue from 'vue'

let Market = class Market extends Base{
  constructor(data){
    data = data?data:{}
    data.current_model = Market //当前模型

    data.add_url = `${process.env.API.DICT}/admin/dict/brand`
    data.get_list_url = `${process.env.API.MARKET}/market/buyer/goodsList`
    data.get_detail_url = `${process.env.API.DICT}/admin/dict/brand`
    data.update_url = `${process.env.API.DICT}/admin/dict/brand`
    data.delete_url = `${process.env.API.DICT}/admin/dict/brand`
    super(data)

    this.type = data.type ||'create_time'
    this.title = data.title||''

    this.cover_fid = data.cover_fid || ''
    this.cover_pic = data.cover_pic || ''
    this.exchange_status = data.exchange_status || ''
    this.exchange_status_name = data.exchange_status_name || ''
    this.gid = data.gid || ''
    this.price = data.price || ''
    this.pv = data.pv || ''
    this.status = data.status || ''
    this.tit = data.title || ''
    this.totallists = {
      data: [],
      pages:{
        p: 0,
        rows:10,
        total_pages:1
      }
    }
  }

  setGetListParams(){
    return {
      order:this.type,
      title:this.title
    }
  }


  //获取列表数据
  get_market (list, callback) {
    let self = this
    xhr.get_list({
      url: this.get_list_url,
      list:list || this.totallists,
      data:this.setGetListParams(),
      model: this.current_model,
      resultCallback(res, model) {
        if(self.title){
      //    self.totallists.data = []
       //   self.totallists.data = self.totallists.data.concat(res.data.data)
        }else{
       //   self.totallists.data = self.totallists.data.concat(res.data.data)
        }
        if(typeof callback === 'function') {
          callback()
        }
      }
    })
  }
}

export default Market
