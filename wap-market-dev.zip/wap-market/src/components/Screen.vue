<template>
  <div class="screen">
    <div class="selStyle" @click="isBrand">
      <div>{{$t('isBrand')}}</div>
      <div :class="{'fooColor':brand==$t('brand')}">{{brand}} <img src="../assets/images/market/arrow.png"></div>
    </div>
    <div class="selStyle" @click="conditionHide">
      <div>{{$t('condition')}}</div>
      <div :class="{'fooColor':condition==$t('choose')}">{{condition}} <img src="../assets/images/market/arrow.png">
      </div>
    </div>
    <div class="money">
      <p class="moneyTie">{{$t('priceRange')}}</p>
      <div><input type="number" v-model="postData.money1">
        <p></p><input type="number" v-model="postData.money2"></div>
    </div>
    <div class="wrap">
      <p>{{$t('exchangeStatus')}}</p>
      <ul>
        <li v-for="item,index in exchangeList">
          <div :class="{'active':exchangeNum==index}" @click="exchangeClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
    </div>
    <div class="wrap">
      <p>{{$t('viewImg_360')}}</p>
      <ul>
        <li v-for="item,index in sixList">
          <div :class="{'active':sixNum==item.id}" @click="sixClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
    </div>
    <div class="wrap">
      <p>{{$t('movement')}}</p>
      <ul v-show="!movementShow">
        <li v-for="item,index in movementList" v-if="index<7">
          <div :class="{'active':movementNum==index}" @click="movementClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
      <ul v-show="movementShow">
        <li v-for="item,index in movementList">
          <div :class="{'active':movementNum==index}" @click="movementClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
      <div class="isDown" :class="{'isUp':movementShow}" @click="movementShow=!movementShow"
           v-if="movementList.length>7">
        <img src="../assets/images/market/detail/down.png">
      </div>
    </div>
    <div class="wrap">
      <p>{{$t('gender')}}</p>
      <ul>
        <li v-for="item,index in gender">
          <div :class="{'active':genderNum == index}" @click="genderClick(index)">
            {{item}}
          </div>
        </li>
      </ul>
    </div>
    <div class="wrap">
      <p>{{$t('material')}}</p>
      <ul v-show="!materialShow">
        <li v-for="item,index in watchCase" v-if="index<=7">
          <div :class="{'active':watchCaseNum==index}" @click="watchCaseClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
      <ul v-show="materialShow">
        <li v-for="item,index in watchCase">
          <div :class="{'active':watchCaseNum==index}" @click="watchCaseClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
      <div class="isDown" :class="{'isUp':materialShow}" @click="materialShow=!materialShow" v-if="watchCase.length>7">
        <img src="../assets/images/market/detail/down.png">
      </div>
    </div>
    <div class="wrap">
      <p>{{$t('shape')}}</p>
      <ul v-show="!shapeShow">
        <li v-for="item,index in shapeList" v-if="index<=7">
          <div :class="{'active':shapeNum==index}" @click="shapeClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
      <ul v-show="shapeShow">
        <li v-for="item,index in shapeList">
          <div :class="{'active':shapeNum==index}" @click="shapeClick(item,index)">
            {{item.name}}
          </div>
        </li>
      </ul>
      <div class="isDown" :class="{'isUp':shapeShow}" @click="shapeShow=!shapeShow" v-if="shapeList.length>7">
        <img src="../assets/images/market/detail/down.png">
      </div>
    </div>
    <div class="wrap">
      <p>{{$t('diameter')}}</p>
      <ul v-show="!diameterShow">
        <li v-for="item,index in diameterList" v-if="diameterList.length<=7">
          <div :class="{'active':diameterNum==index}" @click="diameterClick(item,index)">
            {{item}}
          </div>
        </li>
      </ul>
      <ul v-show="diameterShow">
        <li v-for="item,index in diameterList">
          <div :class="{'active':diameterNum==index}" @click="diameterClick(item,index)">
            {{item}}
          </div>
        </li>
      </ul>
      <div class="isDown" :class="{'isUp':diameterShow}" @click="diameterShow=!diameterShow"
           v-if="diameterList.length>7">
        <img src="../assets/images/market/detail/down.png">
      </div>
    </div>
    <div class="wrap">
      <p>{{$t('function_name')}}</p>
      <ul v-show="!functionShow">
        <li v-for="item,index in complex" v-if="index<=7">
          <div :class="{'active':item.wrap}" @click="complexClick(item,index)">
            {{item.manage.name}}
          </div>
        </li>
      </ul>
      <ul v-show="functionShow">
        <li v-for="item,index in complex">
          <div :class="{'active':item.wrap}" @click="complexClick(item,index)">
            {{item.manage.name}}
          </div>
        </li>
      </ul>
      <div class="isDown" :class="{'isUp':functionShow}" @click="functionShow=!functionShow" v-if="complex.length>7">
        <img src="../assets/images/market/detail/down.png">
      </div>
    </div>
    <div style="width: 100%;height: 50px"></div>
    <div class="btn">
      <span @click="sub(1)">{{$t('reset')}}</span>
      <span @click="sub(2)">{{$t('confirm')}}</span>
    </div>
    <!--品牌弹窗显示-->
    <mt-popup v-model="brandShow" position="bottom" class="mint-popup-bottom" :modal="false">
      <div class="close">
        <img src="../assets/images/market/close.png" @click="brandShow = false">
      </div>
      <div style="height: 44px;width: 100%"></div>
      <mt-index-list>
        <mt-index-section v-for="item,index in brandList" :index="item.initial.toString()" :key="index">
          <mt-cell v-for="cell,num in item.list" @click.native="brandClick(cell)" :key="num" class="brandStyle">
            <img :src="cell.pic" alt=""><span>{{cell.name}}</span>
          </mt-cell>
        </mt-index-section>
      </mt-index-list>
    </mt-popup>
    <!--成色弹出显示-->
    <mt-popup v-model="conditionShow" position="bottom" class="mint-popup-bottom" :modal="false">
      <div class="close">
        <img src="../assets/images/market/close.png" @click="conditionHide(1)">
      </div>
      <div style="height: 44px;width: 100%"></div>
      <ul class="condition">
        <li v-for="item in conditionList" @click="conditionClick(item)">
          <p>【{{item.name}}】</p>
          <!--<span v-if="item.details!=''">{{item.details}}</span>-->
        </li>
      </ul>
    </mt-popup>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        brand: this.$t('brand'),
        shapeNum: null,
        genderNum: null,
        moneyNum: null,
        movementNum: null,
        exchangeNum: null,
        watchCaseNum: null,
        isProcess: true,
        number: null,
        brandShow: false,
        conditionShow: false,
        sixNum:null,
        diameterNum: null,
        movementShow: false,
        materialShow: false,
        shapeShow: false,
        diameterShow: false,
        functionShow: false,
        bankcardList: [],
        sixList: [
          {
            name: this.$t('all_360'),
            id: 0
          }, {
            name: this.$t('yes_360'),
            id: 1
          }, {
            name: this.$t('no_360'),
            id: -1
          }
        ],
        diameterList: [
          '36mm以下',
          '36-39mm',
          '39-42mm',
          '42-45mm',
          '45mm以上'
        ],
        exchangeList: [
          {
            name: this.$t('sale'),
            key: 'sale'
          },
          {
            name: this.$t('sold'),
            key: 'sold'
          }
        ],
        condition: this.$t('choice'),
        gender: [this.$t('sex.man'), this.$t('sex.lady'), this.$t('sex.neutral')],
        brandList: [],
        conditionList: [],
        shapeList: [],
        watchCase: [],
        complex: [],
        movementList: [],
        postData: {
          diameter_l: '',
          diameter_h: '',
          brand_id: '',
          money1: '',
          money2: '',
          material_id: '',
          shape_id: '',
          function_id: [],
          fineness: '',
          gender: '',
          movement_id: '',
          exchange_status: '',
          key: 1,
          is_360:''
        }
      }
    },
    methods: {
      isBrand(index) {
        let self = this
        self.brandShow = true
        document.title = this.$t('condition')
      },
      exchangeClick(item, index) {
        if (this.exchangeNum == index) {
          this.exchangeNum = null
          this.postData.exchange_status = ''
          return false
        }
        this.exchangeNum = index
        this.postData.exchange_status = item.key
      },
      sixClick(item,index){
        if(this.sixNum == item.id){
          this.sixNum = null
          this.postData.is_360 = ''
        }else{
          this.sixNum = item.id
          this.postData.is_360 = item.id
        }
      },
      moneyClick(index) {
        let self = this
        if (self.moneyNum == index) {
          self.postData.money1 = ''
          self.postData.money2 = ''
          self.moneyNum = null
          return false
        }
        switch (index) {
          case 1:
            self.postData.money1 = 0
            self.postData.money2 = 10
            setTimeout(() => {
              self.moneyNum = index
            })
            break;
          case 2:
            self.postData.money1 = 10
            self.postData.money2 = 50
            setTimeout(() => {
              self.moneyNum = index
            })
            break;
          case 3:
            self.postData.money1 = 50
            self.postData.money2 = 200
            setTimeout(() => {
              self.moneyNum = index
            })
            break
        }
      },
      genderClick(index) {
        let self = this
        if (index == self.genderNum) {
          self.genderNum = null
        } else {
          self.genderNum = index
          self.postData.gender = index + 1
        }
      },
      brandClick(cell) {
        let self = this
        self.brand = cell.name
        self.postData.brand_id = cell.id
        self.brandShow = false
      },
      conditionHide(index) {
        let self = this
        if (index == 1) {
          self.conditionShow = false
          document.title = this.$t('watchSell')
        } else {
          self.conditionShow = true
          document.title = this.$t('condition')
        }
      },
      conditionClick(item) {
        let self = this
        self.condition = item.name
        self.postData.fineness = item.id
        self.conditionShow = false
        document.title = this.$t('watchSell')
      },
      watchCaseClick(item, index) {
        let self = this
        if (index == self.watchCaseNum) {
          self.watchCaseNum = null
          self.postData.material_id = ''
        } else {
          self.watchCaseNum = index
          self.postData.material_id = item.id
        }
      },
      complexClick(item, index) {
        let self = this
        if (!self.complex[index].wrap) {
          self.complex[index].wrap = true
          self.postData.function_id.push(item.manage.id)
        } else {
          self.complex[index].wrap = false
          for (let i = 0; i < self.complex.length; i++) {
            if (self.postData.function_id[i] == item.manage.id) {
              self.postData.function_id.splice(i, 1)
            }
          }
        }
      },
      shapeClick(item, index) {
        let self = this
        if (self.shapeNum == index) {
          self.shapeNum = null
          self.postData.shape_id = ''
        } else {
          self.shapeNum = index
          self.postData.shape_id = item.id
        }
      },
      movementClick(item, index) {
        let self = this
        if (self.movementNum == index) {
          self.movementNum = null
          self.postData.movement_id = ''
        } else {
          self.movementNum = index
          self.postData.movement_id = item.id
        }
      },
      diameterClick(item, index) {
        let self = this
        if (self.diameterNum == index) {
          self.diameterNum = null
        } else {
          self.diameterNum = index
          switch (index) {
            case 0:
              self.postData.diameter_l = 0
              self.postData.diameter_h = 36
              break;
            case 1:
              self.postData.diameter_l = 36
              self.postData.diameter_h = 39
              break;
            case 2:
              self.postData.diameter_l = 39
              self.postData.diameter_h = 42
              break;
            case 3:
              self.postData.diameter_l = 42
              self.postData.diameter_h = 45
              break;
            case 4:
              self.postData.diameter_l = 45
              self.postData.diameter_h = -1
              break;
          }
        }
      },
      sub(index) {
        let self = this
        if (index == 1) {
//          this.$router.push('/')
          location.reload()
        } else {
          if (this.$route.query.isGround == 1) {
            this.$router.push({name: 'GroundList', params: this.postData, query: {aid: this.$route.query.aid}})
          } else {
            this.$router.push({name: 'Index', params: this.postData})
            document.title = this.$t('watchSell')
          }
        }
      },
    },
    mounted() {
      let self = this
      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/brand`, '/dict/brand')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/material`, '/dict/material')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/fineness`, '/dict/fineness')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/function`, '/dict/function')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/shape`, '/dict/shape')

      self.$fun.getObj.get_list(self, `${process.env.API.USER}/user/bankcard`, '/user/bankcard')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/movement`, '/dict/movement')
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .demo {
    display: flex;
    flex-wrap: wrap;
    div {
      display: flex;
      p {
        width: 100px;
      }
    }
  }

  .screen {
    padding: 0 0 15px 15px;
    background: #fff;
    margin-bottom: 30px;
    height: 100vh;
    overflow-y: scroll;
    .money {
      border-bottom: 1px solid #f2f2f2;
      .moneyTie {
        font-size: 12px;
        color: #999;
        padding: 15px 0 10px;
      }
      div {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
        p {
          width: 66px;
          display: inline-block;
          height: 1px;
          background: #999;
        }
        input {
          background: #ecf0f4;
          width: 100px;
          min-height: 32px;
          text-align: center;
          &:first-child {
            margin-right: 7.5px !important;
          }
          &:last-child {
            margin-left: 7.5px !important;
          }
        }

      }
      ul {
        display: flex;
        li {
          width: 25%;
          display: flex;
          align-items: center;
          div {
            width: 80%;
            height: 24px;
            background: #ecf0f4;
            text-align: center;
            font-size: 12px;
            color: #333;
            display: flex;
            justify-content: center;

            &.active {
              background: #333;
              color: #fff;
            }
          }
        }
      }
    }
    .wrap {
      border-bottom: 1px solid #f2f2f2;
      padding-bottom: 15px;
      p {
        padding: 15px 0;
      }
      ul {
        display: flex;
        flex-wrap: wrap;
        li {
          width: 25%;
          display: flex;
          margin-bottom: 10px;
          box-sizing: border-box;
          div {
            width: 80px;
            height: 24px;
            background: #ecf0f4;
            box-sizing: border-box;
            color: #333;
            text-align: center;
            font-size: 12px;
            line-height: 24px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            &.active {
              background: #333;
              color: #fff;
            }
          }
        }
      }
      .isDown {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding-top: 10px;
        box-sizing: border-box;
        img {
          width: 12px;
          height: 7px;
          display: block;
          transition: all 0.3s;
        }
        &.isUp {
          img {
            transform: rotate(180deg);
          }
        }
      }
    }
    .selStyle {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 44px;
      border-bottom: 1px solid #f2f2f2;
      input {
        border: none;
        text-align: right;
        padding-right: 10px;
        box-sizing: border-box;
      }
      div {
        color: #333;
        font-size: 14px;
        padding-right: 15px;
        span {
          color: #999;
          font-size: 12px;
          &.rmb {
            font-size: 14px;
            color: #333;
          }
        }
        img {
          width: 7px;
          height: 12px;
        }
      }
    }
    .fooColor {
      color: #ccc !important;
    }
    .condition {
      padding: 0 15px;
      li {
        color: #333;
        font-size: 14px;
        display: flex;
        min-height: 44px;
        padding: 10px 0;
        border-top: 1px solid #f2f2f2;
        box-sizing: border-box;
        &:last-child {
          border-bottom: 1px solid #f2f2f2;
        }
        p {
          max-width: 150px;
        }
        span {
          display: inline-block;
          padding-top: 2px;
          width: calc(~'100% - 150px');
          font-size: 12px;
          color: #666;
          padding-left: 10px;
        }
      }
    }
    .btn {
      position: fixed;
      width: 100%;
      height: 44px;
      border-top: 1px solid #f2f2f2;
      bottom: 0;
      left: 0;
      display: flex;
      align-items: center;
      span {
        display: inline-block;
        width: 50%;
        text-align: center;
        height: 44px;
        line-height: 44px;
        background: #fff;
        z-index: 999;
        &:last-child {
          background: #333;
          color: #fff;
        }
      }
    }
  }
</style>
<style lang="less" type="text/less">
  body {
    padding: 0;
  }

  .brandStyle {
    display: flex !important;
    align-items: center;
    span {
      color: #333;
    }
    .mint-cell-title {
      flex: 0;
    }
    img {
      width: 60px;
      height: 30px;
      margin-right: 10px;
    }
  }
</style>
