<template>
  <div class="pay">
    <header class="head">
      <div class="tit">{{$t('retainage')}}</div>
      <div class="content">
        US{{orderInfo.unpaid_money}}
        <span>
          ({{$t('rmb')}}{{orderInfo.unpaid_money_cny}})
        </span>
      </div>
    </header>
    <main class="main">
      <ul class="payMethods">
        <li v-for="item,index in payList" :key="index" @click="payNum=index">
          <div class="rightWrap">
            <img :src="item.icon" :alt="item.title">
            <div>
              {{item.title}}
              <p>
                {{item.content}}
              </p>
            </div>
          </div>
          <span :class="{active:index==payNum}"></span>
        </li>
      </ul>
      <div class="kf" @click="detail">
        {{$t('contact_kf')}}
        <img src="../../assets/images/market/newArrow.png">
      </div>
    </main>
    <div class="sub" @click="sub">
      {{$t('confirm_pay')}}
    </div>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        payNum:0,
        payList:[
          {
            icon:require('../../assets/images/market/pay/line.png'),
            title:this.$t('accounts'),
            content:this.$t('accounts_text')
          }
        ],
        orderInfo:{},
        postData:{
          gid:''
        }
      }
    },
    methods:{
      detail(){
        location.href = `${process.env.URL.USER}/#/email`
      },
      sub(){
//        self.$router.push({path:'/ordershow',query:{gid:self.postData.gid,pay_method:self.postData.pay_method,id:res.data.id}})
        this.$router.push({path:'/orderShow',query:{pay_method:1,gid:this.$route.query.gid}})
      }
    },
    created(){
      document.title = this.$t('choice_pay')
    },
    mounted(){
      let self = this
      self.postData.gid  =self.$route.query.gid
      if(self.postData.gid){
        self.$fun.getObj.get_info(self,`${process.env.API.MARKET}/market/buyer/orderplace?gid=${self.postData.gid}`,'/market/buyer/orderplace')
      }
    }
  }
</script>
<style lang="less" type="text/less" scoped>
  .pay{
    .head{
      margin-top: 10px;
      font-size: 12px;
      color: #999;
      padding: 15px;
      background: #fff;
      display: flex;
      flex-direction: column;
      .tit{
        width: 100%;
        font-weight: normal;
      }
      .content{
        margin-top: 15px;
        font-size: 20px;
        color: #ec4e4e;
        font-weight: bold;
        display: flex;
        flex-direction: column;
        width: 100%;
        span{
          color: #999;
          font-size: 12px;
          font-weight: normal;
          margin-top: 5px;
        }
      }
    }
    .main{
      margin-top: 10px;
      .payMethods{
        width: 100%;
        background: #fff;
        li{
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 72px;
          padding: 0 15px;
          box-sizing: border-box;
          position: relative;
          &:before{
            content: '';
            width: calc(~'100% - 15px');
            height: 1px;
            background: #f2f2f2;
            position: absolute;
            right: 0;
            bottom: 0;
          }
          &:last-child{
            &:before{
              content: '';
              width: 0;
              height: 0;
            }
          }
          .rightWrap{
            display: flex;
            align-items: center;
            font-size: 16px;
            color: #1c1b21;
            font-weight: bold;
            width: calc(~'100% - 18px');
            div{
              width: calc(~'100% - 42px');
              p{
                font-size: 12px;
                color: #999;
                margin-top: 5px;
                font-weight: normal;
              }
            }
            img{
              width: 27px;
              height: auto;
              margin-right: 15px;
            }
          }
          span{
            width: 18px;
            height: 18px;
            background-image: url("../../assets/images/market/pay/noselected.png");
            background-size: cover;
            background-repeat: no-repeat;
            transition: all .3s;
            &.active{
              background-image: url("../../assets/images/market/pay/selected.png");
            }
          }
        }
      }
      .kf{
        height:44px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 14px;
        color: #333;
        background: #fff;
        padding: 0 15px;
        box-sizing: border-box;
        margin-top: 10px;
        img{
          width: 8px;
          height: 12px;
        }
      }
    }
    .sub{
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #ec4e4e;
      font-size: 16px;
      color: #fff;
    }
  }
</style>
