<template>
  <div class="say">
    <div>
      {{info.title}}：
    </div>
    <p v-html="info.content"></p>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        info:{}
      }
    },
    mounted(){
      let self = this
      self.$http.get(`${process.env.API.NEWS}/news/agreement?name=COSTINFO`).then(res=>{
        if(res.data.errcode=='0'){
          self.info = res.data.data
          document.title = self.info.title
        }
      })
    }
  }
</script>
<style type="text/less" lang="less" scoped>
  .say{
    padding: 15px;
    box-sizing: border-box;
    background: #fff;
    div{
      font-size: 14px;
      color: #333;
      position: relative;
      height: 44px;
      line-height: 44px;
      &:before{
        content: '';
        position: absolute;
        width: calc(~'100% + 15px');
        height: 1px;
        background: #f2f2f2;
        right: -15px;
        bottom: 0;
      }
    }
    p{
      padding-top: 15px;
      font-size: 12px;
      color: #999;
      line-height: 24px;
    }
  }
</style>
