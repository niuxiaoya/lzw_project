<template>
  <div class="pay">
    <header class="head">
      <div class="tit">
        {{$t('bond')}}
      </div>
      <div class="content">
        US{{orderInfo.paid_num}}
        <span>
          ({{$t('rmb')}}{{orderInfo.paid_num_cny}})
        </span>
      </div>
    </header>
    <main class="main">
      <ul class="payMethods">
        <li v-for="item,index in payList" :key="index" @click="payNum=index">
          <div>
            <img :src="item.icon" :alt="item.title">
            {{item.title}}
          </div>
          <span :class="{active:index==payNum}"></span>
        </li>
      </ul>
    </main>
    <div class="sub" @click="pay">
      {{$t('confirm_pay')}}
    </div>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        payNum:0,
        payList:[
          {
            icon:require('../../assets/images/market/pay/zfb.png'),
            title:this.$t('zfb')
          }
        ],
        orderInfo:{},
        postData:{
          gid:''
        }
      }
    },
    methods:{
      pay(){
       let self = this
//       location.href = `https://api.swisstimevip.cn/market/index/payment/alipay_wap?gid=${self.postData.gid}`
       location.href = `https://api.swisstimevip.cn/market/index/payment/alipay_wap?gid=bf152372ab776400d27f8b665d95ccb336fc28e8`
      }
    },
    created(){
      document.title = this.$t('choice_pay')
    },
    mounted(){
      let self = this
      self.postData.gid  =self.$route.query.gid
      if(self.postData.gid){
        self.$fun.getObj.get_info(self,`${process.env.API.MARKET}/market/buyer/orderplace?gid=${self.postData.gid}`,'/market/buyer/orderplace')
      }
    }
  }
</script>
<style lang="less" type="text/less" scoped>
  .pay{
    .head{
      font-size: 12px;
      color: #999;
      padding: 15px;
      background: #fff;
      margin-top: 10px;
      .tit{
        width: 100%;
        font-weight: normal;
      }
      .content{
        margin-top: 15px;
        font-size: 20px;
        color: #ec4e4e;
        font-weight: bold;
        display: flex;
        flex-direction: column;
        width: 100%;
        span{
          color: #999;
          font-size: 12px;
          font-weight: normal;
          margin-top: 5px;
        }
      }
    }
    .main{
      margin-top: 10px;
      .payMethods{
        width: 100%;
        background: #fff;
        li{
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 72px;
          padding: 0 15px;
          box-sizing: border-box;
          position: relative;
          &:before{
            content: '';
            width: calc(~'100% - 15px');
            height: 1px;
            background: #f2f2f2;
            position: absolute;
            right: 0;
            bottom: 0;
          }
          &:last-child{
            &:before{
              content: '';
              width: 0;
              height: 0;
            }
          }
          div{
            display: flex;
            align-items: center;
            font-size: 16px;
            color: #1c1b21;
            font-weight: bold;
            img{
              width: 24px;
              margin-right: 15px;
            }
          }
          span{
            width: 18px;
            height: 18px;
            background-image: url("../../assets/images/market/pay/noselected.png");
            background-size: cover;
            background-repeat: no-repeat;
            transition: all .3s;
            &.active{
              background-image: url("../../assets/images/market/pay/selected.png");
            }
          }
        }
      }
    }
    .sub{
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #ec4e4e;
      font-size: 16px;
      color: #fff;
    }
  }
</style>
