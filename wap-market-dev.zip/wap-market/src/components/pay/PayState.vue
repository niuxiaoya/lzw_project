<template>
  <div class="payState">
    <header class="head">
      <img src="../../assets/images/market/pay/pay_success.png" v-if="$route.query&&$route.query.trade_no">
      <img src="../../assets/images/market/pay/pay_error.png" v-if="$route.query&&!$route.query.trade_no">
      <div>
        {{$route.query&&$route.query.trade_no?$t('pay_success'):$t('pay_error')}}
        <!--<p v-if="false">测试一下失败</p>-->
      </div>
    </header>
    <main class="main">
      <ul>
        <li @click="detail(0)" v-if="$route.query&&$route.query.trade_no">
          <div>
            {{$t('pay_retainage')}}(<span>US{{orderInfo.unpaid_money}}</span>)
          </div>
          <img src="../../assets/images/market/newArrow.png">
        </li>
        <li @click="detail(1)">
          <div>
           {{$t('view_order')}}
          </div>
          <img src="../../assets/images/market/newArrow.png">
        </li>
        <li @click="detail(2)">
          <div>
            {{$t('contact_kf')}}
          </div>
          <img src="../../assets/images/market/newArrow.png">
        </li>
      </ul>
    </main>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        orderInfo:{

        }
      }
    },
    methods:{
      detail(index){
        switch (index) {
          case 0:
            this.$router.push({path:'/pay/retainage',query:{gid:this.$route.query.gid}})
            break;
          case 1:
            this.$router.push({path:'/pay/order',query:{bill_sn:this.$route.query.out_trade_no}})
            break;
          case 2:
            location.href = `${process.env.URL.USER}/#/email`
            break;
        }
      }
    },
    created(){
      document.title = this.$t('pay_result')
    },
    mounted(){
      let self = this
      if(self.$route.query.gid){
        self.$fun.getObj.get_info(self,`${process.env.API.MARKET}/market/buyer/orderplace?gid=${self.$route.query.gid}`,'/market/buyer/orderplace')
      }
    }
  }
</script>
<style type="text/less" lang="less" scoped>
  .head{
    font-size: 20px;
    font-weight: bold;
    color: #333;
    padding: 30px 15px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    background: #fff;
    margin: 10px 0;
    div{
      p{
        font-size: 12px;
        color: #ec4e4e;
        margin-top: 5px;
      }
    }
    img{
      width: 32px;
      height: 32px;
      margin-right: 15px;
    }
  }
  .main{
    background: #fff;
    ul{
      li{
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 15px;
        height: 44px;
        font-size: 14px;
        color: #333;
        position: relative;
        &:before {
          content: '';
          position: absolute;
          width: calc(~'100% - 15px');
          height: 1px;
          background: #f2f2f2;
          right: 0;
          bottom: 0;
        }
        &:last-child{
          &:before{
            content: '';
            width: 0;
            height: 0;
          }
        }
        div{
          span{
            color: #ec4e4e;
          }
        }
        img{
          width: 8px;
          height: 12px;
        }
      }
    }
  }
</style>
