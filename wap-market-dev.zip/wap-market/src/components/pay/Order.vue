<template>
  <div class="order">
    <header class="head">
      <div>
        {{$t('orderPrice')}}
      </div>
      <span>
        US{{orderInfo.pay_money}}
      </span>
    </header>
    <main class="main">
      <ul>
        <li>
          {{$t('order_type')}}
          <span>
            {{orderInfo.pay_kind_str}}
          </span>
        </li>
        <li>
          {{$t('current_state')}}
          <span>
            {{orderInfo.is_refund_str}}
          </span>
        </li>
        <li>
          {{$t('pay_time')}}
          <span>
            {{orderInfo.pay_time}}
          </span>
        </li>
        <li>
          {{$t('payMethod')}}
          <span>
            {{orderInfo.pay_method_str}}
          </span>
        </li>
        <li>
          {{$t('number')}}
          <span>
            {{orderInfo.order_bill_sn}}
          </span>
        </li>
      </ul>
    </main>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        orderInfo:[]
      }
    },
    mounted(){
      let self = this
      self.$http.get(`${process.env.API.MARKET}/market/buyer/payinfo`,{params:{pay_kind:2,bill_sn:self.$route.query.bill_sn}}).then(res=>{
        if(res.data.errcode=='0'){
            self.orderInfo = res.data.data[0]
            self.orderInfo.pay_time = self.$moment(self.orderInfo.pay_time*1000).format('YYYY-MM-DD')
        }
      }).catch(err=>{
        console.log(err)
      })
    }
  }
</script>
<style type="text/less" lang="less" scoped>
  .order{
    background: #fff;
    margin-top: 10px;
    .head{
      font-size: 16px;
      color: #999;
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 50px;
      padding: 0 15px;
      box-sizing: border-box;
      position: relative;
      &:before{
        content: '';
        position: absolute;
        width: calc(~'100% - 15px');
        height: 1px;
        right: 0;
        bottom: 0;
        background: #f2f2f2;
      }
      span{
        font-weight: bold;
        color: #333;
      }
    }
    .main{
      ul{
        li{
          padding: 10px 15px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 12px;
          color: #999;
        }
      }
    }
  }
</style>
