<template>
  <ul class="foo">
    <li @click="open(1)">
      <span class="foo1"></span>
    </li>
    <li @click="open(2)">
      <span class="foo2"></span>
    </li>
    <li @click="open(5)">
      <div>
        <img src="../assets/images/toolbar/ground.png">
      </div>
    </li>
    <li @click="open(3)" :class="{'fooActive':fooNum==1}">
      <span class="foo3" :class="{'foo3Active':fooNum==1}"></span>
    </li>
    <li @click="open(4)">
      <span class="foo4" :class="{'newData':userInfo&&userInfo.new_data_sum>0}"></span>
    </li>
  </ul>
</template>
<script>
  export default {
    props:['type'],
    data() {
      return {
        fooNum: 0,
        userInfo:{}
      }
    },
    methods: {
      open(index) {
        let self = this
        switch (index) {
          case 1:
            location.href = `${process.env.URL.FRIENDS}/#/`
            break;
          case 2:
            location.href = `${process.env.URL.VIP}/#/`
            break;
          case 3:
            location.href = `${process.env.URL.MARKET}/#/`
            break;
          case 4:
            location.href = `${process.env.URL.USER}/#/`
            break;
          case 5:
            location.href = `${process.env.URL.MARKET}/#/ground`
            break;
        }
      }
    },
    mounted(){
      this.fooNum = this.type
      setTimeout(()=>{
        this.userInfo = this.$store.state.userInfo
      },600)
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .foo {
    position: fixed;
    z-index: 1999;
    bottom: 0;
    left: 0;
    width: 100%;
    display: flex;
    flex-wrap: nowrap;
    border-top: 1px solid #f2f2f2;
    background: #fff;

    li {
      display: flex;
      flex-direction: column;
      align-items: center;
      height: 45px;
      justify-content: center;
      width: 20%;
      box-sizing: border-box;
      font-size: 12px;
      color: #999;
      div{
        height: 45px;
        width: 45px;
        img{
          width: 100%;
          height: 100%;
        }
      }
      &.fooActive {
        color: #333;
      }
      span {
        width: 27px;
        height: 23px;
        margin: 0 2px 2px 0;
        background-size: cover;
        background-repeat: no-repeat;
        position: relative;
        &.newData{
          &:before{
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: #ff6969;
          }
        }
        &.foo1 {
          background-image: url('../assets/images/toolbar/home.png');
        }

        &.foo2 {
          background-image: url('../assets/images/toolbar/vip.png');
        }

        &.foo3 {
          background-image: url('../assets/images/toolbar/watch.png');
        }

        &.foo4 {
          background-image: url('../assets/images/toolbar/my.png');
        }

        &.foo1Active {
          background-image: url('../assets/images/toolbar/homeActive.png');
        }

        &.foo2Active {
          background-image: url('../assets/images/toolbar/vipActive.png');
        }

        &.foo3Active {
          background-image: url('../assets/images/toolbar/watchActive.png');
        }

        &.foo4Active {
          background-image: url('../assets/images/toolbar/myActive.png');
        }

      }
      img {
        width: 34px;
        margin-right: 1px;
        margin-bottom: 2px;
      }

    }
  }
</style>
