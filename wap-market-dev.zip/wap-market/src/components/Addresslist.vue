<template>
  <div class="address">
    <div class="add" @click="$router.push('/address')">
      {{$t('addLocation')}}
      <img src="../assets/images/market/arrow.png">
    </div>
    <ul class="main">
      <li v-for="(item,index) in addressList">
        <div class="info">{{item.name}} <span>{{item.tel}}</span></div>
        <div class="main">{{item.address}}</div>
        <div class="foo">
          <p class="default" @click="radioShow(item,index)"><span :class="{'active':item.is_default==1}"></span>{{$t('isDefault')}}</p>
          <p class="fooLast">
            <span @click="editShow(item)"><img src="../assets/images/market/detail/edit.png"></span>
            <span @click="delShow(item)"><img src="../assets/images/market/detail/delete.png"></span>
          </p>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
  export default {
    data (){
      return{
        addressList:[],
        flag:false
      }
    },
    methods:{
      radioShow(item,index){
        let self = this
        if( item.is_default==1){
          return false
        }
//        for (let i=0;i<self.addressList.length;i++){
//          self.addressList[i].is_default = 0
//        }
        self.$fun.putObj.put_data(self,`${process.env.API.USER}/user/address`,{is_default:1,id:item.id},'/user/address')
      },
      editShow(item){
        let self = this
        self.$router.push({name:'Address',params:item})
      },
      delShow(item){
        let self = this
        self.$fun.deleteObj.delete_data(self,`${process.env.API.USER}/user/address?id=${item.id}`,'/user/address')
        setTimeout(()=>{
          self.$fun.getObj.get_list(self,`${process.env.API.USER}/user/address`,'/user/address')
        },300)
      }
    },
    mounted(){
      let self = this
      self.$fun.getObj.get_list(self,`${process.env.API.USER}/user/address`,'/user/address')
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .address{
    font-size: 14px;
    color: #333;
    .add{
      height: 44px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #fff;
      margin: 10px 0;
      padding: 0 15px;
      img{
        width: 7px;
        height: 12px;
      }
    }
    .main{
      li{
        padding-left: 15px;
        margin-bottom: 10px;
        background: #fff;
        font-size: 14px;
        color: #333;
        div{
          &.info{
            padding-top: 15px;
            span{
              margin-left: 15px;
            }
          }
          &.main{
            padding: 10px 0 15px;
            line-height: 22px;
          }
          &.foo{
            color: #999;
            border-top: 1px solid #f2f2f2;
            padding-right: 15px;
            display: flex;
            justify-content: space-between;
            .fooLast{
              display: flex;
              align-items: center;
              height: 44px;
              span{
                display: flex;
                align-items: center;
                &:last-child{
                  margin-left: 30px;
                }
              }
              img{
                width: 14px;
                height: 14px;
                margin-right: 5px;
                display: inline-block;
              }
            }
          }
        }
      }
    }
  }
</style>
<style lang="less">
  body{
    background: #ecf0f4;
  }
</style>
