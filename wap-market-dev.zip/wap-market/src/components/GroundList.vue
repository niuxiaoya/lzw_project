<template>
  <div class="groundList" :class="{'isHid':popupVisible}">
    <div class="banner">
      <img :src="banner.cover_pic">
    </div>
    <div class="nav" :class="{'topShow':top>280}">
      <div @click="popupClick(1)" :class="{'active':popupVisible}">
        {{$t('sort')}}
        <img src="../assets/images/market/ground/down.png">
      </div>
      <div @click="$router.push({name:'Screen',query:{isGround:1,aid:aid}})">
        {{$t('screen')}}
        <img src="../assets/images/market/ground/down.png">
      </div>
    </div>
    <div class="watchList">
      <no-more v-if="marketList.data.length<=0" :style="{top:'0'}"></no-more>
      <ul id="watchWrap">
        <li v-for="item in marketList.data" @click="detailClick(item)">
          <img :src="item.cover_pic" :style="{height:imgHei}" class="imgBg">
          <div class="hotMainContent">
            <div class="hotMainContentTit">
              <span v-if="item.exchange_stage!=30">{{item.exchange_stage_name}}</span>
              <div :class="{'isChange':item.exchange_stage!=30}">
                {{item.title}}
              </div>
            </div>
            <p class="hotMainContentPrice" :class="{'isNew':item.original_price!=item.price}">
              {{item.price}}
            </p>
            <div class="hotMainContentFoo">
              <p v-if="item.original_price!=item.price">{{item.original_price}}</p>
              <span :class="{'isNew':item.original_price!=item.price}" v-if="item.fineness_name">
                {{item.fineness_name}}
              </span>
            </div>
          </div>
          <span class="is360" v-if="item.is_360==1">
            <img src="../assets/images/market/360.png">
          </span>
          <span class="lang">
            <img :src="item.country_flag">{{item.country_short_name}}
          </span>
        </li>
        <infinite-loading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="marketList.page.p>2">{{$t('noMore')}}</span>
          <span slot="no-results" v-show="marketList.page.p>2">{{$t('noMore')}}</span>
        </infinite-loading>
      </ul>
    </div>
    <mt-popup v-model="popupVisible" position="top" class="mint-popup-2 btnPop">
      <ul>
        <li v-for="item,key in nav" @click="navClick(item,key)" :class="{'active':key==num}">
        {{item.name}}<img src="../assets/images/market/ok.png" v-if="key==num">
        </li>
      </ul>
    </mt-popup>
    <toolbar :type="2"></toolbar>
  </div>
</template>
<script>
  import toolbar from '../components/toolbar'
  import InfiniteLoading from 'vue-infinite-loading'

  export default {
    data() {
      return {
        top: 0,
        locationName: this.$t('experienceAll'),
        popupVisible: false,
        num: 100,
        imgHei:0,
        aid:'',
        type:'',
        banner:{},
        marketList:{
          data:[],
          page:{
            p:0,
            total_pages:1
          }
        },
        postData:{
          diameter_l: '',
          diameter_h: '',
          brand_id: '',
          money1: '',
          money2: '',
          material_id: '',
          shape_id: '',
          function_id:[],
          fineness: '',
          gender: '',
          movement_id: '',
          exchange_status: '',
          key:1,
          is_360:''
        },
        nav:[
          {
            name:this.$t('pv_h'),
            type:'pv'
          },{
            name:this.$t('price_h'),
            type:'price_h'
          }, {
            name: this.$t('price_l'),
            type: 'price_l'
          },
        ],
      }
    },
    methods: {
      handleScroll() {
        this.top = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
      },
      detailClick(item){
        location.href = `${process.env.URL.MARKET}/#/detail?id=${item.gid}`
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (this.marketList.page.p > this.marketList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          this.marketList.page.p++
          let post = {
            order:self.type,
            title:self.tit,
            diameter_l:self.postData.diameter_l,
            diameter_h:self.postData.diameter_h,
            brand_id:self.postData.brand_id,
            price_l:self.postData.money1 || 0,
            price_h:self.postData.money2 || -1,
            material_id:self.postData.material_id,
            shape_id:self.postData.shape_id,
            fineness_id:self.postData.fineness,
            gender:self.postData.gender,
            movement_id:self.postData.movement_id,
            exchange_status:self.postData.exchange_status,
            p:this.marketList.page.p,
            is_360:self.postData.is_360,
            rows:10,
            acid:self.aid,function_id:self.postData.function_id
          }
          this.$http.get(`${process.env.API.MARKET}/market/buyer/goodsList`,{params:post}).then(res => {
            if (res.data.errcode == '0') {
              for(let value of res.data.data){
                value.file_pic = value.file_pic.split(',')
              }
              this.banner = res.data.banner
              document.title = res.data.banner.title
              this.marketList.data = this.marketList.data.concat(res.data.data)
              if(res.data.page){
                this.marketList.page = res.data.page
              }
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 500);
      },
      navClick(item, key) {
        let self = this
        if(key==self.num){
          self.popupVisible = !this.popupVisible
          return false
        }
        self.num = key
        self.popupVisible = !this.popupVisible
        self.type = item.type
        self.marketList = {
          data:[],
          page:{
            p:0,
            total_pages:1
          }
        }
        this.postData.brand_id =''
        this.postData.money1 = ''
        this.postData.money2 =''
        this.postData.material_id = ''
        this.postData.shape_id = ''
        this.postData.function_id = ''
        this.postData.fineness = ''
        this.postData.diameter_l = ''
        this.postData.diameter_h = ''
        this.postData.movement_id = ''
        this.postData.gender = ''
        this.postData.exchange_status = ''
        this.postData.is_360 = ''
        //重新刷新数据
        self.$nextTick(() => {
          self.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
        });
      },
      popupClick(index) {
        switch (index) {
          case 1:
            this.popupVisible = !this.popupVisible
            this.popupVisible1 = false
            break;
          case 2:
            this.popupVisible1 = !this.popupVisible1
            this.popupVisible = false
            break;
        }
      }
    },
    created() {
      let self = this
      self.aid = this.$route.query.aid
      self.imgHei = ((document.body.clientWidth - 10)/2-2.5)+'px'
    },
    mounted() {
      window.scrollTo(0, 0)
      window.addEventListener('scroll', this.handleScroll)
      if (this.$route.params.key==1) {
        this.$route.params.function_id = this.$route.params.function_id.join()
        this.postData.brand_id =this.$route.params.brand_id
        this.postData.money1 = this.$route.params.money1
        this.postData.money2 =this.$route.params.money2
        this.postData.material_id = this.$route.params.material_id
        this.postData.shape_id = this.$route.params.shape_id
        this.postData.function_id = this.$route.params.function_id
        this.postData.fineness = this.$route.params.fineness
        this.postData.diameter_l = this.$route.params.diameter_l
        this.postData.diameter_h = this.$route.params.diameter_h
        this.postData.movement_id = this.$route.params.movement_id
        this.postData.gender = this.$route.params.gender
        this.postData.exchange_status = this.$route.params.exchange_status
        this.postData.is_360 = this.$route.params.is_360
      }
    },
    components: {
      toolbar,
      InfiniteLoading
    }//公共底部
  }
</script>
<style lang="less" type="text/less">
  .groundList {
    &.isHid {
      overflow: hidden;
      height: 100vh;
    }
    .banner{
      width: 100%;
      height: 280px;
      position: relative;
      z-index: 9999;
      background: #fff;
      z-index: 10;
      img{
        width: 100%;
        height: 100%;
        display: block;
        object-fit: cover;
      }
    }
    .btnPop {
      top: 325px;
      width: 100%;
      ul {
        li {
          padding-left: 15px;
          display: flex;
          align-items: center;
          box-sizing: border-box;
          height: 44px;
          /*border-bottom: 1px solid #f5f5f5;*/
          justify-content: space-between;
          padding-right: 15px;
          font-size: 14px;
          &.active{
            background: #fafafa;
            border: none;
          }
        }
      }
    }
    .mint-swipe {
      /*height: 375px;*/
      color: #fff;
      font-size: 30px;
      text-align: center;
      position: relative;
      z-index: 9999;
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .nav {
      display: flex;
      height: 45px;
      background: #fff;
      width: 100%;
      box-sizing: border-box;
      position: relative;
      z-index: 9998;
      border-bottom: 1px solid #f2f2f2;
      &.topShow {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 10;
      }
      .active{
        img{
          transform: rotate(180deg);
        }
      }
      div {
        font-size: 14px;
        color: #999;
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        img {
          transition: all .5s;
          width: 6px;
          height: 4px;
          margin-left: 5px;
        }
      }
    }
    .watchList {
      color: #333;
      margin-bottom: 80px;
      position: relative;
      ul {
        display: flex;
        width: 100%;
        padding: 5px;
        box-sizing: border-box;
        justify-content: space-between;
        flex-wrap: wrap;
        li {
          display: flex;
          flex-direction: column;
          width: calc(~'50% - 2.5px');
          border: 1px solid #f2f2f2;
          box-sizing: border-box;
          background: #fff;
          margin-bottom: 5px;
          position: relative;
          .imgBg {
            width: 100%;
            object-fit: cover;
          }
          .is360{
            position: absolute;
            top: 10px;
            right: 10px;
            img{
              width: 22px;
              display: block;
            }
          }
          .lang {
            display: flex;
            align-items: center;
            font-size: 12px;
            color: #333;
            position: absolute;
            left: 8px;
            top: 10px;
            img {
              height: 16px;
              margin-right: 5px;
              display: block;
            }
          }
          .hotMainContent{
            width: 100%;
            padding: 15px 7.5px;
            box-sizing: border-box;
            font-size: 14px;
            .hotMainContentTit {
              width: 100%;
              margin-bottom: 10px;
              display: flex;
              align-items: center;
              div{
                width: 100%;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                font-weight: bold;
                &.isChange{
                  width: calc(~'100% - 40px');
                }
              }
              span{
                margin: 0;
                background: #ecf0f4;
                padding: 0 5px;
                font-size: 12px;
                display: block;
                color: #333;
                margin-right: 5px;
              }
            }
            .hotMainContentPrice {
              color: #666;
              margin-bottom: 10px;
              &.isNew{
                color: #eb4343;
              }
            }
            .hotMainContentFoo{
              display: flex;
              justify-content: space-between;
              align-items: center;
              font-size: 12px;
              p{
                color: #999;
                text-decoration:line-through;
              }
              span{
                border:1px solid #ccc;
                color: #333;
                padding: 0 3px;
                &.isNew{
                  color: #eb4343;
                  border-color: #eb4343;
                }
              }
            }
          }
        }
      }
    }
  }
</style>
