<template>
  <div class="order">
    <div class="address">
      <div class="addressNone" v-if="!orderInfo.name" @click="addressClick">
        {{$t('address')}}
        <span>{{addressName}} <img src="../assets/images/market/arrow.png" ></span>
      </div>
      <div class="addressTrue" v-if="orderInfo.name" @click="addressClick" >
        <div>
          <p>{{orderInfo.name}} <span>{{orderInfo.tel}}</span></p>
          <p>{{orderInfo.address}}</p>
        </div>
        <img src="../assets/images/market/arrow.png" >
      </div>
    </div>
    <div class="main">
      <div class="mainTit">
        <img :src="orderInfo.cover">
        <div>
          <p>{{orderInfo.title}}</p>
          <span>{{orderInfo.price}}</span>
        </div>
      </div>
      <div class="mainFoo">
        <p>
          {{$t('distribution')}}
        </p>
        <div>
          <span :class="{'active':postData.delivery_method==1}" @click="postData.delivery_method=1">{{$t('express')}}</span>
          <span :class="{'active':postData.delivery_method==2}" @click="postData.delivery_method=2">{{$t('delivery')}}</span>
        </div>
      </div>
      <div class="price">
        <div class="priceFirst">
          {{$t('bond')}}
          <p>
            US{{orderInfo.paid_num}}
            <span>({{orderInfo.paid_num_cny}})</span>
          </p>
        </div>
        <div class="priceLast">
          {{$t('retainage')}}
          <p>
            US{{orderInfo.unpaid_money}}
            <span>({{orderInfo.unpaid_money_cny}})</span>
          </p>
        </div>
      </div>
      <ul class="kf">
        <li @click="detail(1)">
          {{$t('contact_kf')}}
          <img src="../assets/images/market/newArrow.png">
        </li>
        <li @click="detail(2)">
          {{$t('explain')}}
          <img src="../assets/images/market/newArrow.png">
        </li>
      </ul>
      <ul class="process">
        <li>
          1、保证金支付完成后，客服人员会第一时间内联系到您，指引您完成完成尾款的支付。
        </li>
        <li>
          2、保证金与尾款支付完成后，订单才算交易成功，请您耐心等待物流公司将腕表送到您手上。
        </li>
        <li>
          3、在客服致电您的过程中，请仔细核对账号及订单信息。小心谨慎，以防被不法之徒欺骗！
        </li>
      </ul>
    </div>
    <div class="foo">
      <div>
        {{$t('real_payment')}}
        <span>US{{orderInfo.paid_num}}</span>
      </div>
      <p @click="sub">{{$t('to_pay')}}</p>
    </div>
  </div>
</template>
<script>
  export default {
    data(){
      return {
        addressName:this.$t('choice'),
        orderInfo:{
        },
        postData:{
          address_id:'',
          gid:'',
          seller_uid:'',
          delivery_method:1,
          terminal:3
        }
      }
    },
    methods:{
      detail(index){
        if(index==1){
          location.href = `${process.env.URL.USER}/#/email`
        }else{
          this.$router.push('/pay/explain')
        }
      },
      sub(){
        let self = this
        if(!self.orderInfo.address_id){
          self.$toast(this.$t('selAddress'))
          return false
        }else if(!self.postData.gid){
          self.$toast(this.$t('isOrder'))
          return false
        }else{
          self.postData.address_id = self.orderInfo.address_id
          self.$http.post(`${process.env.API.MARKET}/market/buyer/order`,self.postData).then(res=>{
            if(res.data.errcode=='0') {
              self.$router.push({path:'/pay',query:{gid:self.postData.gid,id:res.data.id}})
            }else {
              self.$toast(res.data.errmsg)
            }
          }).catch(err=>{
            console.log(err)
          })
        }
      },
      addressClick(){
        this.$router.push({name:'Addresslist',params:this.postData})
      }
    },
    created(){
      document.title =this.$t('inputOrder')
    },
    mounted(){
      let self = this
      self.postData.gid = self.$fun.GetQueryString('gid','order')
      self.postData.seller_uid = self.$fun.GetQueryString('user_uid','order')

      if(self.postData.gid){
        self.$fun.getObj.get_info(self,`${process.env.API.MARKET}/market/buyer/orderplace?gid=${self.postData.gid}`,'/market/buyer/orderplace')
      }

    }
  }
</script>
<style lang="less" scoped type="text/less">
  .order{
    .address{
      background: #fff;
      margin: 10px 0;
      padding:15px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 14px;
      .addressNone{
        display: flex;
        justify-content: space-between;
        width: 100%;
        span{
          color: #999;
          font-size: 12px;
          display: flex;
          align-items: center;
          img{
            width: 7px;
            height: 12px;
            margin-left: 10px;
          }
        }
      }
      .addressTrue{
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        font-size: 14px;
        img{
          width: 7px;
          height: 12px;
          margin-left: 10px;
        }
        div{
          p{
            max-width: 280px;
            &:first-child{
              margin-bottom: 10px;
            }
            span{
              margin-left: 10px;
            }
          }
        }
      }

    }
    .main{
      .mainTit{
        background: #fff;
        padding:15px;
        display: flex;
        font-size: 14px;
        color: #333;
        border-bottom: 1px solid #f2f2f2;
        div{
          display: flex;
          width: calc(~'100% - 120px');
          flex-direction: column;
          justify-content: space-between;
          span{
            font-size: 20px;
          }
        }
        img{
          width: 105px;
          height: 105px;
          display: inline-block;
          margin-right: 15px;
          object-fit: cover;
        }
      }
      .mainFoo{
        background: #fff;
        padding:0 15px;
        display: flex;
        justify-content: space-between;
        height: 44px;
        align-items: center;
        font-size: 14px;
        p{
          max-width: 100px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        span{
          font-size: 12px;
          background: #ecf0f7;
          padding: 5px 20px;
          margin-left: 10px;
          &.active{
            background: #333;
            color: #fff;
          }
        }
      }
      .price{
        margin: 10px 0;
        background: #fff;
        div{
          display: flex;
          font-size: 14px;
          height: 44px;
          justify-content: space-between;
          align-items: center;
          padding: 0 15px;
          p{
            display: flex;
            align-items: center;
            font-weight: bold;
            span{
              font-size: 12px;
              color: #999;
              margin-left: 5px;
              font-weight: normal;
            }
          }
          &.priceFirst{
            border-bottom: 1px solid #f2f2f2;
            p{
              color: #ec4e4e;
            }
          }
          &.priceLast{
            color: #999;
            background: #fafafa;
            p{
              color: #333;
            }
          }
        }
      }
      .kf{
        background: #fff;
        li{
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0 15px;
          height: 50px;
          font-size: 14px;
          color: #333;
          position: relative;
          &:first-child{
            &:before{
              content: '';
              position: absolute;
              width: calc(~'100% - 15px');
              height: 1px;
              background: #f2f2f2;
              right: 0;
              bottom: 0;
            }
          }
          img{
            width: 8px;
            height: 12px;
          }
        }
      }
      .process{
        padding: 15px;
        margin-bottom: 60px;
        font-size: 12px;
        color: #999;
        line-height: 24px;
        box-sizing: border-box;
      }
    }
    .pay{
      margin-top: 10px;
      background: #fff;
      padding-left: 15px;
      font-size: 14px;
      .payTit{
        height: 44px;
        display: flex;
        align-items: center;
        border-bottom: 1px solid #f2f2f2;
        color: #666;
        p{
          max-width: 70px;
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
        }
        span{
          color: #999;
          font-size: 12px;
          width: calc(~'100% - 70px');
          display: block;
        }
      }
      .payMain{
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 15px 0;
        .firstMain{
          display: flex;
          align-items: center;
          div{
            display: flex;
            flex-direction: column;
            p{
              font-size: 14px;
              color: #666;
              margin-bottom: 5px;
            }
            span{
              max-width: 200px;
              font-size: 12px;
              color: #999;
            }
          }
          img{
            width: 49px;
            height: 37px;
            display: inline-block;
            margin-right: 15px;
          }
        }
      }
    }
    .foo{
      position: fixed;
      width: 100%;
      z-index: 999;
      height: 56px;
      bottom: 0;
      left: 0;
      display: flex;
      justify-content: space-between;
      border-top: 1px solid #f2f2f2;
      box-sizing: border-box;
      div{
        width: calc(~'100% - 135px');
        display: flex;
        flex-direction: column;
        padding-left: 15px;
        justify-content: center;
        font-size: 12px;
        background: #fff;
        box-sizing: border-box;
        color: #999;
        span {
          color: #ec4e4e;
          font-size: 14px;
          font-weight: bold;
          display: block;
          margin-top: 5px;
        }
      }
      p{
        width: 135px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        background: #ec4e4e;
        color: #fff;
      }
    }
  }
</style>
<style lang="less">
  body{
    background: #ecf0f4;
    padding: 0;
  }
</style>
