<template>
  <div>
    <div class="threesixty car" v-show="watchInfo.file_pic_360&&watchInfo.file_pic_360.total_num&&albumNum==0">
      <div class="spinner">
        <span>0%</span>
      </div>
      <ol class="threesixty_images"></ol>
      <span style="position: absolute;top: 15px;right: 15px">
        <img src="../assets/images/market/360.png">
      </span>
    </div>
    <div class="album" v-if="watchInfo.file_pic_360&&watchInfo.file_pic_360.total_num">
      <img class="albumImg" :style="{height:hei+'px'}" :src="watchInfo.file_pic[albumNum-1]" v-if="albumNum!=0">
      <ul>
        <li @click="albumNum=0">
          <img :src="is360" class="albumImgList">
          <span>
            <img src="../assets/images/market/360.png">
          </span>
        </li>
        <li v-for="item,index in watchInfo.file_pic" @click="albumNum=index+1">
          <img :src="item" class="albumImgList">
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
  import ThreeSixty from '@/plugin/threesixty'
  export default {
    data() {
      return {
        uid: '',
        swiperNum: 1,
        watchInfo: {},
        albumNum: 0,
        is360: '',
        hei:0,
      }
    },
    methods: {
    },
    created() {
      document.title = this.$t('commodity')
      this.hei = document.body.clientWidth
    },
    mounted() {
      //测试3D
      let self = this
      self.uid = localStorage.getItem('userId')
//       调用url参数方法
      if (self.$fun.GetQueryString('id', 'ios')) {
        self.$http.get(`${process.env.API.MARKET}/market/buyer/watchinfo?gid=${self.$fun.GetQueryString('id', 'ios')}`).then((res) => {
          if (res.data.errcode == '0') {
            res.data.manage.file_pic = res.data.manage.file_pic.split(',') || []//商品图片轮播
            self.watchInfo = res.data.manage
            if (res.data.manage.file_pic_360 && res.data.manage.file_pic_360.total_num) {
              self.is360 = `${res.data.manage.file_pic_360.url}/1${res.data.manage.file_pic_360.ext}`
              let product = $('.car').ThreeSixty({
                totalFrames: res.data.manage.file_pic_360.total_num,
                endFrame: res.data.manage.file_pic_360.total_num,
                currentFrame: 1,
                imgList: '.threesixty_images',
                progress: '.spinner',
                imagePath: `${res.data.manage.file_pic_360.url}/`,
                filePrefix: '',
                ext: res.data.manage.file_pic_360.ext,
                height: this.hei,
                width: '',
                navigation: true,
                disableSpin: false
              });
            }
          } else {
            self.$messagebox.alert(res.data.errmsg)
          }
        }).catch((err) => {
          console.log(err)
        })
      } else {
        self.$messagebox.alert(self.$t('noOrder')).then((action) => {
          self.$router.push('/')
        })
      }
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .album {
    .albumImg {
      width: 100%;
      object-fit: cover;
      display: block;
    }
    ul {
      display: flex;
      width: 100%;
      overflow: scroll;
      padding: 6px;
      box-sizing: border-box;
      -webkit-overflow-scrolling: touch;
      li {
        box-sizing: border-box;
        height: 100px;
        width: 100px;
        margin-right: 6px;
        position: relative;
        .albumImgList {
          width: 100px;
          height: 100px;
          object-fit: cover;
        }
        span {
          position: absolute;
          top: 5px;
          right: 5px;
        }
      }
    }
  }

</style>
<style lang="less">
  body {
    background: #ecf0f4;
    padding: 0;
  }

  .mint-swipe-items-wrap {
    min-height: 100% !important;
  }
</style>
