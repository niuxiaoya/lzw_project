<template>
  <div class="bankcard">
    <div class="addBankCard">
      <p class="tit">
        {{$t('bandMyBank')}}
      </p>
      <ul>
        <li><input type="text" v-model="postData.cardholder" :placeholder="$t('myName')"></li>
        <li><input type="number" v-model="postData.cardnum" :placeholder="$t('inputCard')"></li>
        <li>
          <div class="wapHei">
            <p :class="{'color':gjName==$t('choice')}">{{gjName}}</p>
            <select v-model="postData.is_china" @change="selectVal">
              <option v-for="item,index in gjList" :value="item.id">{{item.name}}</option>
            </select>
          </div>
        </li>
        <li><input type="text" v-model="postData.bank_name" :placeholder="$t('bankType')"></li>
        <li v-if="postData.is_china==1">
          <div class="bankText">
            <textarea name="" id="" cols="30" rows="4" :placeholder="$t('accountsBankText')"
                      v-model="postData.opening_bank">
        </textarea>
          </div>
        </li>
      </ul>
      <div class="btn" @click="nextClick">
        {{$t('next')}}
      </div>
      <div class="foo">
        {{$t('myBankText')}}
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        bankList: [],
        bank: '',
        gjName: this.$t('choice'),
        gjList: [
          {name: this.$t('china'), id: 1},
          {name: this.$t('other'), id: 2}
        ],
        postData: {
          cardholder: '',
          cardnum: '',
          is_china: '',
          bank_name: '',
          opening_bank: ''
        }
      }
    },
    methods: {
      selectVal(ele) {
        let self = this
        if (this.postData.is_china == 2) {
          self.postData.opening_bank = ''
        }
        for (let i = 0; i < self.gjList.length; i++) {
          if (self.gjList[i].id == this.postData.is_china) {
            self.gjName = self.gjList[i].name
          }
        }
      },
      nextClick() {
        let self = this
        if (!self.postData.cardholder) {
          self.$toast(this.$t('inputName'))
        } else if (!self.postData.cardnum) {
          self.$toast(this.$t('inputCard'))
        } else if (self.postData.cardnum.length < 8 || self.postData.cardnum.length > 30) {
          self.$toast(this.$t('inputBankCard'))
        } else if (!self.postData.is_china) {
          self.$toast(this.$t('selCountry'))
        } else if (!self.postData.bank_name) {
          self.$toast(this.$t('bankType'))
        } else if (self.postData.is_china == 1 && self.postData.opening_bank == '') {
          self.$toast(this.$t('inputAccountsBank'))
        } else {
          localStorage.setItem('bankInfo', JSON.stringify(self.postData))
          self.$router.push('/confirm')
        }
      }
    },
    created() {
      document.title = this.$t('addBank')
      let self = this
//      let uid = self.$fun.GetQueryString('uid','bankcard')
//
//      // 调用方法
//      if (uid) {
//        localStorage.setItem('userId', uid)
//        this.$store.state.userId =localStorage.getItem('userId')
//        this.$store.state.language =localStorage.getItem('lang')
//      }else{
//        this.$store.state.userId =localStorage.getItem('userId')?localStorage.getItem('userId'):''
//        this.$store.state.language =localStorage.getItem('lang')?localStorage.getItem('lang'):'zh-cn'
//      }
    },
    mounted() {
      let self = this
      let bankInfo = JSON.parse(localStorage.getItem('bankInfo'))

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/bank`, '/dict/bank')

//      setTimeout(()=>{
//        if(!bankInfo){
//          self.bankNum = 0
//          self.bank= self.bankList[self.bankNum].name
//          self.postData.bank_id= self.bankList[self.bankNum].id
//        }else{
//          self.postData.cardholder = bankInfo.cardholder
//          self.postData.cardnum = bankInfo.cardnum
//          self.postData.bank_id = bankInfo.bank_id
//        }
//        for (let i=0;i<self.bankList.length;i++){
//          if(self.bankList[i].id == self.postData.bank_id){
//            self.bank = self.bankList[i].name
//            self.bankNum = i
//          }
//        }
//      },300)
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .bankcard {
    .addBankCard {
      .tit {
        font-size: 12px;
        color: #666;
        padding: 15px;
      }
      ul {
        background: #fff;
        padding: 0 15px;
        font-size: 14px;
        li {
          min-height: 44px;
          color: #333;
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 1px solid #f2f2f2;
          input {
            width: 100%;
            height: 30px;
          }
          .wapHei {
            width: 100%;
            min-height: 44px;
            background: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
            font-size: 14px;
            .color {
              color: #ccc;
            }
            p {
              color: #333;
              height: 44px;
              padding: 0;
              width: 100%;
              display: flex;
              align-items: center;
              img {
                width: 20px;
                height: 20px;
                border-radius: 50%;
                margin-right: 5px;
              }
            }
            select {
              width:100%;
              opacity: 0;
              position: absolute;
              height: 100%;
            }

          }
          .bankText {
            width: 100%;
            display: flex;
            background: #fff;
            padding-top: 15px;
            box-sizing: border-box;
            justify-content: space-between;
            textarea {
              overflow: scroll;
              width: 100%;
              box-sizing: border-box;
              resize: none;
              border: none;
              font-size: 14px;
            }
          }
        }
      }
      .btn {
        width: 250px;
        height: 44px;
        background: #333;
        color: #fff;
        margin: auto;
        text-align: center;
        line-height: 44px;
        display: block;
        margin-top: 75px;
        font-size: 16px;
      }

      .foo {
        color: #999;
        font-size: 12px;
        width: 300px;
        background: #ecf0f4;
        margin: auto;
        line-height: 22px;
        margin-top: 30px;
      }
    }
  }
</style>
<style lang="less" type="text/less">
  //移除body
  body {
    padding: 0 !important;
    background: #ecf0f4 !important;
  }
</style>
