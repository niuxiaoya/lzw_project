<template>
  <div class="bankList">
    <div class="add" @click="$router.push('/bankcard')">
      {{$t('bandMyBank')}}
      <img src="../assets/images/market/arrow.png">
    </div>
    <div class="page-cell">
      <mt-cell-swipe
        v-for="item,index in bankcardList"
        key="index"
        :right="[
           {
              content: '解绑',
              style: { background: '#ff6969', color: '#fff' },
              handler: () => {
                relieve(item)
              }
            }
        ]"
        :title="`${item.bank_name} **** ${item.cardnum}`">
      </mt-cell-swipe>
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        bankcardList: [],
      }
    },
    methods: {
      relieve(item) {
        let self = this
        if (!self.flag) {
          self.$messagebox.confirm(self.$t('removeBank'), self.$t('prompt')).then(action => {
            if (action == 'confirm') {
              self.$fun.deleteObj.delete_data(self, `${process.env.API.USER}/user/bankcard?id=${item.id}`, '/user/bankcard')
            }
          });
        }
      },
    },
    created() {
      let self = this
      document.title = this.$t('selBank')
      let uid = self.$fun.GetQueryString('uid', 'banklist')
      if (uid) {
        localStorage.setItem('userId', uid)
        self.$store.state.userId = uid
      }

      self.$fun.getObj.get_list(self, `${process.env.API.USER}/user/bankcard`, '/user/bankcard')
    },
    mounted() {

    }
  }
</script>
<style lang="less" scoped type="text/less">
  .bankList {
    .add {
      margin: 10px 0;
      height: 44px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 15px;
      background: #fff;
      font-size: 14px;
      color: #333;
      img {
        width: 7px;
        height: 12px;
      }
    }
    ul {
      margin-top: 10px;
      li {
        height: 75px;
        display: flex;
        align-items: center;
        padding: 0 15px;
        background: #fff;
        margin-bottom: 10px;
        font-size: 14px;
        p {
          margin-left: 15px;
          display: flex;
          align-items: center;
        }
      }
    }
    .foo {
      width: 100%;
      height: 44px;
      text-align: center;
      line-height: 44px;
      position: fixed;
      bottom: 0;
      left: 0;
      background: #333;
      color: #fff;
    }
  }
</style>
<style lang="less" type="text/less">
  body {
    padding: 0 !important;
    background: #ecf0f4;
  }
  .bankList{
    .page-cell{
      .mint-cell-swipe{
        height: 75px;
        display: flex;
        margin-top: 10px;
        .mint-cell-swipe-button{
          display: flex;
          align-items: center;
        }
        .mint-cell-text{
          font-size: 14px;
        }
        .mint-cell-wrapper{
          background: #fff;
        }
      }
    }
  }
</style>
