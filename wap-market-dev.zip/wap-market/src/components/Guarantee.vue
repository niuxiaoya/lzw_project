<template>
  <div class="guarantee">
    <no-more v-if="this.$route&&!this.$route.params.guarantee"></no-more>
    <div v-html="this.$route.params.guarantee"></div>
  </div>
</template>
<script>
  export default {
    data(){
      return{

      }
    },
    created(){
      window.scrollTo(0,0)
    },
    mounted(){}
  }
</script>
<style lang="less" scoped type="text/less">

</style>
