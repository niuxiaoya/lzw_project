<template>
  <div class="sell" :class="{'hide':localShow}">
    <div class="loser" v-if="isLoser==1">
      <p>{{$t('error')}}</p>
      <div>
        {{errInfo}}
      </div>
    </div>
    <mt-popup v-model="isProcess" position="bottom" class="mint-popup-bottom" :modal="false">
      <div class="process">
        <div class="process">
          <div class="processTit">{{$t('process')}}</div>
          <div class="processMain">
            <p>
              <img src="../assets/images/market/process/sell1.png">
              {{$t('releaseWatch')}}
            </p>
            <div>
              <img src="../assets/images/market/process/right.png">
            </div>
            <p>
              <img src="../assets/images/market/process/sell2.png">
              {{$t('saleWatch')}}
            </p>
            <div>
              <img src="../assets/images/market/process/right.png">
            </div>
            <p>
              <img src="../assets/images/market/process/sell3.png">
              {{$t('paymentOrder')}}
            </p>
          </div>
          <div class="processDown">
            <img src="../assets/images/market/process/down.png">
          </div>
          <div class="processMain">
            <p>
              <img src="../assets/images/market/process/sell4.png">
              {{$t('receivables')}}
            </p>
            <div>
              <img src="../assets/images/market/process/left.png">
            </div>
            <p>
              <img src="../assets/images/market/process/sell5.png">
              {{$t('buyers')}}
            </p>
            <div>
              <img src="../assets/images/market/process/left.png">
            </div>
            <p>
              <img src="../assets/images/market/process/sell6.png">
              {{$t('watchIdentification')}}
            </p>
          </div>
        </div>
        <div class="btn" @click="popHide">
          {{$t('determine')}}({{num}}s)
        </div>
      </div>
    </mt-popup>
    <div class="topNav">
      <div @click="$router.push('/')">
        {{$t('tb4')}}
      </div>
      <div class="topNavActive">
        {{$t('sell')}}
      </div>
    </div>
    <div class="formData" v-if="!isProcess">
      <div class="brand" :class="{'fooColor':brand==$t('brand')}" @click="isBrand">
        {{brand}}
        <img src="../assets/images/market/arrow.png">
      </div>
      <div class="tit">
        <p>{{$t('title')}}</p>
        <textarea contenteditable="true" :class="{'fontColor':postData.title!=''}" :placeholder="$t('biaoti')"
                  style="resize:none" rows="4" v-model="postData.title">
        </textarea>
      </div>
      <div class="describe">
        <p class="describeP">{{$t('describe')}}</p>
        <textarea contenteditable="true" :class="{'fontColor':postData.details!=''}" :placeholder="$t('watchDescribe')"
                  style="resize:none" rows="4" v-model="postData.details">
        </textarea>
        <div class="img">
          <el-upload
            class="avatar-uploader"
            :headers="head"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg1"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[0].img" :src="img[0].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[0]!='-1'&&imgData[0]!=''" @click.stop="removeImg(1)">
              <img src="../assets/images/market/redClose.png"></span>
            <p v-if="imgData[0]=='-1'||imgData[0]==''">{{$t('img1')}}</p>
          </el-upload>
          <el-upload
            class="avatar-uploader"
            :headers="head"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg2"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[1].img" :src="img[1].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[1]!='-1'&&imgData[1]!=''" @click.stop="removeImg(2)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[1]=='-1'||imgData[1]==''">{{$t('img2')}}</p>
          </el-upload>
          <el-upload
            :headers="head"
            class="avatar-uploader"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg3"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[2].img" :src="img[2].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[2]!='-1'&&imgData[2]!=''" @click.stop="removeImg(3)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[2]=='-1'||imgData[2]==''">{{$t('img3')}}</p>
          </el-upload>
          <el-upload
            :headers="head"
            class="avatar-uploader"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg4"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[3].img" :src="img[3].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[3]!='-1'&&imgData[3]!=''" @click.stop="removeImg(4)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[3]=='-1'||imgData[3]==''">{{$t('img4')}}</p>
          </el-upload>
          <el-upload
            :headers="head"
            class="avatar-uploader"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg5"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[4].img" :src="img[4].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[4]!='-1'&&imgData[4]!=''" @click.stop="removeImg(5)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[4]=='-1'||imgData[4]==''">{{$t('img5')}}</p>
          </el-upload>
          <el-upload
            :headers="head"
            class="avatar-uploader"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg6"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[5].img" :src="img[5].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[5]!='-1'&&imgData[5]!=''" @click.stop="removeImg(6)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[5]=='-1'||imgData[5]==''">{{$t('img6')}}</p>
          </el-upload>
          <el-upload
            :headers="head"
            class="avatar-uploader"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg7"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[6].img" :src="img[6].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[6]!='-1'&&imgData[6]!=''" @click.stop="removeImg(7)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[6]=='-1'||imgData[6]==''">{{$t('img7')}}</p>
          </el-upload>
          <el-upload
            :headers="head"
            class="avatar-uploader"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg8"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[7].img" :src="img[7].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[7]!='-1'&&imgData[7]!=''" @click.stop="removeImg(8)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[7]=='-1'||imgData[7]==''">{{$t('img8')}}</p>
          </el-upload>
          <el-upload
            :headers="head"
            class="avatar-uploader"
            :action="upload"
            :show-file-list="false"
            :on-success="successImg9"
            :before-upload="beforeAvatarUpload">
            <img v-if="img[8].img" :src="img[8].img" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            <span v-if="imgData[8]!='-1'&&imgData[8]!=''" @click.stop="removeImg(9)">
              <img src="../assets/images/market/redClose.png">
            </span>
            <p v-if="imgData[8]=='-1'||imgData[8]==''">{{$t('img9')}}</p>
          </el-upload>
        </div>
        <span>{{$t('img_upload')}}</span>
        <p style="border: none">
          <mt-checklist
            v-model="value"
            :options="[{label: '阅读并同意',value: '同意' }]"
          >
          </mt-checklist>
          <span @click="popupRight = true" style="color: #333">
            《{{$t('consignmentAgreement')}}》
          </span>
        </p>
      </div>
      <div class="info">
        <div class="wrap">
          <p>{{$t('gender')}}</p>
          <ul>
            <li v-for="item,index in gender">
              <div :class="{'active':(index+1) == postData.gender}" @click="genderClick(index)">
                {{item}}
              </div>
            </li>
          </ul>
        </div>
        <div class="wrap">
          <p>{{$t('movement')}}</p>
          <ul>
            <li v-for="item,index in movementList">
              <div :class="{'active':item.id == postData.movement_id}" @click="movementClick(item,index)">
                {{item.name}}
              </div>
            </li>
          </ul>
        </div>
        <div class="wrap">
          <p>{{$t('material')}}</p>
          <ul>
            <li v-for="item,index in watchCase">
              <div :class="{'active':postData.material_id==item.id}" @click="watchCaseClick(item,index)">
                {{item.name}}
              </div>
            </li>
          </ul>
        </div>
        <div class="wrap">
          <p>{{$t('shape')}}</p>
          <ul>
            <li v-for="item,index in shapeList">
              <div :class="{'active':postData.shape_id==item.id}" @click="shapeClick(item,index)">
                {{item.name}}
              </div>
            </li>
          </ul>
        </div>
        <div class="wrap">
          <p>{{$t('function_name')}}</p>
          <ul>
            <li v-for="item,index in complex">
              <div :class="{'active':postData.function_id.indexOf(item.manage.id.toString())>-1}"
                   @click="complexClick(item,index)">
                {{item.manage.name}}
              </div>
            </li>
          </ul>
        </div>
        <div class="selStyle" @click="conditionHide">
          <div class="wapTit">{{$t('condition')}}<span>（{{$t('mandatory')}}）</span></div>
          <div :class="{'fooColor':condition==$t('choose')}">{{condition}} <img src="../assets/images/market/arrow.png"></div>
        </div>
        <div class="selStyle" @click="bankShow = true">
          <div class="wapTit">{{$t('bankCard')}}<span>（{{$t('mandatory')}}）</span></div>
          <div class="bank">
            <p :class="{'fooColor':bank==$t('choose')}">{{bank}}<img src="../assets/images/market/arrow.png"></p>
            <select v-model="postData.bankcard_id" @change="selectChange">
              <option v-for="item in bankList" :value="item.id">{{item.bank_name}}({{item.cardnum}})</option>
            </select>
          </div>
        </div>
        <div class="selStyle" @click="localShow = true">
          <div class="wapTit">{{$t('location')}}<span>（{{$t('mandatory')}}）</span></div>
          <div :class="{'fooColor':local==$t('choose')}">{{local}} <img src="../assets/images/market/arrow.png"></div>
        </div>
        <div class="selStyle">
          <div class="wapTit">{{$t('diameter')}}<span>（{{$t('require')}}）</span></div>
          <div class="selInputShow"><input type="number" placeholder="0" v-model="postData.diameter"> <span class="rmb">MM</span></div>
        </div>
        <div class="selStyle">
          <div class="wapTit">{{$t('original_price')}}<span>（{{$t('require')}}）</span></div>
          <div class="selInputShow"><input type="number" v-model="postData.original_price" placeholder="0"><span class="rmb">USD</span>
          </div>
        </div>
        <div class="selStyle">
          <div class="wapTit">{{$t('price')}}<span>（{{$t('require')}}）</span></div>
          <div class="selInputShow"><input type="number" v-model="postData.price" placeholder="0"><span class="rmb">USD</span></div>
        </div>
      </div>
      <div class="btn" @click="sub">{{$t('confirmText')}}</div>
    </div>
    <!--协议弹窗显示-->
    <mt-popup v-model="popupRight" position="bottom" class="mint-popup-bottom popBtn" :modal="false">
      <div class="tit">{{$t('serviceAgreement')}}</div>
      <p class="edit">{{$t('editTime')}}：{{xieyi?xieyi.publish_time:''}}</p>
      <div class="content" v-html="xieyi?xieyi.content:''">
      </div>
      <img src="../assets/images/market/close.png" @click="popupHide">
    </mt-popup>
    <!--品牌弹窗显示-->
    <mt-popup v-model="brandShow" position="bottom" class="mint-popup-bottom" :modal="false">
      <div class="close">
        <img src="../assets/images/market/close.png" @click="brandShow = false">
      </div>
      <div style="height: 44px;width: 100%"></div>
      <mt-index-list>
        <mt-index-section v-for="item,index in brandList" :index="item.initial.toString()" :key="index">
          <mt-cell v-for="cell,num in item.list" @click.native="brandClick(cell)" :key="num" class="brandStyle">
            <img :src="cell.pic" alt=""><span>{{cell.name}}</span>
          </mt-cell>
        </mt-index-section>
      </mt-index-list>
    </mt-popup>
    <!--成色弹出显示-->
    <mt-popup v-model="conditionShow" position="bottom" class="mint-popup-bottom" :modal="false">
      <div class="close">
        <img src="../assets/images/market/close.png" @click="conditionHide(1)">
      </div>
      <div style="height: 44px;width: 100%"></div>
      <ul class="condition">
        <li v-for="item in conditionList" @click="conditionClick(item)">
          <p>【{{item.name}}】</p><span>{{item.details}}</span>
        </li>
      </ul>
    </mt-popup>
    <!--所在地弹出显示-->
    <mt-popup v-model="localShow" position="bottom" class="mint-popup-4" style="height: 230px!important;">
      <div class="tit">
        <p @click="localShow = false">{{$t('cancel')}}</p>
        <p @click="sureLocal">{{$t('complete')}}</p>
      </div>
      <mt-picker :slots="addressSlots" value-key="name" @change="onAddressChange" :visible-item-count="5"></mt-picker>
    </mt-popup>
    <!--<div @click="demo">语言切换</div>-->
  </div>
</template>
<script>
  let address = []
  export default {
    data() {
      return {
        errInfo: '',
        upload: `${process.env.API.USER}/user/upload`,
        head: {
          AccessToken: localStorage.getItem('AccessToken'),
          Authorization: localStorage.getItem('userId')
        },
        brand: `${this.$t('brand')}`,
        num: 6,
        bankList: [],
        xieyi: {},
        flag: false,
        isLoser: 0,
        address: [],
        value: ['同意'],
        isProcess: true,
        number: null,
        brandShow: false,
        conditionShow: false,
        popupRight: false,
        localShow: false,
        bankShow: false,
        bank: this.$t('choose'),
        condition: this.$t('choose'),
        local: this.$t('choose'),
        location: [],
        brandList: [],
        conditionList: [],
        shapeList: [],
        movementList: [],
        imgData: [
          '', '', '', '', '', '', '', '', ''
        ],
        img: [
          {img: require('@/assets/images/market/watch/img1.jpg')},
          {img: require('@/assets/images/market/watch/img2.jpg')},
          {img: require('@/assets/images/market/watch/img3.jpg')},
          {img: require('@/assets/images/market/watch/img4.jpg')},
          {img: require('@/assets/images/market/watch/img5.jpg')},
          {img: require('@/assets/images/market/watch/img6.jpg')},
          {img: require('@/assets/images/market/watch/img7.jpg')},
          {img: require('@/assets/images/market/watch/img8.jpg')},
          {img: require('@/assets/images/market/watch/img9.jpg')}
        ],
        gender: [this.$t('sex.man'), this.$t('sex.lady'), this.$t('sex.neutral')],
        watchCase: [],
        addressSlots: [
          {
            flex: 1,
            defaultIndex: 1,
            values: address,
            className: 'slot1',
            textAlign: 'center'
          }, {
            flex: 1,
            values: [],
            className: 'slot2',
            textAlign: 'center'
          },
          {
            flex: 1,
            values: [],
            className: 'slot3',
            textAlign: 'center'
          }
        ],
        complex: [],
        localList: [],
        postData: {
          gender: '',
          diameter: '',
          title: '',
          brand_id: '',
          material_id: '',
          shape_id: '',
          original_price: '',
          price: '',
          details: '',
          file_id: [],
          cover: '',
          function_id: [],
          location: '',
          prov_code: '',
          city_code: '',
          dist_code: '',
          fineness_id: '',
          movement_id: '',
          bankcard_id: ''
        }
      }
    },
    methods: {
      //协议
      popupShow() {
        let self = this
        self.popupRight = true
        document.title = self.xieyi.title
      },
      selectChange() {
        let self = this
        for (let i = 0; i < self.bankList.length; i++) {
          if (self.postData.bankcard_id == self.bankList[i].id) {
            self.bank = `${self.bankList[i].bank_name}(${self.bankList[i].cardnum})`
          }
        }
      },
      popupHide() {
        let self = this
        self.popupRight = false
        document.title = this.$t('process')
      },
      genderClick(index) {
        let self = this
        if ((index + 1) == self.postData.gender) {
          self.postData.gender = 0
        } else {
          self.postData.gender = index + 1
        }
      },
      watchCaseClick(item, index) {
        let self = this
        if (item.id == self.postData.material_id) {
          self.postData.material_id = ''
        } else {
          self.postData.material_id = item.id
        }
      },
      complexClick(item, index) {
        let self = this
        for (let i = 0; i < self.postData.function_id.length; i++) {
          if (self.postData.function_id[i] == item.manage.id) {
            self.postData.function_id.splice(i, 1)
            return false
          }
        }
        self.postData.function_id.push(item.manage.id.toString())
      },
      shapeClick(item, index) {
        let self = this
        if (self.postData.shape_id == item.id) {
          self.postData.shape_id = ''
        } else {
          self.postData.shape_id = item.id
        }
      },
      popHide() {
        let self = this
        self.isProcess = false
        document.title = this.$t('watchSell')
      },
      removeImg(index) {
        let key = index - 1
        this.imgData[key] = ''
        switch (index) {
          case 1:
            this.img[key].img = require('@/assets/images/market/watch/img1.jpg')
            break;
          case 2:
            this.img[key].img = require('@/assets/images/market/watch/img2.jpg')
            break;
          case 3:
            this.img[key].img = require('@/assets/images/market/watch/img3.jpg')
            break;
          case 4:
            this.img[key].img = require('@/assets/images/market/watch/img4.jpg')
            break;
          case 5:
            this.img[key].img = require('@/assets/images/market/watch/img5.jpg')
            break;
          case 6:
            this.img[key].img = require('@/assets/images/market/watch/img6.jpg')
            break;
          case 7:
            this.img[key].img = require('@/assets/images/market/watch/img7.jpg')
            break;
          case 8:
            this.img[key].img = require('@/assets/images/market/watch/img8.jpg')
            break;
          case 9:
            this.img[key].img = require('@/assets/images/market/watch/img9.jpg')
            break;
        }
      },
      successImg1(res, file) {
        if (res.errcode == '0') {
          this.img[0].img = URL.createObjectURL(file.raw);
          this.postData.cover = res.fileinfo.fid
          this.imgData[0] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg2(res, file) {
        if (res.errcode == '0') {
          this.img[1].img = URL.createObjectURL(file.raw);
          this.imgData[1] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg3(res, file) {
        if (res.errcode == '0') {
          this.img[2].img = URL.createObjectURL(file.raw);
          this.imgData[2] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg4(res, file) {
        if (res.errcode == '0') {
          this.img[3].img = URL.createObjectURL(file.raw);
          this.imgData[3] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg5(res, file) {
        if (res.errcode == '0') {
          this.img[4].img = URL.createObjectURL(file.raw);
          this.imgData[4] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg6(res, file) {
        if (res.errcode == '0') {
          this.img[5].img = URL.createObjectURL(file.raw);
          this.imgData[5] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg7(res, file) {
        if (res.errcode == '0') {
          this.img[6].img = URL.createObjectURL(file.raw);
          this.imgData[6] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg8(res, file) {
        if (res.errcode == '0') {
          this.img[7].img = URL.createObjectURL(file.raw);
          this.imgData[7] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      successImg9(res, file) {
        if (res.errcode == '0') {
          this.img[8].img = URL.createObjectURL(file.raw);
          this.imgData[8] = res.fileinfo.fid
        } else {
          this.$toast(res.errmsg)
        }
      },
      beforeAvatarUpload(file) {
        const isLt5M = file.size / 1024 / 1024 < 5;
        if (file.type == 'image/jpeg' || file.type == 'image/jpg' || file.type == 'image/png' || file.type == 'image/bmp') {

        } else {
          this.$toast(this.$t('isImg'));
          return false
        }
        if (!isLt5M) {
          this.$toast(this.$t('is5MB'));
        }
        return isLt5M;
      },
      isBrand(index) {
        let self = this
        self.brandShow = true
        document.title = this.$t('condition')
      },
      brandClick(cell) {
        let self = this
        self.brand = cell.name
        self.postData.brand_id = cell.id
        self.brandShow = false
      },
      conditionHide(index) {
        let self = this
        if (index == 1) {
          self.conditionShow = false
          document.title = this.$t('watchSell')
        } else {
          self.conditionShow = true
          document.title = this.$t('condition')
        }
      },
      conditionClick(item) {
        let self = this
        self.condition = item.name
        self.postData.fineness_id = item.id
        self.conditionShow = false
        document.title = this.$t('watchSell')
      },
      localClick(name) {
        let self = this
        self.postData.location = name
        self.localShow = false
      },
      onAddressChange(picker, values) {
        let self = this
        if (self.address.length >= 1) {
          if (!values[0].city) {
            picker.setSlotValues(1, []);
            picker.setSlotValues(2, []);
            self.location[0] = values[0];
            self.location[1] = '';
            self.location[2] = '';
          } else {
            picker.setSlotValues(1, values[0].city);
            self.location[0] = values[0];
            self.location[1] = values[1];
            self.location[2] = values[2];
            setTimeout(() => {
              picker.setSlotValues(2, values[1].dist);
            }, 300)
          }
        }
      },
      sureLocal() {
        let self = this
        if (self.location[1].name) {
          self.local = self.location[0].name + '/' + self.location[1].name + '/' + self.location[2].name
          self.postData.prov_code = self.location[0].code
          self.postData.city_code = self.location[1].code
          self.postData.dist_code = self.location[2].code
        } else {
          self.local = self.location[0].name
        }
        self.postData.location = self.location[1].name
        self.localShow = false
      },
      movementClick(item, index) {
        let self = this
        if (self.postData.movement_id == item.id) {
          self.postData.movement_id = ''
        } else {
          self.postData.movement_id = item.id
        }
      },
      sub() {
        let self = this
        let reg = /^\d+(\.\d{0,2})?$/
        if (!self.postData.brand_id) {
          self.$toast(this.$t('brand'))
          return false
        } else if (!self.postData.title) {
          self.$toast(this.$t('inputTitle'))
          return false
        } else if (!self.postData.details) {
          self.$toast(this.$t('inputDetail'))
          return false
        } else if (!self.imgData[0] || !self.imgData[1] || !self.imgData[2]) {
          self.$toast(this.$t('threeImg'))
          return false
        } else if (!self.value[0]) {
          self.$toast(this.$t('isAgreement'))
          return false
        } else if (!self.postData.fineness_id) {
          self.$toast(this.$t('choiceCondition'))
          return false
        } else if (!self.postData.bankcard_id) {
          self.$toast(this.$t('choiceBankcard'))
          return false
        } else if (!self.postData.location) {
          self.$toast(this.$t('choiceLocation'))
          return false
        } else if (!self.postData.diameter) {
          self.$toast(this.$t('inputDiameter'))
          return false
        } else if (!self.postData.original_price ||self.postData.original_price==0) {
          self.$toast(this.$t('inputOriginalPrice'))
          return false
        }  else if (!self.postData.price||self.postData.price==0) {
          self.$toast(this.$t('inputPrice'))
          return false
        }


        self.postData.file_id = []
        for (let i = 0; i < 9; i++) {
          if (self.imgData[i]) {
            self.postData.file_id.push(self.imgData[i])
          } else {
            self.postData.file_id.push(-1)
          }
        }
        if (self.isLoser == 1) {
          if (!self.flag) {
            self.flag = true
            self.postData.gid = self.$fun.GetQueryString('id', 'sell')
            self.$http.put(`${process.env.API.MARKET}/market/seller/publish`, self.postData).then(res => {
              if (res.data.errcode == '0') {
                self.$toast(this.$t('success'))
                setTimeout(() => {
                  self.$router.push('/')
                  self.flag = false
                }, 2000)
              } else {
                self.$$toast(res.data.errmsg)
              }
            }).catch(err => {
              console.log(err)
            })
          }
        } else {
          if (!self.flag) {
            self.flag = true
            self.$http.post(`${process.env.API.MARKET}/market/seller/publish`, self.postData).then(res => {
              if (res.data.errcode == '0') {
                self.$toast(this.$t('success'))
                setTimeout(() => {
                  self.flag = false
                  self.$router.push('/')
                }, 2000)
              } else {
                self.$messagebox.alert(res.data.msg)
              }
            }).catch(err => {
              console.log(err)
            })
          }
        }
      },
    },
    created() {
      let self = this
      let timeShow = setInterval(function () {
        if (self.num <= 0) {
          clearInterval(timeShow)
          self.isProcess = false
        } else {
          self.num--
        }
      }, 1000)
      document.title = this.$t('process')
      setTimeout(()=>{
        document.title = this.$t('watchSell')
      },5000)
      self.$http.get(`${process.env.API.USER}/user/bankcard?nonce=${Math.random()}`).then(res => {
        if (res.data.errcode == '0') {
          for (let i = 0; i < res.data.data.length; i++) {
            res.data.data[i].cardnum = res.data.data[i].cardnum.substring(res.data.data[i].cardnum.length - 4)
          }
          self.bankList = res.data.data
        }
      }).catch(err => {
        console.log(err)
      })

      if (self.$fun.GetQueryString('isLoser', 'sell')) {
        self.isLoser = 1
        let gid = self.$fun.GetQueryString('id', 'sell')
        self.$http.get(`${process.env.API.MARKET}/market/seller/republishinfo?gid=${gid}`).then(res => {
          if (res.data.errcode == '0') {
            self.errInfo = res.data.data.remark//错误信息
            self.postData.gender = res.data.data.gender //性别
            self.postData.movement_id = res.data.data.movement_id //机芯
            self.postData.fineness_id = res.data.data.fineness_id//成色id
            self.condition = res.data.data.fineness_name //成色展示
            self.local = res.data.data.area //省市区展示
            self.postData.location = res.data.data.area //省市区展示
            self.postData.material_id = res.data.data.material_id //材质
            self.brand = res.data.data.brand_name //品牌名字
            self.postData.brand_id = res.data.data.brand_id //品牌名字
            self.postData.function_id = res.data.data.function_id.replace(/^,*|,*$/g, '').split(',') //品牌名字
            self.postData.diameter = res.data.data.diameter//直径
            self.postData.original_price = res.data.data.original_price_num//原价
            self.postData.price = res.data.data.price_num//售价
            self.postData.cover = res.data.data.cover_fid//售价
            self.postData.prov_code = res.data.data.prov_code
            self.postData.city_code = res.data.data.city_code
            self.postData.dist_code = res.data.data.dist_code
            self.postData.bankcard_id = res.data.data.user_bankcard_id
            for (let b = 0; b < self.bankList.length; b++) {
              if (self.bankList[b].id == self.postData.bankcard_id) {
                self.bank = `${self.bankList[b].bank_name}(${self.bankList[b].cardnum})`
              }
            }
            let file_pic = res.data.data.file_pic.split(',')//图片
            for (let i = 0; i < 9; i++) {
              if (file_pic[i] && file_pic[i] != -1) {
                self.img[i].img = file_pic[i]
              }
            }
            self.postData.file_id = res.data.data.file_fid.split(',')//图片id
            self.imgData = self.postData.file_id//图片id
            self.postData.details = res.data.data.details//详情
            self.postData.title = res.data.data.title//标题
            self.postData.shape_id = res.data.data.shape_id//形状
          }
        }).catch(err => {
          console.log(err)
        })
      }
    },
    mounted() {
      let self = this
      self.$nextTick(() => {
        setTimeout(() => {//这个是一个初始化默认值的一个技巧
          self.addressSlots[0].defaultIndex = 0;
        }, 100);
      });
      self.$http.get(`${process.env.API.DICT}/dict/area?kind=all`).then(res => {
        if (!res.data.errcode) {
          address = res.data
          self.addressSlots[0].values = address;
          self.address = address;
        }
      }).catch(err => {
        console.log(err)
      })
      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/brand`, '/dict/brand')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/material`, '/dict/material')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/fineness`, '/dict/fineness')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/function`, '/dict/function')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/shape`, '/dict/shape')

      self.$fun.getObj.get_list(self, `${process.env.API.DICT}/dict/movement`, '/dict/movement')
      self.$http.get(`${process.env.API.NEWS}/news/agreement?name=EXCHANGE`).then(res => {
        self.xieyi = res.data.data
        self.xieyi.publish_time = this.$moment(self.xieyi.publish_time * 1000).format('YYYY-MM-DD HH:mm:ss')
      }).catch(err => {
        console.log(err)
      })
    },
    watch: {
      'postData.original_price'() {
        let self = this
        let reg = /^\d+(\.\d{0,2})?$/
        if (!self.postData.original_price) {
          return false
        }
        if (!reg.test(self.postData.original_price)) {
//          self.postData.original_price = self.postData.original_price.toFixed(2)
          self.$toast(this.$t('decimal'))
        }
      },
      'postData.price'() {
        let self = this
        let reg = /^\d+(\.\d{0,2})?$/
        if (!self.postData.price) {
          return false
        }
        if (!reg.test(self.postData.price)) {
//          self.postData.original_price = self.postData.original_price.toFixed(2)
          self.$toast(this.$t('decimal'))
        }
      }
    }
  }
</script>
<style lang="less" type="text/less" scoped>
  .sell {
    height: 100vh;
    &.hide {
      overflow: hidden;
    }
  }

  .loser {
    padding-left: 15px;
    background: #fff;
    margin-top: 10px;
    p {
      font-size: 14px;
      color: #db4a4a;
      height: 44px;
      line-height: 44px;
      border-bottom: 1px solid #f2f2f2;
    }
    div {
      font-size: 12px;
      color: #333;
      padding: 15px 15px 15px 0;
    }
  }
  .process{
    width: 100%;
    box-sizing: border-box;
    font-size: 14px;
    color: #333;
    padding: 15px 0;
    position: relative;
    .processTit{
      padding: 12px 15px 30px;
      color: #333;
      font-size: 20px;
    }
    .processMain{
      display: flex;
      width: 340px;
      margin: auto;
      align-items: flex-start;
      justify-content: flex-start;
      box-sizing: border-box;
      font-size: 12px;
      color: #666;
      &:last-child{
        justify-content: flex-end;
      }
      p{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 85px;
        text-align: center;
        word-break: break-word;
        img{
          width: 44px;
          height: 44px;
          display: block;
          margin-bottom: 5px;
        }
      }
      div{
        padding-top: 20px;
        box-sizing: border-box;
        img{
          height: 5px;
          display: block;
        }
      }
    }
    .processDown{
      width:340px;
      display: flex;
      justify-content: flex-end;
      box-sizing: border-box;
      margin: 5px auto;
      padding: 0 40px;
      img{
        width: 5px;
        height: 42.22px;
      }
    }
    .btn {
      width: 250px;
      height: 44px;
      line-height: 44px;
      text-align: center;
      background: #333;
      color: #fff;
      margin: 50px auto 0;
    }
  }
  .topNav {
    display: flex;
    justify-content: center;
    background: #fff;
    font-size: 14px;
    div{
      min-width: 100px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #666;
      &.topNavActive{
        position: relative;
        color: #333;
        font-weight: bold;
        &:before{
          position: absolute;
          width: 20px;
          height: 2px;
          content: '';
          background: #333;
          bottom: 0;
          left: calc(~'50% - 10px');
        }
      }
    }
  }
  .formData {
    margin-top: 10px;
    color: #999;
    width: 100%;
    .brand {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      height: 44px;
      background: #fff;
      padding: 0 15px;
      box-sizing: border-box;
      margin-bottom: 10px;
      img {
        width: 7px;
        height: 12px;
      }
    }
    .tit {
      background: #fff;
      padding-left: 15px;
      margin-bottom: 10px;
      p {
        color: #333;
        height: 44px;
        line-height: 44px;
        font-size: 14px;
        border-bottom: 1px solid #ecf0f4;
        margin-bottom: 15px;
        padding-right: 15px;
      }
      textarea {
        width: 100%;
        box-sizing: border-box;
        border: none;
        font-size: 14px;
        padding-right: 15px;
      }
      span {
        font-size: 12px;
        color: #999;
      }
    }
    .describe {
      background: #fff;
      padding-left: 15px;
      margin-bottom: 10px;
      box-sizing: border-box;
      span {
        font-size: 12px;
      }
      .describeP {
        color: #333;
        height: 44px;
        line-height: 44px;
        font-size: 14px;
        border-bottom: 1px solid #ecf0f4;
        margin-bottom: 15px;
        padding-right: 15px;
      }
      textarea {
        font-size: 14px;
        width: 100%;
        border: none;
        padding-right: 15px;
        box-sizing: border-box;
      }
      .img {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        box-sizing: border-box;
        padding-right: 15px;
        div {
          margin-bottom: 15px;
        }
      }
      p {
        color: #999;
        display: flex;
        align-items: center;
        span {
          font-size: 12px !important;
          display: block;
        }
      }
    }
    .info {
      padding: 0 15px;
      background: #fff;
      margin-bottom: 30px;
      .wrap {
        border-bottom: 1px solid #f2f2f2;
        padding-bottom: 15px;
        p {
          padding: 15px 0;
        }
        ul {
          display: flex;
          flex-wrap: wrap;
          li {
            width: 25%;
            display: flex;
            margin-bottom: 10px;
            box-sizing: border-box;
            div {
              width: 80px;
              height: 24px;
              background: #ecf0f4;
              box-sizing: border-box;
              color: #333;
              text-align: center;
              font-size: 12px;
              line-height: 24px;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              &.active {
                background: #333;
                color: #fff;
              }
            }
          }
        }
      }
      .selStyle {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 44px;
        border-bottom: 1px solid #f2f2f2;
        box-sizing: border-box;
        .wapTit{
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          word-break: normal;
          max-width: 120px;
        }
        .bank {
          width: calc(~'100% - 110px');
          display: flex;
          justify-content: flex-end;
          align-items: center;
          height: 100%;
          position: relative;
          p {
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            img {
              width: 7px;
              height: 12px;
              margin-left: 5px;
            }
          }
          select {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
          }
        }
        &:last-child {
          border: none;
        }
        input {
          border: none;
          text-align: right;
          padding-right: 5px;
          box-sizing: border-box;
          max-width: 140px;
        }
        .selInputShow{
          display: flex;
          justify-content: flex-end;
          align-items: flex-end;
        }
        div {
          color: #333;
          font-size: 14px;
          span {
            color: #999;
            font-size: 12px;
            &.rmb {
              font-size: 14px;
              color: #333;
            }
          }
          img {
            width: 7px;
            height: 12px;
          }
        }
      }
    }
    .btn {
      width: 250px;
      height: 44px;
      background: #333;
      color: #fff;
      text-align: center;
      line-height: 44px;
      margin: auto;
      margin-bottom: 50px;
    }
  }

  .fontColor {
    color: #333;
  }

  .fooColor {
    color: #ccc !important;
  }

  .condition {
    padding: 0 15px;
    li {
      color: #333;
      font-size: 14px;
      display: flex;
      min-height: 44px;
      padding: 10px 0;
      border-top: 1px solid #f2f2f2;
      box-sizing: border-box;
      &:last-child {
        border-bottom: 1px solid #f2f2f2;
      }
      p {
        max-width: 140px;
      }
      span {
        display: inline-block;
        padding-top: 2px;
        max-width: calc(~'100% - 140px');
        font-size: 12px;
        color: #666;
        padding-left: 10px;
      }
    }
  }

  /*图片样式*/
  /*提交图片*/

  @media screen and (min-width: 414px) {
    .avatar-uploader .el-upload {
      width: 120px !important;
      height: 120px !important;
    }

    .avatar {
      width: 120px !important;
      height: 120px !important;
    }

    .avatar-uploader {
      height: 120px !important;
      margin-bottom: 15px !important;
      width: 32%;
    }
  }

  @media screen and (min-width: 500px) {
    .avatar-uploader .el-upload {
      width: 135px !important;
      height: 135px !important;
    }

    .avatar {
      width: 135px !important;
      height: 135px !important;
    }
  }

  .avatar-uploader {
    height: 105px;
    span {
      position: absolute;
      right: -7px;
      top: -7px;
      img {
        width: 14px;
        height: 14px;
        border-radius: 50%;
      }
    }
  }

  .avatar-uploader .el-upload {
    border-radius: 0;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    box-sizing: border-box;
    width: 105px;
    height: 105px;
    img {
      object-fit: cover
    }
    p{
      position: absolute;
      bottom: 0;
      width: 100%;
      left: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
      border: none;
      padding: 0;
      margin: 0;
      font-size: 14px;
    }
  }

  .avatar-uploader .el-upload:hover {
    border-color: #20a0ff;
  }

  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    text-align: center;
  }

  .avatar {
    width: 105px;
    height: 105px;
    display: block;
    &.avatar {
      width: 100% !important;
    }
  }

  .avatar-uploader {
    width: 30%;
  }
</style>
<style lang="less" type="text/less">
  .el-upload {
    position: relative;
  }

  body {
    background: #ecf0f4;
    padding: 0 !important;
  }

  .mint-cell:last-child {
    background: none !important;
  }

  .mint-checklist-title {
    margin: 0 !important;
  }

  .mint-checklist-label {
    padding: 0 !important;
    span {
      font-size: 12px !important;
    }
  }

  .mint-cell-wrapper {
    border: none !important;
    span {
    }
  }

  .brandStyle {
    display: flex !important;
    align-items: center;
    span {
      color: #333;
    }
    .mint-cell-title {
      flex: 0;
    }
    img {
      width: 60px;
      height: 30px;
      margin-right: 10px;
      object-fit: cover;
    }
  }

  .popBtn {
    margin-top: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow: scroll;
    padding: 15px;
    img {
      width: 15px;
      height: 15px;
      position: absolute;
      right: 15px;
      top: 15px;
    }
    .tit {
      font-size: 16px;
      color: #333;
      margin: 15px auto 10px;
    }
    .edit {
      font-size: 12px;
      color: #999;
      width: calc(~'100% + 30px');
      border-bottom: 1px solid #f2f2f2;
      text-align: center;
      padding-bottom: 15px;
      margin-bottom: 30px;
    }
    .content {
      font-size: 14px;
      div {
        &:first-child {
          margin-bottom: 30px;
          p {
            font-size: 12px;
            color: #333;
            &:first-child {
              margin-bottom: 30px;
            }
          }
        }
        &:last-child {
          p {
            font-size: 12px;
            color: #666;
          }
          ul {
            font-size: 12px;
            color: #666;
          }
        }
      }
    }
  }

</style>
