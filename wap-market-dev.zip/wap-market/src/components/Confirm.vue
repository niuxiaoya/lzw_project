<template>
  <div class="confirm">
    <ul>
      <li><span>{{postData.cardholder}}</span></li>
      <li><span>{{postData.cardnum}}</span></li>
      <li><span>{{gjName}}</span></li>
      <li><span>{{postData.bank_name}}</span></li>
      <li v-if="postData.is_china==1"><span>{{postData.opening_bank}}</span></li>
    </ul>
    <div class="btn" @click="add">
      {{$t('confirmAdd')}}
    </div>
    <div class="foo">
      {{$t('bankText')}}
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        gjName: '',
        gjList: [
          {name: this.$t('china'), id: 1},
          {name: this.$t('other'), id: 2}
        ],
        bankNum: 0,
        postData: {
          cardholder: '',
          cardnum: '',
          is_china: '',
          bank_name: '',
          opening_bank: ''
        }
      }
    },
    methods: {
      add() {
        let self = this
        self.$fun.postObj.post_data(self, `${process.env.API.USER}/user/bankcard`, self.postData, '/user/bankcard')
      }
    },
    mounted() {
      let self = this
      document.title = this.$t('bankInfo')
      let bankInfo = JSON.parse(localStorage.getItem('bankInfo'))
      if (!bankInfo) {
        self.$router.push('/')
        return false
      } else {
        setTimeout(() => {
          self.postData.cardholder = bankInfo.cardholder
          self.postData.cardnum = bankInfo.cardnum
          self.postData.is_china = bankInfo.is_china
          self.postData.bank_name = bankInfo.bank_name
          self.postData.opening_bank = bankInfo.opening_bank
          for (let i = 0; i < self.gjList.length; i++) {
            if (self.gjList[i].id == self.postData.is_china) {
              self.gjName = self.gjList[i].name
            }
          }
        }, 300)
      }
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .confirm {
    ul {
      margin-top: 10px;
      padding-left: 15px;
      background: #fff;
      li {
        color: #999;
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 44px;
        font-size: 14px;
        padding-right: 15px;
        border-bottom: 1px solid #f2f2f2;
        &:last-child {
          img {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            margin-right: 5px;
            border: none;
          }
        }
        span {
          display: flex;
          align-items: center;
          color: #333;
        }
      }
    }
    .btn {
      width: 250px;
      height: 44px;
      line-height: 44px;
      background: #333;
      color: #fff;
      text-align: center;
      margin: 75px auto 30px;
      font-size: 16px;
    }
    .foo {
      font-size: 12px;
      color: #999;
      width: 300px;
      margin: auto;
      line-height: 22px;
      text-align: center;
    }
  }
</style>
<style lang="less">
  body {
    background: #ecf0f4 !important;
    padding: 0 !important;
  }
</style>
