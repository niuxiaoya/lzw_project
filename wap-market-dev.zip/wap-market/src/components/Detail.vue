<template>
  <div class="detail">
    <div class="head">
      <div class="threesixty car" v-show="watchInfo.is_360==1&&albumNum==0">
        <div class="spinner">
          <span>0%</span>
        </div>
        <ol class="threesixty_images"></ol>
        <span style="position: absolute;top: 15px;right: 15px">
        <img src="../assets/images/market/360.png">
      </span>
      </div>
      <div class="album" v-if="watchInfo.is_360==1">
        <img class="albumImg" :style="{height:hei+'px'}" :src="watchInfo.file_pic[albumNum-1]" v-if="albumNum!=0" @click.stop="selectImg(albumNum-1,watchInfo.file_pic[albumNum-1])">
        <ul>
          <li @click="albumNum=0">
            <img :src="is360" class="albumImgList">
            <span>
            <img src="../assets/images/market/360.png">
          </span>
          </li>
          <li v-for="item,index in watchInfo.file_pic" @click="albumNum=index+1">
            <img :src="item" class="albumImgList">
          </li>
        </ul>
      </div>
      <mt-swipe :show-indicators="false" @change="handleChange" :auto="0" v-show="watchInfo.is_360==0">
        <mt-swipe-item v-for="(item,key) in watchInfo.file_pic" :key="key"><img :src="item" @click.stop="selectImg(key,item)"></mt-swipe-item>
        <p class="num">{{swiperNum}}/{{watchInfo.file_pic?watchInfo.file_pic.length:''}}</p>
      </mt-swipe>
      <div class="wrap">
        <div class="tit">{{watchInfo.title}}</div>
        <div class="money">
          <div :class="{'isNew':watchInfo.original_price!=watchInfo.price}">
            USD: {{watchInfo.price}}
            <p v-if="watchInfo.original_price!=watchInfo.price">{{watchInfo.original_price}}</p>
          </div>
          <p class="re">
            {{watchInfo.reference_price}}
          </p>
          <span class="new" :class="{'isNew':watchInfo.original_price!=watchInfo.price}" v-if="watchInfo.fineness_name">
            {{watchInfo.fineness_name}}
          </span>
        </div>
      </div>
      <div class="officialPrice">
        <div class="tit">
          {{$t('officialMediaPrice')}}
        </div>
        <ul>
          <li v-for="item in watchInfo.official_price">
            <p>{{item[0]}}</p>
            <span>{{item[1]}}</span>
          </li>
        </ul>
      </div>
      <div class="rate">
        <div class="rateFirst" @click="rateShow=!rateShow">
          {{$t('realTime')}}
          <img src="../assets/images/market/detail/down.png" :class="{'active':rateShow}">
        </div>
        <div class="rateLast" v-show="rateShow">
          <p>{{watchInfo.rate}}</p>
          <span>{{watchInfo.rate_str}}</span>
        </div>
      </div>
      <div class="guarantee" @click="$router.push({name:'Guarantee',params:watchInfo})">
        {{$t('protection')}}
        <img src="../assets/images/market/newArrow.png" alt="">
      </div>
    </div>
    <div class="nav">
      <ul>
        <li @click="navNum=0" :class="{'active':navNum==0}">
          {{$t('graphicDetails')}}
        </li>
        <li @click="navNum=1" :class="{'active':navNum==1}">
          {{$t('parameter')}}
        </li>
        <li @click="navNum=2" :class="{'active':navNum==2}">
          {{$t('traceability')}}
        </li>
      </ul>
    </div>
    <div class="main">
      <no-more v-show="navNum==0&&watchInfo&&!watchInfo.graphic_details" :style="{top:0}"></no-more>
      <div class="picWrap" v-show="navNum==0&&watchInfo&&watchInfo.graphic_details" >
        <div class="selectShow">
          <div class="selectDetail">
            <p>
              {{translate}}
            </p>
            <select name="select1" v-model="translateVal" @change="selShow">
              <option v-for="item in langList" :value="item.value">{{item.label}}</option>
            </select>
          </div>
          <div @click="viewTextClick(1)" v-show="text.one==2" class="textBtn">
            {{$t('viewOriginal')}}
          </div>
        </div>
        <div v-if="text.one==2" class="machine">{{text.machineOne}}</div>
        <div class="pic" v-html="watchInfo.graphic_details"></div>
      </div>
      <div class="parameter" v-show="navNum==1">
        <ul>
          <li>
            <p>
              {{$t('location')}}
            </p>
            <span class="lang">
             {{watchInfo.country_name}}({{watchInfo.country_short_name}}) <img :src="watchInfo.country_flag">
            </span>
          </li>
          <li>
            <p>
              {{$t('isBrand')}}
            </p>
            <span>
              {{watchInfo.brand_name}}
            </span>
          </li>
          <li>
            <p>
              {{$t('model')}}
            </p>
            <span>
              {{watchInfo.model_num?watchInfo.model_num:$t('no')}}
            </span>
          </li>
          <li>
            <p>
              {{$t('shape')}}
            </p>
            <span>
              {{watchInfo.shape_name?watchInfo.shape_name:$t('no')}}
            </span>
          </li>
          <li>
            <p>
              {{$t('movement')}}
            </p>
            <span>
              {{watchInfo.movement_name?watchInfo.movement_name:$t('no')}}
            </span>
          </li>
          <li>
            <p>
              {{$t('material')}}
            </p>
            <span>
              {{watchInfo.material_name?watchInfo.material_name:$t('no')}}
            </span>
          </li>
          <li>
            <p>
              {{$t('condition')}}
            </p>
            <span>
              {{watchInfo.fineness_name?watchInfo.fineness_name:$t('no')}}
            </span>
          </li>
          <li>
            <p>
              {{$t('function_name')}}
            </p>
            <span>
              {{watchInfo.function_name?watchInfo.function_name:$t('no')}}
            </span>
          </li>
          <li>
            <p>
              {{$t('diameter')}}
            </p>
            <span>
              {{watchInfo.diameter?watchInfo.diameter:0}}MM
            </span>
          </li>
          <li>
            <p>
              {{$t('gender')}}
            </p>
            <span>
              {{watchInfo.gender_name?watchInfo.gender_name:$t('no')}}
            </span>
          </li>
        </ul>
      </div>
      <no-more v-show="navNum==2&&watchInfo&&!watchInfo.history" :style="{top:0}"></no-more>
      <div class="picWrap" v-show="navNum==2&&watchInfo&&watchInfo.history">
        <div class="selectShow">
          <div class="selectDetail">
            <p>
              {{translate1}}
            </p>
            <select name="select2" v-model="translateVal1" @change="selShow">
              <option v-for="item in langList" :value="item.value">{{item.label}}</option>
            </select>
          </div>
          <div @click="viewTextClick(2)" v-show="text.two==2" class="textBtn">
            {{$t('viewOriginal')}}
          </div>
        </div>
        <div v-if="text.two==2" class="machine">{{text.machineTwo}}</div>
        <div class="pic" v-html="watchInfo.history"></div>
      </div>
    </div>
    <div class="foo">
      <div class="fooWrap">
        <div @click="sub(1)">
          <span class="kefu"></span>
        </div>
        <div @click="sub(2)" :class="{'active':watchInfo.is_collect==1}">
          <span class="star"></span>
        </div>
      </div>
      <p class="pay" @click="sub(3)" :class="{'noClick':watchInfo.exchange_stage !=30}">{{$t('buy')}}</p>
    </div>
    <transition name="slide-fade" class="fadeView">
      <div v-if="show">
        <image-view :imgArr="watchInfo.source_pic"
                    :showImageView="true"
                    :imageIndex="imageIndex"
                    v-on:hideImage="hideImageView"
        >
        </image-view>
      </div>
    </transition>
  </div>
</template>
<script>
  import ThreeSixty from '@/plugin/threesixty'
  import imageView from 'vue-imageview'

  export default {
    data() {
      return {
        uid: '',
        navNum: 0,
        swiperNum: 1,
        text:{
          one:1,
          two:1,
          textOne:'',
          textTwo:'',
          machineOne:'',
          machineTwo:''
        },
        watchInfo: {},
        albumNum: 0,
        is360: '',
        hei:0,
        langList:[
          {
            value:'zh',
            label:'中文（简）',
          }, {
            value:'cht',
            label:'中文（繁）',
          }, {
            value:'en',
            label:'English',
          }, {
            value:'fra',
            label:'Français',
          }, {
            value:'de',
            label:'Deutsch',
          }
        ],
        translate:this.$t('viewTranslation'),
        translate1:this.$t('viewTranslation'),
        translateVal:'',
        translateVal1:'',
        rateShow:false,
        // 显示组件
        show: false,
        // 从哪一张图片开始
        imageIndex: 0,
        imgKey: 0,
        messageBtn: {
          message: this.$t('isLogin'),
          title: this.$t('prompt'),
          confirmButtonText: this.$t('confirm'),
          cancelButtonText: this.$t('cancel'),
          showCancelButton: true,
          showConfirmButton: true
        },
      }
    },
    methods: {
      hideImageView() {
        document.body.style.overflow = 'visible'
        setTimeout(() => {
          this.show = false
        }, 300)
      },
      selectImg(index, item) {
        document.body.style.height = '100vh'
        document.body.style.overflow = 'hidden'
        this.show = true
        this.imageIndex = index
      },
      selShow(el){
        if(this.navNum==0){
          for(let value of this.langList){
            if(this.translateVal==value.value){
              this.translate = value.label
              let post = {
                is_html:1,
                content:this.text.textOne,
                target:this.translateVal,
                key:'graphic_details',
                gid:this.watchInfo.gid
              }

              this.$indicator.open();
              this.$http.post(`${process.env.API.SYSTEM}/system/translate`,post).then(res=>{
                if(res.data.errcode=='0'){
                  res.data.content = this.sethtml(res.data.content)
                  this.watchInfo.graphic_details = res.data.content
                  this.text.one=2
                  this.text.machineOne=res.data.supply
                }
                this.$indicator.close();
              }).catch(err=>{
                this.$indicator.close();
                console.log(err)
              })
            }
          }
        }else{
          for(let value of this.langList){
            if(this.translateVal1==value.value){
              this.translate1 = value.label
              let post = {
                is_html:1,
                content:this.text.textTwo,
                target:this.translateVal1,
                key:'history',
                gid:this.watchInfo.gid
              }
              this.$indicator.open();
              this.$http.post(`${process.env.API.SYSTEM}/system/translate`,post).then(res=>{
                if(res.data.errcode=='0'){
                  res.data.content = this.sethtml(res.data.content)
                  this.text.two=2
                  this.watchInfo.history = res.data.content
                  this.text.machineTwo=res.data.supply
                }
                this.$indicator.close();
              }).catch(err=>{
                this.$indicator.close();
                console.log(err)
              })
            }
          }
        }
      },
      viewTextClick(index){
        if(index==1){
          this.text.one=1
          this.watchInfo.graphic_details = this.text.textOne
          this.translate = this.$t('viewTranslation')
          this.text.machineOne = ''
          this.translateVal = ''
        }else{
          this.text.two=1
          this.watchInfo.history = this.text.textTwo
          this.translate1 = this.$t('viewTranslation')
          this.text.machineTwo = ''
          this.translateVal1 = ''
        }
      },
      sethtml (html) {
        return html
          .replace(html ? /&(?!#?\w+;)/g : /&/g, '&amp;')
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
          .replace(/&quot;/g, "\"")
          .replace(/&#39;/g, "\'");
      },
      sub(index) {
        let self = this
        if (!self.uid) {
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }
        switch (index) {
          case 1:
            location.href = `${process.env.URL.USER}/#/email`
            break;
          case 2:
            if (self.watchInfo.is_collect == 1) {
              self.$http.delete(`${process.env.API.USER}/user/collect?collect_id=${self.watchInfo.gid}&publish_uid=${self.watchInfo.user_uid}&type=goods`).then(res=>{
                if(res.data.errcode=='0'){
                  self.watchInfo.is_collect = 0
                }else{
                  self.$toast(res.data.errmsg)
                }
              }).catch(err=>{
                console.log(err)
              })
            } else {
              self.$http.post(`${process.env.API.USER}/user/collect`,{
                collect_id: self.watchInfo.gid,
                publish_uid: self.watchInfo.user_uid,
                type: 'goods'
              }).then(res=>{
                if(res.data.errcode=='0'){
                  self.watchInfo.is_collect = 1
                }else{
                  self.$toast(res.data.errmsg)
                }
              }).catch(err=>{
                console.log(err)
              })
            }
            break;
          case 3:
            if (self.watchInfo.exchange_stage != 30) {
              return false
            }
            self.$router.push(`/order?gid=${self.watchInfo.gid}&user_uid=${self.watchInfo.user_uid}`)
            break;
        }
      },
      handleChange(index) {
        this.swiperNum = index + 1
      }
    },
    created() {
      document.title = this.$t('commodity')
      window.scrollTo(0,0)
      this.hei = document.body.clientWidth
      //测试3D效果
    },
    mounted() {
      //测试3D
      let self = this

      // 调用url参数方法
      if (self.$fun.GetQueryString('id', 'detail')) {
        this.$indicator.open();
        self.$http.get(`${process.env.API.MARKET}/market/buyer/watchinfo?gid=${self.$fun.GetQueryString('id', 'detail')}`).then((res) => {
          if (res.data.errcode == '0') {
            res.data.manage.file_pic = res.data.manage.file_pic.split(',') || []//商品图片轮播
            res.data.manage.source_pic = res.data.manage.source_pic.split(',') || []//商品图片轮播
            res.data.manage.create_time = self.$moment(res.data.manage.create_time*1000).format('YYYY-MM-DD HH:mm:ss')||''//创建时间
            res.data.manage.tel = res.data.manage.tel ? `${res.data.manage.tel.substring(0, 3)}****${res.data.manage.tel.substring(res.data.manage.tel.length - 4)}` : ''//订单状态
            res.data.manage.guarantee =res.data.manage.guarantee?this.sethtml(res.data.manage.guarantee):''
            res.data.manage.history = res.data.manage.history?this.sethtml(res.data.manage.history):''
            self.text.textOne = res.data.manage.graphic_details
            self.text.textTwo= res.data.manage.history
            self.watchInfo = res.data.manage
            self.uid = localStorage.getItem('userId')
            if (res.data.manage.file_pic_360 && res.data.manage.file_pic_360.total_num) {
              self.is360 = `${res.data.manage.file_pic_360.url}/1${res.data.manage.file_pic_360.ext}`
              let product = $('.car').ThreeSixty({
                totalFrames: res.data.manage.file_pic_360.total_num,
                endFrame: res.data.manage.file_pic_360.total_num,
                currentFrame: 1,
                imgList: '.threesixty_images',
                progress: '.spinner',
                imagePath: `${res.data.manage.file_pic_360.url}/`,
                filePrefix: '',
                ext: res.data.manage.file_pic_360.ext,
                height: self.hei,
                width: '',
                navigation: true,
                disableSpin: false
              });
            }
            this.$indicator.close();
          } else {
            self.$messagebox.alert(res.data.errmsg)
            this.$indicator.close();
          }
        }).catch((err) => {
          console.log(err)
          this.$indicator.close();
        })
//        self.$fun.getObj.get_info(self, ``, '/market/buyer/watchinfo')
      } else {
        self.$messagebox.alert(self.$t('noOrder')).then((action) => {
          self.$router.push('/')
        })
      }
    },
    components:{
      'image-view': imageView
    }
  }
</script>
<style lang="less" scoped type="text/less">
  @media screen and (min-width: 410px) {
    .mint-swipe {
      height: 414px !important;
    }

    .processMain {
      width: 400px !important;
      p {
        width: 105px !important;
      }
    }

    .processDown {
      width: 400px !important;
      padding: 0 45px !important;
    }
  }

  .noClick {
    background: #ccc !important;
  }

  .album {
    .albumImg {
      width: 100%;
      object-fit: cover;
      display: block;
    }
    ul {
      display: flex;
      width: 100%;
      overflow: scroll;
      padding: 6px;
      box-sizing: border-box;
      -webkit-overflow-scrolling: touch;
      li {
        box-sizing: border-box;
        height: 100px;
        width: 100px;
        margin-right: 6px;
        position: relative;
        .albumImgList {
          width: 100px;
          height: 100px;
          object-fit: cover;
        }
        span {
          position: absolute;
          top: 5px;
          right: 5px;
          img{
            width: 36px!important;
          }
        }
      }
    }
  }

  .detail {
    .head {
      color: #333;
      img {
        width: 100%;
        display: block;
        object-fit: cover;
      }
      .wrap {
        padding: 15px 15px 40px 0;
        background: #fff;
        margin-bottom: 10px;
        .tit {
          font-size: 16px;
          margin-bottom: 20px;
          padding-left: 15px;
          font-weight: bold;
        }
        .money {
          padding-left: 15px;
          div{
            font-size: 16px;
            color: #333;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            p{
              text-decoration: line-through;
              color: #999;
              font-size: 12px;
              height: 100%;
              margin-left: 5px;
              font-weight: normal;
            }
            &.isNew{
              color: #eb4343;
            }
          }
          .re{
            font-size: 12px;
            color: #999;
          }
          .new{
            border:1px solid #ccc;
            color: #333;
            font-size: 12px;
            margin-top: 15px;
            display: inline-block;
            padding: 0 3px;
            &.isNew{
              color: #eb4343;
              border-color: #eb4343;
            }
          }
        }
      }
      .officialPrice{
        background: #fff;
        font-size: 14px;
        color: #333;
        margin: 10px 0;
        .tit{
          font-weight: bold;
          height: 44px;
          display: flex;
          align-items: center;
          padding-left: 15px;
          box-sizing: border-box;
          width: 100%;
          border-bottom: 1px solid #f2f2f2;
        }
        ul{
          padding-left: 15px;
          li{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 14px;
            height: 44px;
            padding-right: 15px;
            box-sizing: border-box;
            border-bottom: 1px solid #f2f2f2;
            p{
              color: #999;
            }
            span{
              color: #333;
            }
          }
        }
      }
      .rate{
        margin-bottom: 10px;
        font-size: 14px;
        .rateFirst{
          display: flex;
          font-weight: bold;
          justify-content: space-between;
          align-items: center;
          height: 44px;
          background: #fff;
          padding: 0 15px;
          img{
            width: 14px;
            height: 9px;
            transition: all 0.5s;
            &.active{
              transform:rotate(180deg);
            }
          }
        }
        .rateLast{
          padding: 0 15px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 12px;
          background: #fafafa;
          height: 44px;
          p{
            color: #999;
          }
          span{
            color: #333;
          }
        }
      }
      .guarantee{
        font-size: 14px;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 15px;
        box-sizing: border-box;
        height: 44px;
        background: #fff;
        margin-bottom: 10px;
        img{
          width: 9px;
          height: 14px;
        }
      }
    }
    .nav {
      background: #fff;
      height: 44px;
      display: flex;
      align-items: center;
      border-bottom: 1px solid #f2f2f2;
      ul {
        color: #666;
        font-size: 14px;
        display: flex;
        width: 100%;
        justify-content: space-between;
        align-items: center;
        height: 44px;
        padding: 0 15px;
        box-sizing: border-box;
        li {
          position: relative;
          min-width: 90px;
          text-align: center;
          max-width: 33%;
          height: 44px;
          box-sizing: border-box;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          word-break: normal;
          line-height: 44px;
          &.active {
            color: #333;
            border-bottom: 2px solid #333;
            font-weight: bold;
          }
        }
      }
    }
    .main{
      margin-bottom: 100px;
      min-height: 238px;
      position: relative;
      .parameter{
        background: #fff;
        padding: 0 15px;
        li{
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px 0;
          box-sizing: border-box;
          min-height: 44px;
          border-bottom: 1px solid #f2f2f2;
          font-size: 14px;
          &:last-child{
            border:none;
          }
          P{
            color: #999;
            min-width: 40%;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
          }
          span{
            color: #333;
            &.lang{
              display: flex;
              align-items: center;
              img{
                height: 16px;
                display: flex;
                align-items: center;
                margin-left: 5px;
              }
            }
          }
        }
      }
      .picWrap{
        .selectShow{
          background: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #007099;
          font-size: 14px;
          height: 44px;
          border-bottom: 1px solid #f2f2f2;
          .selectDetail{
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            select{
              opacity: 0;
              position: absolute;
              background: none;
              width: 100%;
              border:none;
            }
          }
          .textBtn{
            margin-left: 15px;
          }
        }
        .pic{
          padding: 15px;
          box-sizing: border-box;
          background: #fff;
        }
        .machine{
          background: #fff;
          color: #333;
          padding: 15px 15px 0;
          box-sizing: border-box;
        }
      }
    }
    .foo {
      display: flex;
      width: 100%;
      position: fixed;
      bottom: 0;
      left: 0;
      background: #fff;
      color: #333;
      font-size: 14px;
      border-top: 1px solid #f2f2f2;
      box-sizing: border-box;
      z-index: 999;
      .fooWrap {
        width: 35%;
        display: flex;
        div {
          display: flex;
          flex-direction: column;
          justify-content: center;
          background: none !important;
          width: 50%;
          align-items: center;
          color: #999;
          font-size: 12px;
          p {
            width: 50px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            text-align: center;
          }
          &.active {
            color: #333;
            .star {
              background-image: url("../assets/images/market/detail/starActive.png");
            }
          }
          .kefu {
            background-image: url("../assets/images/market/detail/kefu.png");
            background-repeat: no-repeat;
            background-size: cover;
            width: 15px;
            height: 15px;
          }
          .star {
            background-image: url("../assets/images/market/detail/star.png");
            background-repeat: no-repeat;
            background-size: cover;
            width: 15px;
            height: 15px;
          }
          /*width: 15px;*/
          /*height: 15px;*/
        }
      }
      .pay {
        width: 65%;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        img {
          width: 23px;
          height: 23px;
          margin-right: 15px;
        }
        &:last-child {
          background: #ec4e4e;
          color: #fff;
        }
      }
    }
    .process {
      width: 100%;
      box-sizing: border-box;
      font-size: 14px;
      color: #333;
      padding: 15px 0;
      position: relative;
      .processTit {
        padding: 12px 15px 30px;
        color: #999;
      }
      .processMain {
        display: flex;
        width: 340px;
        margin: auto;
        align-items: flex-start;
        justify-content: flex-start;
        box-sizing: border-box;
        font-size: 12px;
        color: #666;
        &:last-child {
          justify-content: flex-end;
        }
        p {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          width: 85px;
          text-align: center;
          word-break: break-word;
          img {
            width: 44px;
            height: 44px;
            display: block;
            margin-bottom: 5px;
          }
        }
        div {
          padding-top: 20px;
          box-sizing: border-box;
          img {
            height: 5px;
            display: block;
          }
        }
      }
      .processDown {
        width: 340px;
        display: flex;
        justify-content: flex-end;
        box-sizing: border-box;
        margin: 5px auto;
        padding: 0 40px;
        img {
          width: 5px;
          height: 42.22px;
        }
      }
      .processCentent {
        width: 340px;
        display: flex;
        justify-content: center;
        box-sizing: border-box;
        margin: 5px auto;
        img {
          width: 5px;
          height: 42.22px;
        }
      }
      &:last-child {
        &:before {
          content: '';
          width: calc(~'100% - 15px');
          height: 1px;
          background: #f2f2f2;
          position: absolute;
          right: 0;
          top: 0;
        }
      }
    }
  }
  .mint-swipe {
    position: relative;
    .num {
      position: absolute;
      bottom: 15px;
      right: 15px;
      width: 50px;
      height: 30px;
      font-size: 14px;
      background: rgba(3, 3, 3, 0.5);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    height: 375px;
    color: #fff;
    font-size: 30px;
    text-align: center;
    margin-bottom: 0;
    img {
      width: 100%;
      height: 100%;
    }
    /*.mint-swipe-items-wrap{*/
    /*min-height: 230px!important;*/
    /*.mint-swipe-item{*/
    /*min-height: 230px;*/
    /*}*/
    /*}*/
  }
</style>
<style lang="less" type="text/less">
  body {
    background: #ecf0f4;
    padding: 0;
  }

  .mint-swipe-items-wrap {
    min-height: 100% !important;
  }
</style>
