<template>
  <div class="search">
    <div class="tit">
      <div>
        <img src="../assets/images/market/search.png">
        <input type="text" :placeholder="$t('inputBrand')" v-model="searchText"  @keyup.13="openShow($event)">
        <img src="../assets/images/market/close.png" @click="searchText=''" v-if="searchText!=''">
      </div>
      <span @click="openShow">{{$t('confirm')}}</span>
    </div>
    <div class="wrap">
      <div class="hot">
      <span>
        {{$t('hotSearch')}}
      </span>
        <ul>
          <li v-for="item in hotList" @click="hotClick(item)">{{item.name}}</li>
        </ul>
      </div>
      <div class="history">
        <span>{{$t('history')}}</span>
        <ul>
          <li v-for="item,index in historyList" @click="$router.push({name:'Index',params:{search:item}})" v-if="index<5">
            {{item}}
          </li>
        </ul>
      </div>
    </div>
    <div class="remove" v-if="historyList.length>0" @click="clearLocal">
      {{$t('removeHistory')}}
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        searchText: '',
        historyList: [],
        hotList: [
          {name: this.$t('search1')},
          {name: this.$t('search2')},
          {name: this.$t('search3')},
          {name: this.$t('search4')},
          {name: this.$t('search5')},
          {name: this.$t('search6')},
          {name: this.$t('search7')},
          {name: this.$t('search8')},
        ]
      }
    },
    methods: {
      openShow(event) {
        let self = this
        if (self.searchText) {
          localStorage.removeItem('historyList')
          self.historyList.push(self.searchText)
          localStorage.setItem('historyList', self.historyList)
        }
        self.$router.push({name: 'Index', params: {search: this.searchText}})
      },
      hotClick(item) {
        this.$router.push({name: 'Index', params: {search: item.name}})
      },
      clearLocal() {
        localStorage.removeItem('historyList')
        if (localStorage.getItem('historyList')) {
          this.historyList = localStorage.getItem('historyList').split(',') || []
        } else {
          this.historyList = []
        }
      }
    },
    mounted() {
      if (localStorage.getItem('historyList')) {
        this.historyList = localStorage.getItem('historyList').split(',') || []
        this.historyList.reverse()
      }
    }
  }
</script>
<style lang="less" scoped type="text/less">
  .search {
    .tit {
      display: flex;
      justify-content: space-between;
      padding: 10px 15px;
      background: #fff;
      div {
        display: flex;
        align-items: center;
        flex-wrap: nowrap;
        background: #ecf0f4;
        flex:2;
        padding: 0 15px 0 10px;
        height: 24px;
        box-sizing: border-box;
        img {
          width: 15px;
          font-size: 15px;
          margin-right: 5px;
          &:last-child {
            width: 7px;
            height: 7px;
          }
        }
        input {
          background: none;
          height: 100%;
          width: 100%;
        }
      }
      span {
        font-size: 16px;
        color: #333;
        display: inline-block;
        margin-left: 15px;
      }
    }
    .wrap {
      background: #fff;
      .hot {
        padding: 15px 15px 0;
        border-top: 1px solid #f2f2f2;
        border-bottom: 1px solid #f2f2f2;
        span {
          font-size: 12px;
          color: #999;
          display: block;
          margin-bottom: 15px;
        }
        ul {
          display: flex;
          flex-wrap: wrap;
          li {
            background: #ecf0f4;
            color: #333;
            font-size: 12px;
            padding: 8px;
            margin-right: 15px;
            margin-bottom: 15px;
          }
        }
      }
      .history {
        padding: 15px 0 0 15px;
        span {
          font-size: 12px;
          color: #999;
          display: block;
          padding-bottom: 25px;
          border-bottom: 1px solid #f2f2f2;
        }
        ul {
          font-size: 14px;
          height: 225px;
          color: #333;
          li {
            display: flex;
            align-items: center;
            height: 44px;
            border-bottom: 1px solid #f2f2f2;
          }
        }
      }
    }

    .remove {
      width: 250px;
      font-size: 16px;
      line-height: 44px;
      height: 44px;
      text-align: center;
      background: #333;
      color: #fff;
      margin: 30px auto;
    }
  }
</style>
<style lang="less">
  body {
    padding: 0;
    background: #ecf0f4;
  }
</style>
