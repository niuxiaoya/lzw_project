<template>
  <div class="ground">
    <div class="banner">
      <mt-swipe @change="handleChange" :auto="0" :show-indicators="false" :style="{height:hei}">
        <mt-swipe-item v-for="item,index in data.banner" :key="index">
          <img :src="item.file_pic" @click="topBanner(item)">
        </mt-swipe-item>
      </mt-swipe>
    </div>
    <div class="groundNav">
      <ul class="navStyle">
        <li v-for="item in nav" @click="navClick(item)">
          <img :src="item.src" :alt="item.name">
          <span>{{item.name}}</span>
        </li>
      </ul>
      <ul class="hotWatch">
        <li v-for="item in data.partwatch" @click="hotClick(item)">
          <img :src="item.cover_pic" :alt="item.title" class="imgBg">
          <div class="hotMainContent">
            <div class="hotMainContentTit">
              {{item.title}}
            </div>
            <p class="hotMainContentPrice" :class="{'isNew':item.original_price!=item.price}">
              {{item.price}}
            </p>
            <div class="hotMainContentFoo">
              <p v-if="item.original_price!=item.price">{{item.original_price}}</p>
              <span :class="{'isNew':item.original_price!=item.price}" v-if="item.fineness_name">
                {{item.fineness_name}}
              </span>
            </div>
          </div>
          <span class="is360" v-if="item.is_360==1">
            <img src="../assets/images/market/360.png">
          </span>
          <span class="lang">
            <img :src="item.country_flag">{{item.country_short_name}}
          </span>
        </li>
      </ul>
    </div>
    <div class="banners">
      <div class="bannersWrap" v-for="item in data.activity">
        <mt-swipe @change="handleChange" :auto="0" :show-indicators="false" :style="{height:bannersHei}">
          <mt-swipe-item v-for="el,index in item.value" :key="index">
            <img :src="el.cover_pic" @click="bannerClick(el)">
          </mt-swipe-item>
        </mt-swipe>
        <!--<span>{{item.name}}</span>-->
      </div>
    </div>
    <div class="watchList">
      <div class="title">
        {{$t('moreGoods')}}
      </div>
      <ul>
        <li v-for="item in marketList.data" @click="hotClick(item)">
          <img :src="item.cover_pic" :style="{height:imgHei}" class="imgBg">
          <div class="hotMainContent">
            <div class="hotMainContentTit">
              {{item.title}}
            </div>
            <p class="hotMainContentPrice" :class="{'isNew':item.original_price!=item.price}">
              {{item.price}}
            </p>
            <div class="hotMainContentFoo">
              <p v-if="item.original_price!=item.price">{{item.original_price}}</p>
              <span :class="{'isNew':item.original_price!=item.price}" v-if="item.fineness_name">
                {{item.fineness_name}}
              </span>
            </div>
          </div>
          <span class="is360" v-if="item.is_360==1">
            <img src="../assets/images/market/360.png">
          </span>
          <span class="lang">
            <img :src="item.country_flag">{{item.country_short_name}}
          </span>
        </li>
        <infinite-loading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="marketList.page.p>2">{{$t('noMore')}}</span>
          <span slot="no-results" v-show="marketList.page.p>2">{{$t('noMore')}}</span>
        </infinite-loading>
      </ul>
    </div>
    <div class="top" :class="{'isShow':top<900}" @click="goTop">
      <img src="../assets/images/market/ground/top.png">
    </div>
    <toolbar :type="2"></toolbar>
  </div>
</template>
<script>
  import toolbar from '../components/toolbar'
  import InfiniteLoading from 'vue-infinite-loading';
  export default {
    data() {
      return {
        top:0,
        hei: 0,
        imgHei:0,
        bannersHei: '280px',
        userInfo:{},
        uid:'',
        nav: [
          {
            name: this.$t('tb4'),
            src: require('../assets/images/market/ground/buy.png')
          }, {
            name:this.$t('sell'),
            src: require('../assets/images/market/ground/sell.png')
          }, {
            name: this.$t('vip'),
            src: require('../assets/images/market/ground/vip.png')
          }, {
            name: this.$t('tb1'),
            src: require('../assets/images/market/ground/friends.png')
          }, {
            name: this.$t('tb2'),
            src: require('../assets/images/market/ground/news.png')
          }
        ],
        bankList:[],
        data:{},
        marketList:{
          data:[],
          page:{
            p:0,
            total_pages:1
          }
        },
        messageBtn: {
          message: this.$t('isLogin'),
          title: this.$t('prompt'),
          confirmButtonText: this.$t('confirm'),
          cancelButtonText: this.$t('cancel'),
          showCancelButton: true,
          showConfirmButton: true
        },
      }
    },
    methods: {
      hotClick(item){
        location.href = `${process.env.URL.MARKET}/#/detail?id=${item.gid}`
      },
      bannerClick(item){
        if(item.type==2){
          this.$router.push({name:'GroundList',query:{aid:item.acid}})
        }else{
          location.href = `${process.env.URL.MARKET}/#/detail?id=${item.data_id}`
        }
      },
      topBanner(item){
        if(item.url){
          location.href = item.url
        }
      },
      navClick(item){
        let self = this
        switch (item.name){
          case this.$t('tb4'):
            location.href = `${process.env.URL.MARKET}/#/`
            break;
          case this.$t('sell'):
            if(!self.uid){
              self.messageBtn.message = this.$t('isLogin')
              self.$messagebox(self.messageBtn).then(action => {
                if (action == 'confirm') {
                  location.href = `${process.env.URL.USER}/#/login`
                }
              }).catch(err => {
                console.log(err)
              })
              return false
            }else if(self.userInfo&&self.userInfo.is_auth!=1){
              self.messageBtn.message = this.$t('isAuth')
              self.$messagebox(self.messageBtn).then(action => {
                if (action == 'confirm') {
                  location.href = `${process.env.URL.USER}/#/realname`
                }
              }).catch(err => {
                console.log(err)
              })
              return false
            }else if(self.bankList&&self.bankList.length<=0){
              self.messageBtn.message = this.$t('addBankList')
              self.$messagebox(self.messageBtn).then(action => {
                if (action == 'confirm') {
                  location.href = `${process.env.URL.MARKET}/#/banklist`
                }
              }).catch(err => {
                console.log(err)
              })
              return false
            }else{
              location.href = `${process.env.URL.MARKET}/#/sell`
            }
            break;
          case this.$t('vip'):
            location.href = `${process.env.URL.VIP}/#/`
            break;
          case this.$t('tb1'):
            location.href = `${process.env.URL.FRIENDS}/#/`
            break;
          case this.$t('tb2'):
            location.href = `${process.env.URL.NEWS}/#/`
            break;
        }
      },
      handleChange(el) {
      },
      handleScroll () {
        this.top = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (this.marketList.page.p > this.marketList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          this.marketList.page.p++
          this.$http.get(`${process.env.API.MARKET}/market/buyer/goodsList`,{params:{toppage:1,rows:10,p:this.marketList.page.p}}).then(res => {
            if (res.data.errcode == '0') {
              for(let value of res.data.data){
                value.file_pic = value.file_pic.split(',')
              }
              this.marketList.data = this.marketList.data.concat(res.data.data)
              this.marketList.page = res.data.page
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 500);
      },
      goTop(){
        let self = this
        let print = function () {
          self.top = self.top-300
          window.scrollTo(0,self.top)
        }
        let t = setInterval(function () {
          if(self.top<=0){
            window.scrollTo(0,self.top)
            window.clearInterval(t)
          }else{
            print();
          }
        }, 30);
      }
    },
    created() {
      let self = this
      document.title= 'swisstimevip'
      self.hei = document.body.clientWidth + 'px'
      self.imgHei = ((document.body.clientWidth - 10)/2-2.5)+'px'
    },
    mounted(){
      let self = this
      self.uid = localStorage.getItem('userId')
      window.addEventListener('scroll', this.handleScroll)
      self.$http.get(`${process.env.API.MARKET}/market/buyer/toppage`).then(res=>{
        if(res.data.errcode=='0'){
          self.data = res.data
          for(let value of self.data.partwatch){
            value.file_pic = value.file_pic.split(',')
          }
        }
      }).catch(err=>{
        console.log(err)
      })

      self.$http.get(`${process.env.API.USER}/user/bankcard`).then(res=>{
        if(res.data.errcode=='0'){
          self.bankList = res.data.data
        }
      }).catch(err=>{
        console.log(err)
      })


      setTimeout(()=>{
        self.userInfo = self.$store.state.userInfo
      },300)
    },
    components: {
      toolbar,
      InfiniteLoading
    }//公共底部
  }
</script>
<style lang="less" type="text/less">
  .ground {
    .mint-swipe {
      /*height: 375px;*/
      color: #fff;
      font-size: 30px;
      text-align: center;
      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }
    .groundNav {
      width: 100%;
      .navStyle {
        background: #fff;
        /*width: 100%;*/
        display: flex;
        margin-bottom: 10px;
        align-items: center;
        padding: 15px 0;
        box-sizing: border-box;
        overflow: scroll;
        li {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 100%;
          flex:1;
          img {
            width: 48px;
            display: block;
            margin-bottom: 10px;
          }
          span {
            font-size: 12px;
            color: #333;
            width: 100%;
            height: 30px;
            white-space: pre-wrap;
            word-break: break-all;
            text-align: center;
            padding: 0 7.5px;
            box-sizing: border-box;
          }
        }
      }
      .hotWatch {
        display: flex;
        overflow: scroll;
        width: 100%;
        padding: 0 5px;
        box-sizing: border-box;
        -webkit-overflow-scrolling: touch;
        li {
          display: flex;
          flex-direction: column;
          margin-right: 5px;
          border: 1px solid #f2f2f2;
          font-size: 12px;
          width: 165px;
          position: relative;
          background: #fff;
          .imgBg {
            width: 165px;
            height: 165px;
            object-fit: cover;
          }
          .is360{
            position: absolute;
            top: 10px;
            right: 10px;
            img{
              width: 22px;
              display: block;
            }
          }
          .lang {
            display: flex;
            align-items: center;
            font-size: 12px;
            color: #333;
            position: absolute;
            left: 8px;
            top: 10px;
            img {
              height: 16px;
              margin-right: 5px;
            }
          }
          .hotMainContent{
            width: 100%;
            padding: 15px 7.5px;
            box-sizing: border-box;
            font-size: 14px;
            .hotMainContentTit {
              width: 100%;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              font-weight: bold;
              margin-bottom: 10px;
              font-size: 14px;
            }
            .hotMainContentPrice {
              color: #666;
              display: block;
              margin-bottom: 10px;
              &.isNew{
                color: #eb4343;
              }
            }
            .hotMainContentFoo{
              display: flex;
              justify-content: space-between;
              align-items: center;
              font-size: 12px;
              p{
                color: #999;
                text-decoration:line-through;
              }
              span{
                border:1px solid #ccc;
                color: #333;
                padding: 0 3px;
                &.isNew{
                  color: #eb4343;
                  border-color: #eb4343;
                }
              }
            }
          }
        }
      }
    }
    .banners {
      margin: 10px 0;
      .bannersWrap {
        margin-bottom: 10px;
        position: relative;
        span {
          position: absolute;
          bottom: 15px;
          width: 100%;
          left: 0;
          display: flex;
          justify-content: center;
          font-size: 20px;
          font-weight: bold;
          color: #fefefe;
        }
        &:last-child {
          margin: 0;
        }
      }
    }
    .watchList{
      color: #333;
      margin-bottom: 80px;
      .title{
        height:50px;
        font-size: 16px;
        font-weight: bold;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      ul {
        display: flex;
        width: 100%;
        padding:5px;
        box-sizing: border-box;
        justify-content: space-between;
        flex-wrap: wrap;
        li {
          display: flex;
          flex-direction: column;
          width: calc(~'50% - 2.5px');
          box-sizing: border-box;
          background: #fff;
          margin-bottom: 5px;
          position: relative;
          .is360{
            position: absolute;
            top: 10px;
            right: 10px;
            img{
              width: 22px;
              display: block;
            }
          }
          .imgBg {
            width: 100%;
            object-fit: cover;
          }
          .lang {
            display: flex;
            align-items: center;
            font-size: 12px;
            color: #333;
            position: absolute;
            left: 8px;
            top: 10px;
            img {
              height: 16px;
              margin-right: 5px;
            }
          }
          .hotMainContent{
            width: 100%;
            padding: 15px 7.5px;
            box-sizing: border-box;
            font-size: 14px;
            .hotMainContentTit {
              width: 100%;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              font-weight: bold;
              margin-bottom: 10px;
            }
            .hotMainContentPrice {
              color: #666;
              display: block;
              margin-bottom: 10px;
              &.isNew{
                color: #eb4343;
              }
            }
            .hotMainContentFoo{
              display: flex;
              justify-content: space-between;
              align-items: center;
              font-size: 12px;
              p{
                color: #999;
                text-decoration:line-through;
              }
              span{
                border:1px solid #ccc;
                color: #333;
                padding: 0 3px;
                &.isNew{
                  color: #eb4343;
                  border-color: #eb4343;
                }
              }
            }
          }

        }
      }
    }
    .top{
      position: fixed;
      right: 15px;
      bottom: 60px;
      transition: all .5s;
      opacity: 1;
      z-index: 99;
      &.isShow{
        opacity: 0;
        z-index: -1;
      }
      img{
        width: 44px;
        height: 44px;
      }
    }
  }
</style>
