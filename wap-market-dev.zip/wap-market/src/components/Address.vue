<template>
  <div class="address">
    <ul>
      <li>
        <input type="text" :placeholder="$t('inputConsignee')" v-model="postData.name">
      </li>
      <li>
        <input type="number" :placeholder="$t('inputPhone')" v-model="postData.tel">
      </li>
      <li @click="locaShow = true">
        <p class="receipt" :class="{'fontColor':local==$t('selLocation')}">{{local}}<img
          src="../assets/images/market/arrow.png"></p>
      </li>
      <li>
        <textarea contenteditable="true" :placeholder="$t('addressText')" style="resize:none" rows="4"
                  v-model="postData.address">
        </textarea>
      </li>
    </ul>
    <p class="default isShow" @click="isDefault">
      <span :class="{'active':postData.is_default==1}"></span>{{$t('isDefault')}}
    </p>
    <div class="foo" @click="sub">
      {{$t('save')}}
    </div>
    <!--所在地弹出显示-->
    <mt-popup v-model="locaShow" position="bottom" class="mint-popup-4" style="height: 230px!important;">
      <div class="tit">
        <p @click="locaShow = false">{{$t('cancel')}}</p>
        <p @click="sureLocal">{{$t('complete')}}</p>
      </div>
      <mt-picker :slots="addressSlots" value-key="name" @change="onAddressChange" :visible-item-count="5"></mt-picker>
    </mt-popup>
  </div>
</template>
<script>
  let address = []
  export default {
    data() {
      return {
        location: [],
        local: this.$t('selLocation'),
        locaShow: false,
        address: address,
        addressSlots: [
          {
            flex: 1,
            defaultIndex: 1,
            values: address,
            className: 'slot1',
            textAlign: 'center'
          }, {
            flex: 1,
            values: [],
            className: 'slot2',
            textAlign: 'center'
          },
          {
            flex: 1,
            values: [],
            className: 'slot3',
            textAlign: 'center'
          }
        ],
        addressList: [],
        postData: {
          location: '',
          address: '',
          name: '',
          tel: '',
          is_default: 1,
          prov_code: '',
          city_code: '',
          dist_code: '',
          country_code: '' || 86,
          id: ''
        }
      }
    },
    methods: {
      onAddressChange(picker, values) {
        let self = this
        setTimeout(() => {
          if (self.address.length >= 1) {
            if (!values[0].city) {
              picker.setSlotValues(1, []);
              picker.setSlotValues(2, []);
              self.location[0] = values[0];
              self.location[1] = '';
              self.location[2] = '';
            } else {
              picker.setSlotValues(1, values[0].city);
              self.location[0] = values[0];
              self.location[1] = values[1];
              self.location[2] = values[2];
              setTimeout(() => {
                picker.setSlotValues(2, values[1].dist);
              }, 100)
            }
          }
        }, 300)
      },
      sureLocal() {
        let self = this
        if (self.location[1].name) {
          self.local = self.location[0].name + '/' + self.location[1].name + '/' + self.location[2].name
          self.postData.prov_code = self.location[0].code
          self.postData.city_code = self.location[1].code
          self.postData.dist_code = self.location[2].code
        } else {
          self.local = self.location[0].name
        }
        self.postData.location = self.local
        self.locaShow = false
      },
      isDefault() {
        let self = this
        if (self.addressList.length <= 0) {
          return false
        }
        if (self.postData.is_default) {
          self.postData.is_default = 0
        } else {
          self.postData.is_default = 1
        }
      },
      sub() {
        let self = this
        let reg = /^1(3|4|5|7|8)\d{9}$/
        if (!self.postData.name) {
          self.$toast(this.$t('inputConsignee'))
        } else if (!self.postData.tel) {
          self.$toast(this.$t('inputPhone'))
        } else if (!reg.test(self.postData.tel)) {
          self.$toast(this.$t('phoneError'))
        } else if (!self.postData.location) {
          self.$toast(this.$t('selLocation'))
        } else if (!self.postData.address) {
          self.$toast(this.$t('inputDetailAddress'))
        } else {
          if (self.$route.params.id) {
            self.$fun.putObj.put_data(self, `${process.env.API.USER}/user/address`, self.postData, '/user/address')
          } else {
            self.$fun.postObj.post_data(self, `${process.env.API.USER}/user/address`, self.postData, '/user/address')
          }
        }
      }
    },
    created() {
      document.title = this.$t('addressManagement')
    },
    mounted() {
      let self = this
      self.$nextTick(() => {
        setTimeout(() => {//这个是一个初始化默认值的一个技巧
          self.addressSlots[0].defaultIndex = 0;
        }, 100);
      });
      self.$http.get(`${process.env.API.DICT}/dict/area?kind=all&nonce=${Math.random()}`).then(res => {
        if (!res.data.errcode) {
          address = res.data
          self.addressSlots[0].values = address;
          self.address = address;
        }
      }).catch(err => {
        console.log(err)
      })
      self.$fun.getObj.get_list(self, `${process.env.API.USER}/user/address`, '/user/address')
      if (self.$route.params.id) {
        self.postData.name = self.$route.params.name
        self.postData.tel = self.$route.params.tel
        self.postData.address = self.$route.params.address
        self.postData.is_default = self.$route.params.is_default
        self.postData.id = self.$route.params.id
        self.local = self.$route.params.city_name
        self.postData.location = self.$route.params.city_name
        self.postData.city_code = self.$route.params.city_code
        self.postData.dist_code = self.$route.params.dist_code
        self.postData.prov_code = self.$route.params.prov_code
      }
    },
  }
</script>
<style lang="less" scoped type="text/less">
  .fontColor {
    color: #ccc;
  }

  .address {
    ul {
      background: #fff;
      margin: 10px 0 15px;
      li {
        display: flex;
        padding: 12px;
        border-bottom: 1px solid #f2f2f2;
        .receipt {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 14px;
          img {
            width: 7px;
            height: 12px;
          }
        }
        &:last-child {
          border: none;
        }
        p {
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: 100%;
        }
        input {
          width: 100%;
          border: none;
          height: 100%;
        }
        textarea {
          width: 100%;
          border: none;
          height: 100%;
          font-size: 14px;
        }
      }
    }
    .isShow {
      padding-left: 15px;
      margin-bottom: 75px;
      display: flex;
      justify-content: flex-end;
      padding-right: 15px;
    }
    .foo {
      background: #333;
      color: #fff;
      height: 44px;
      line-height: 44px;
      text-align: center;
      width: 250px;
      margin: 0 auto;
    }
  }
</style>
<style lang="less">
  body {
    background: #ecf0f4;
  }
</style>
