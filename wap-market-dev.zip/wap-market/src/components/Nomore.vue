<template>
  <div class="noMore">
    <img src="../assets/images/noMore.png">
    <div>
      {{$t('noMoreTit')}}
      <p>
        {{$t('noMoreMain')}}
      </p>
    </div>
  </div>
</template>
<style type="text/less" lang="less">
  .noMore{
    position: absolute;
    left: 0;
    top: 100px;
    box-sizing: border-box;
    width: 100%;
    display: flex;
    justify-content: center;
    flex-direction: column;
    align-items: center;
    height: 300px;
    div{
      display: flex;
      flex-direction: column;
      align-items: center;
      font-size: 20px;
      color: #333;
      p{
        font-size: 12px;
        color: #999;
        margin-top: 5px;
      }
    }
    img{
      width:120px;
      display: block;
      margin-bottom: 20px;
    }
  }
</style>
