<template>
  <div class="buy">
    <div class="head">
      <!--<div class="search">-->
        <!--<div>-->
          <!--<img class="" src="../assets/images/market/search.png">-->
          <!--<input type="text" :placeholder="$t('inputBrandText')" @focus="openSearch">-->
        <!--</div>-->
      <!--</div>-->
      <div class="topNav">
        <div class="topNavActive">
          {{$t('tb4')}}
        </div>
        <div @click="sellClick">
          {{$t('sell')}}
        </div>
        <span @click="$router.push('/search')">
          <img class="" src="../assets/images/market/searchFriend.png">
        </span>
      </div>
      <div class="nav">
        <ul>
          <li @click="navClick(1)" :class="{'navActive':navNum==1}">{{$t('newest')}}</li>
          <li @click="navClick(2)" :class="{'navActive':navNum==2}">{{$t('popularity')}}</li>
          <li @click="navClick(3)" :class="{'navActive':navNum==3}">{{$t('isPrice')}}
            <p>
              <img src="../assets/images/market/detail/price_up.png" :class="{'priceActive':priceNum==4}">
              <img src="../assets/images/market/detail/price_down.png" :class="{'priceActive':priceNum==5}">
            </p>
          </li>
          <li @click="navClick(4)" :class="{'navActive':navNum==4}">{{$t('screen')}}</li>
        </ul>
      </div>
    </div>
    <div class="main">
      <no-more v-if="marketList.data.length<=0"></no-more>
      <ul>
        <li v-for="item in marketList.data" @click="openDetail(item)">
          <img :src="item.cover_pic" :style="{height:imgHei}">
          <div class="hotMainContent">
            <div class="hotMainContentTit">
              <span v-if="item.exchange_stage!=30">{{item.exchange_stage_name}}</span>
              <div :class="{'isChange':item.exchange_stage!=30}">
                {{item.title}}
              </div>
            </div>
            <p class="hotMainContentPrice" :class="{'isNew':item.original_price!=item.price}">
              {{item.price}}
            </p>
            <div class="hotMainContentFoo">
              <p v-if="item.original_price!=item.price">{{item.original_price}}</p>
              <span :class="{'isNew':item.original_price!=item.price}" v-if="item.fineness_name">
                {{item.fineness_name}}
              </span>
            </div>
          </div>
          <span class="is360" v-if="item.is_360==1">
            <img src="../assets/images/market/360.png">
          </span>
          <span class="lang">
            <img :src="item.country_flag">{{item.country_short_name}}
          </span>
        </li>
        <infinite-loading :on-infinite="onInfinite" ref="infiniteLoading">
          <span slot="no-more" v-show="marketList.page.p>2">{{$t('noMore')}}</span>
          <span slot="no-results" v-show="marketList.page.p>2">{{$t('noMore')}}</span>
        </infinite-loading>
      </ul>
    </div>
    <toolbar :type="1"></toolbar>
  </div>
</template>

<script>
  import toolbar from '../components/toolbar'
  import InfiniteLoading from 'vue-infinite-loading';


  export default {
    data() {
      return {
        imgHei:0,
        messageBtn: {
          message: this.$t('isLogin'),
          title: this.$t('prompt'),
          confirmButtonText: this.$t('confirm'),
          cancelButtonText: this.$t('cancel'),
          showCancelButton: true,
          showConfirmButton: true
        },
        marketList: {
          data: [],
          page: {
            p: 0,
            total_pages: 1
          }
        },
        bankList:[],
        userInfo: {},
        navNum: 1,
        pageNum: 0,
        order: '',
        tit: '',
        priceNum: null,
        postData: {
          diameter_l: '',
          diameter_h: '',
          brand_id: '',
          money1: '',
          money2: '',
          material_id: '',
          shape_id: '',
          function_id: [],
          fineness: '',
          gender: '',
          movement_id: '',
          exchange_status: '',
          is_360:''
        }
      }
    },
    methods: {
      sellClick(){
        let self = this
        if(!self.uid){
          self.messageBtn.message = this.$t('isLogin')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/login`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }else if(self.userInfo&&self.userInfo.is_auth!=1){
          self.messageBtn.message = this.$t('isAuth')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.USER}/#/realname`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }else if(self.bankList&&self.bankList.length<=0){
          self.messageBtn.message = this.$t('addBankList')
          self.$messagebox(self.messageBtn).then(action => {
            if (action == 'confirm') {
              location.href = `${process.env.URL.MARKET}/#/banklist`
            }
          }).catch(err => {
            console.log(err)
          })
          return false
        }else{
          this.$router.push('/sell')
        }
      },
      onInfinite() {
        setTimeout(() => {
          let self = this
          if (this.marketList.page.p > this.marketList.page.total_pages) {
            this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            return false
          }
          this.marketList.page.p++
          let post = {
            order:self.order,
            title:self.tit,
            diameter_l:self.postData.diameter_l,
            diameter_h:self.postData.diameter_h,
            brand_id:self.postData.brand_id,
            price_l:self.postData.money1 || 0,
            price_h:self.postData.money2 || -1,
            material_id:self.postData.material_id,
            shape_id:self.postData.shape_id,
            function_id:self.postData.function_id,
            fineness_id:self.postData.fineness,
            gender:self.postData.gender,
            movement_id:self.postData.movement_id,
            exchange_status:self.postData.exchange_status,
            is_360:self.postData.is_360,
            p:this.marketList.page.p,
            rows:10
          }
          this.$http.get(`${process.env.API.MARKET}/market/buyer/goodsList`,{params:post}).then(res => {
            if (res.data.errcode == '0') {
              this.marketList.data = this.marketList.data.concat(res.data.data)
              this.marketList.page = res.data.page
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:loaded')
            } else {
              this.$refs.infiniteLoading.$emit('$InfiniteLoading:complete')
            }
          }).catch(err => {
            console.log(err)
          })
        }, 500);
      },
      openDetail(item) {
        this.$router.push(`/detail?id=${item.gid}`)
      },
      openSearch() {
        this.$router.push('/search')
      },
      navClick(index) {
        let self = this
        this.postData.brand_id =''
        this.postData.money1 = ''
        this.postData.money2 =''
        this.postData.material_id = ''
        this.postData.shape_id = ''
        this.postData.function_id = ''
        this.postData.fineness = ''
        this.postData.diameter_l = ''
        this.postData.diameter_h = ''
        this.postData.movement_id = ''
        this.postData.gender = ''
        this.postData.exchange_status = ''
        this.postData.is_360 = ''
        self.navNum = index
        if (self.tit) {
          self.tit = ''
        }
        if (index != 3) {
          self.priceNum = null
        }
        switch (index) {
          case 1:
            self.order = 'create_time'
            break;
          case 2:
            self.order = 'pv'
            break;
          case 3:
            if (!self.priceNum) {
              self.priceNum = 4
              self.order = 'price_h'
            } else if (self.priceNum == 4) {
              self.priceNum = 5
              self.order = 'price_l'
            } else {
              self.priceNum = 4
              self.order = 'price_h'
            }
            break;
          case 4:
            document.title = this.$t('screen')
            this.$router.push('/screen')
            break;
        }
        if (index != 4) {
          self.marketList.page.p = 0
          self.marketList.data = []
          self.$refs.infiniteLoading.$emit('$InfiniteLoading:reset');
        }
      },
    },
    created() {
      localStorage.removeItem('bankInfo')
      document.title = this.$t('watchSell')
      window.scrollTo(0,0)

      this.imgHei = ((document.body.clientWidth - 10)/2-2.5)+'px'
    },
    mounted() {
      // 调用方法
      if (this.$route.params.key==1||this.$route.params.search) {
        if(this.$route.params.search){
          this.tit = this.$route.params.search
        }else{
          this.$route.params.function_id = this.$route.params.function_id.join()
          this.postData.brand_id =this.$route.params.brand_id
          this.postData.money1 = this.$route.params.money1
          this.postData.money2 =this.$route.params.money2
          this.postData.material_id = this.$route.params.material_id
          this.postData.shape_id = this.$route.params.shape_id
          this.postData.function_id = this.$route.params.function_id
          this.postData.fineness = this.$route.params.fineness
          this.postData.diameter_l = this.$route.params.diameter_l
          this.postData.diameter_h = this.$route.params.diameter_h
          this.postData.movement_id = this.$route.params.movement_id
          this.postData.gender = this.$route.params.gender
          this.postData.exchange_status = this.$route.params.exchange_status
          this.postData.is_360 = this.$route.params.is_360
        }
      }
      let self = this
      self.uid = localStorage.getItem('userId')
      self.$http.get(`${process.env.API.USER}/user/bankcard`).then(res=>{
        if(res.data.errcode=='0'){
          self.bankList = res.data.data
        }
      }).catch(err=>{
        console.log(err)
      })
      setTimeout(()=>{
        self.userInfo = self.$store.state.userInfo
      },300)
    },
    components: {toolbar, InfiniteLoading}//公共底部
  }
</script>
<!--当前页面样式-->
<style lang="less" scoped type="text/less">
  .main {
    margin: 88px 0 0;
    overflow-x: hidden;
    overflow-y: scroll;
    height: calc(~'100vh - 134px');
    -webkit-overflow-scrolling: touch;
    background: #ecf0f4;
    ul {
      display: flex;
      width: 100%;
      padding:5px;
      box-sizing: border-box;
      justify-content: space-between;
      flex-wrap: wrap;
      margin-bottom: 44px;
      li {
        display: flex;
        flex-direction: column;
        width: calc(~'50% - 2.5px');
        box-sizing: border-box;
        background: #fff;
        margin-bottom: 5px;
        position: relative;
        .is360{
          position: absolute;
          top: 10px;
          right: 10px;
          img{
            width: 22px;
            display: block;
          }
        }
        .lang{
          display: flex;
          align-items: center;
          font-size: 12px;
          color: #333;
          position: absolute;
          left: 8px;
          top:10px;
          img{
            height: 16px;
            margin-right: 5px;
          }
        }
        .hotMainContent{
          width: 100%;
          padding: 15px 7.5px;
          box-sizing: border-box;
          font-size: 14px;
          .hotMainContentTit {
            width: 100%;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            div{
              width: 100%;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              font-weight: bold;
              &.isChange{
                width: calc(~'100% - 40px');
              }
            }
            span{
              margin: 0;
              background: #ecf0f4;
              padding: 0 5px;
              font-size: 12px;
              display: block;
              color: #333;
              margin-right: 5px;
            }
          }
          .hotMainContentPrice {
            color: #666;
            margin-bottom: 10px;
            &.isNew{
              color: #eb4343;
            }
          }
          .hotMainContentFoo{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12px;
            p{
              color: #999;
              text-decoration:line-through;
            }
            span{
              border:1px solid #ccc;
              color: #333;
              padding: 0 3px;
              &.isNew{
                color: #eb4343;
                border-color: #eb4343;
              }
            }
          }
        }
      }
    }
  }

  .buy {
    background: #fff;
    .head {
      position: fixed;
      width: 100%;
      left: 0;
      top: 0;
      background: #fff;
    }
    .topNav {
      display: flex;
      justify-content: center;
      background: #fff;
      font-size: 14px;
      position: relative;
      div{
        min-width: 100px;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #666;
        &.topNavActive{
          position: relative;
          color: #333;
          font-weight: bold;
          &:before{
            position: absolute;
            width: 20px;
            height: 2px;
            content: '';
            background: #333;
            bottom: 0;
            left: calc(~'50% - 10px');
          }
        }
      }
      span{
        position: absolute;
        left: 15px;
        top:15px;
        display: block;
        img{
          width: 19px;
          height: 19px;
        }
      }
    }
    //导航栏样式

    .nav {
      background: #fff;
      ul {
        height: 44px;
        width: 100%;
        display: flex;
        flex-wrap: nowrap;
        font-size: 14px;
        border-bottom: 1px solid #f2f2f2;
        border-top: 1px solid #f2f2f2;
        color: #333;
        li {
          width: 25%;
          color: #666;
          display: flex;
          justify-content: center;
          align-items: center;
          &.navActive {
            color: #333;
          }
          p {
            margin-left: 5px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            img {
              width: 5px;
              height: 4px;
              filter: grayscale(100%);
              opacity: .4;
              &.priceActive {
                filter: grayscale(0);
                opacity: 1;
              }
              &:first-child {
                margin-bottom: 2px;
              }
            }
          }
        }
      }
    }
  }
</style>
<!--公共less样式-->
<style lang="less" type="text/less">
  body {
    padding: 0 !important;
  }

  .brandStyle {
    display: flex !important;
    align-items: center;

    span {
      color: #333;
    }

    .mint-cell-title {
      flex: 0;
    }

    img {
      width: 60px;
      height: 30px;
      margin-right: 10px;
    }

  }
</style>
